/* Header for math elements.  */

extern struct math math;

extern void init_math(void);
extern void start_texeqn(struct stack *stack, int depth, int display);
extern void end_texeqn(struct stack *stack, int depth, int display);
