/* Parse the command line.
 * Copyright (C) 1994-1996 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>
/* For the GNU version of getopt().  */
#include "getopt.h"
#include "gf.h"

static void usage(void)
{
  printf("Usage: %s [options] file ...\n", c_line.prog_name);
  printf("Options:\n\
	[-pvV] [-f format] [-n DTD] [-o outfile] [-s style-sheet]\n\
	[-x parser-flags]\n");
  printf("\
	[--format=format]  [--help] [--new=DTD] [--output=outfile]\n\
	[--parse-only] [--parse-options=parser-flags] [--style=style-sheet]\n\
	[--style-help] [--verbose] [--version]\n");
  exit(0);
}

/* Parse the command line.  */
void parse_c_line(int argc, char *argv[])
{
  int i, j;
  int optchar;
  char *short_options = "n:o:x:ps:vf:V";
  static struct option long_options[] =
    {
      {"format", required_argument, NULL, 'f'},
      {"new", required_argument, NULL, 'n'},
      {"output", required_argument, NULL, 'o'},
      {"parse-only", no_argument, NULL, 'p'},
      {"style", required_argument, NULL, 's'},
      {"verbose", no_argument, NULL, 'v'},
      {"version", no_argument, NULL, 'V'},
      {"parse-options", required_argument, NULL, 'x'},
      {"help", no_argument, NULL, 141},
      {"style-help", no_argument, NULL, 142}
    };
    
  c_line.style_file = NULL;
  c_line.sgml_file = galloc(sizeof(char *));
  c_line.num_files = 0;
  c_line.new_doc = NO_DTD;
  c_line.out_file = NULL;
  c_line.popts = NULL;
  c_line.parse_only = 0;
  c_line.setter = DEFAULT_SETTER;
  c_line.family = family[c_line.setter];
  c_line.verbose = 0;
  c_line.style_doc = 0;
  c_line.prog_name = argv[0];

  while ((optchar = getopt_long(argc, argv, short_options, long_options, NULL))
	 != -1) {
    if (optchar == '?')
      exit(1);
    else if (optchar == 'f') {
      /* Compare each output format name with the supplied string.  */
      int found = 0;

      /* Allow case insensitivity of the name.  */
      lower_case(optarg);

      /* Provide the ASCII and LATEX names as aliases.  */
      if (strcmp(optarg, "ascii") == 0)
	optarg = "ab";
      else if (strcmp(optarg, "latex") == 0)
	optarg = "latex2e";
      for (j = 0; j < NUM_SETTERS; j++) {
	if (strcmp(optarg, setter_names[j]) == 0) {
	  c_line.setter = j;
	  found = 1;
	}
      }
      if (found == 0)
	error(EXIT, 0, "Unsupported format: %s", optarg);
      
      /* Assign the typesetter "family".  */
      c_line.family = family[c_line.setter];
    }
    else if (optchar == 'n') {
      for (j = 0; j < NUM_DTDS; j++) {
	if (strcmp(optarg, dtd_names[j]) == 0)
	  c_line.new_doc = j;
      }
      if (c_line.new_doc == NO_DTD)
	error(EXIT, 0, "Unrecognized DTD `%s'", optarg);
    }
    else if (optchar == 'o')
      c_line.out_file = optarg;
    else if (optchar == 'p')
      c_line.parse_only = 1;
    else if (optchar == 's')
      c_line.style_file = optarg;
    else if (optchar == 'v') 
      c_line.verbose = 1;
    else if (optchar == 'V') {
      /* Print version number and exit.  */
      puts(version);
      exit(0);
    }
    else if (optchar == 'x')
      c_line.popts = optarg;
    else if (optchar == 141) {
      /* --help  */
      usage();
    }
    else if (optchar == 142) {
      /* Printing style documentation is prosponed until the style sheets
       * have been read etc.
       */
      c_line.style_doc = 1;
    }
  }
  /* Read the remaining arguments (filenames).  */
  while (argv[optind] != NULL) {
    /* Reading from stdin is broken.
     *  if (strcmp(argv[optind], "-") == 0) {
     *    if (c_line.num_files == 0) {
     *      c_line.sgml_file[0] = argv[optind];
     *      c_line.num_files = 1;
     *    }
     *  }
     */
    if (c_line.num_files == 0) { /* || strcmp(c_line.sgml_file[0], "-") == 0 */
      c_line.sgml_file[0] = galloc(strlen(argv[optind]) + 1);
      strcpy(c_line.sgml_file[0], argv[optind]);
      c_line.num_files = 1;
    }
    else {
      c_line.num_files++;
      c_line.sgml_file = 
	grealloc(c_line.sgml_file, c_line.num_files * sizeof(char *));
      c_line.sgml_file[c_line.num_files - 1] =
	galloc(strlen(argv[optind]) + 1);
      strcpy(c_line.sgml_file[c_line.num_files - 1], argv[optind]);
    }
    optind++;
  }

  /* If no files specified, would read from stdin if it was not broken.
   * if (c_line.num_files == 0) {
   *   c_line.sgml_file[0] = "-";
   *   c_line.num_files = 1;
   *  }
   */

  if (c_line.num_files > 0) {
    /* Derive extensionless filenames and directory names.  */
    c_line.base_name = galloc(c_line.num_files * sizeof(char *));
    c_line.dir_name = galloc(c_line.num_files * sizeof(char *));
    for (i = 0; i < c_line.num_files; i++) {
      char *dir_ptr;
      char *base_ptr;
      int dir_len;
      int base_len;

      c_line.dir_name[i] = galloc(strlen(c_line.sgml_file[i]) + 1);
      strcpy(c_line.dir_name[i], c_line.sgml_file[i]);
      if ((dir_ptr = strrchr(c_line.dir_name[i], '/')) != NULL)
	*dir_ptr = '\0';
      else
	c_line.dir_name[i][0] = '\0';
      dir_len = dir_ptr - c_line.dir_name[i];

      c_line.base_name[i] = galloc(strlen(c_line.sgml_file[i]) + 1);
      strcpy(c_line.base_name[i], c_line.sgml_file[i]);
      if ((base_ptr = strrchr(c_line.base_name[i], '.')) != NULL) {
	base_len = base_ptr - c_line.base_name[i];

	/* Only remove extensions after the final slash.  */
	if (base_len > dir_len)
	  *base_ptr = '\0';
      }
    }
  }
}

/* Create a new SGML document instance with a given DTD. Search for
 * template in  1/ user's library directory 2/ system library directory.
 */

void new_doc(void)
{
  char *file_name;
  char *temp;
  FILE *in, *out;
  int temp_char;

  /* Get the name of the template and search the directories.  */
  file_name = galloc(strlen(dtd_names[c_line.new_doc])
		     + strlen(TEMPLATE_EXT) + 1);
  sprintf(file_name, "%s%s", dtd_names[c_line.new_doc], TEMPLATE_EXT);
  if ((temp = exists_user_dir(file_name)) == NULL) {
    if ((temp = exists_system_dir(file_name)) == NULL)
      error(EXIT, 0, "unable to open %s", file_name);
  }
  if ((in = fopen(temp, "r")) == NULL) 
    error(EXIT, 0, "unable to open %s", temp);
  
  if (c_line.num_files == 0 || strcmp(c_line.sgml_file[0], "-") == 0)
    out = stdout;
  else {
    if (exists(c_line.sgml_file[0]))
      error(EXIT, 0, "%s already exists", c_line.sgml_file[0]);

    if ((out = fopen(c_line.sgml_file[0], "w")) == NULL) {
      verbose(c_line.sgml_file[0], FAIL, WRITE);
      error(EXIT, 0, "unable to open %s for output", c_line.sgml_file[0]);
    }
    verbose(c_line.sgml_file[0], OK, WRITE);
  }

  while ((temp_char = fgetc(in)) != EOF)
    fputc(temp_char, out);

  gfree(temp);
  gfree(file_name);
  fclose(out);
}
