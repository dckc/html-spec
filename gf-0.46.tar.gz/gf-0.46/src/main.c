/* Main program for the SGML formatter.
 * Copyright (C) 1993-1996 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"

/* Definitions of global data structures used only by gf.  */

/* Functions to call at element start and end, for each DTD.  */
el_fun *dtd_element_start[] = {
  &smemo_element_start, &spaper_element_start, &sletter_element_start,
  &html_element_start, &general_element_start};

el_fun *dtd_element_end[] = {
  &smemo_element_end, &spaper_element_end, &sletter_element_end,
  &html_element_end, &general_element_end};

/* Function to call for external entity references, for each DTD.  */
ent_fun *dtd_x_ent[] = {
  &smemo_x_ent, &spaper_x_ent, &sletter_x_ent,
  &html_x_ent, &general_x_ent};

/* Function to call for each data string, for each DTD.  */
char_fun *dtd_chars[] = {
  &smemo_chars, &spaper_chars, &sletter_chars, &html_chars, &general_chars};

/* End function for each DTD.  */
end_fun *dtd_end[] = {
  &smemo_end, &spaper_end, &sletter_end, &html_end, &general_end};

int main(int argc, char *argv[])
{
  int i;

  /* Fix buffering, so error messages don't get out of order. */
#ifdef SETVBUF_REVERSED
  setvbuf(stdout, _IOLBF, (char *) NULL, BUFSIZ);
#else
  setvbuf(stdout, (char *) NULL, _IOLBF, BUFSIZ);
#endif

  /* Set libdir and userdir from GF_LIBDIR and GF_USERDIR or defaults.  */
  if ((libdir = getenv("GF_LIBDIR")) == NULL) {
    libdir = galloc(strlen(LIBDIR) + 1);
    strcpy(libdir, LIBDIR);
  }
  if ((userdir = getenv("GF_USERDIR")) == NULL) {
    char *homedir = getenv("HOME");

    if (homedir == NULL) {
      error(WARN, 0, "unable to get HOME from environment: using /");
      homedir = "/";
    }
    userdir = galloc(strlen(homedir) + 1 + strlen(USERDIR) + 1);
    sprintf(userdir, "%s/%s", homedir, USERDIR);
  }

  parse_c_line(argc, argv);

  c_line.dtd = NO_DTD;

  if (c_line.verbose) {
    fputs(version, stderr);
    fputc('\n', stderr);
    fputs("DTDs:", stderr);
    for (i = 0; i < NUM_DTDS; i++)
      fprintf(stderr, " %s", dtd_names[i]);
    fputc('\n', stderr);
    fputs("Formatters:", stderr);
    for (i = 0; i < NUM_SETTERS; i++)
      fprintf(stderr, " %s", setter_names[i]);
    fputc('\n', stderr);
  }

  if (c_line.new_doc != NO_DTD)
    new_doc();
  else if (c_line.num_files == 0)
    error(EXIT, 0, "missing filename(s).  --help gives usage summary.");
  else if (c_line.sgml_file != NULL) 
    parse_document();

  exit(0);
}
