/* Header for header elements.  */

struct header {
  int need_titlepage;		/* Whether a title page is needed.  */
  int need_toc;			/* Whether a table of contents is needed.  */
};

extern struct header header;

extern void init_header(void);
extern void start_aline(struct stack *stack, int depth);
extern void end_aline(struct stack *stack, int depth);
extern void start_copyrite(struct stack *stack, int depth);
extern void start_copy_noprint(struct stack *stack, int depth);
extern void end_copy_noprint(struct stack *stack, int depth);
extern void start_toc(struct stack *stack, int depth);
extern void start_lof(struct stack *stack, int depth);
