/* Routines for the smemo formatters.
 * Copyright (C) 1993-1996 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 *
 * Public functions: smemo_element_start,
 * smemo_element_end, smemo_x_ent, smemo_chars, smemo_end.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include "gf.h"
#include "text.h"
#include "structure.h"
#include "header.h"
#include "displayed.h"
#include "link.h"
#include "list.h"
#include "table.h"
#include "math.h"
#include "figure.h"

/* Translations for mapping SDATA to output.  */
static struct sdata_table sdata;

/* Data local to this DTD.  */
static struct {
  int pass;			/* Pass number through the document.  */
  int version;			/* Version of the DTD.  */
  int sent_blanks;		/* Blanks after each "sentence": 1 or 2.  */
} dtd;

/* Initialise data structures (once).  */
static void dtd_init(struct stack *stack, int depth)
{
  /* Version number.  */
  struct attr *version_ptr = check_attribute(stack, "VERSION");
  char *dummy;			/* Dummy pointer.  */
  char *ext;			/* Extension for SDATA files.  */

  dtd.pass = 1;			/* 1st pass through the document.  */

  output.discard_text = 1;	/* Don't print text on first pass.  */

  xlink.cross_ref.next = NULL;	/* Linked list for cross-ref information. */

  dtd.version = strtol(version_ptr->values, &dummy, 10);

  /* Initialize data structures.  These also get called at the beginning
   * of the second pass.
   */
  init_text();
  init_structure();
  init_display();
  init_figure();
  init_list();

  if (c_line.family == FAM_TEX) {
    char *temp = check_style("line-width");

    output.line_width = strtol(temp, &dummy, 10); /* Auto line breaking.  */

    ext = ".2tex";
  }
  else if (c_line.family == FAM_PLAIN) {
    char *temp = check_style("line-width");

    output.line_width = strtol(temp, &dummy, 10); /* Auto line breaking.  */

    /* Find how many blanks should be printed after each sentence-like
     * construction.
     */
    if (strcmp(check_style("sent-spacing"), "single") == 0)
      dtd.sent_blanks = 1;
    else
      dtd.sent_blanks = 2;

    if (c_line.setter == AB)
      ext = ".2ab";
    else if (c_line.setter == AS)
      ext = ".2as";
    else if (c_line.setter == L1B)
      ext = ".2l1b";
    else if (c_line.setter == L1S)
      ext = ".2l1s";
  }
  else if (c_line.setter == RTF) {
    char *font_link = check_style("fpar");    /* Paragraph font link.  */
    char *style_link = check_style("spar");   /* Paragraph style link.  */

    output.line_width = 50000;	/* An output line can be this long.
				 * If a line was longer, a blank would be lost.
				 */

    /* Find how many blanks should be printed after each sentence-like
     * construction.
     */
    if (strcmp(check_style("sent-spacing"), "single") == 0)
      dtd.sent_blanks = 1;
    else
      dtd.sent_blanks = 2;

    /* Set up the text for new paragraphs.  */
    output.new_par = galloc(strlen("{\\pard\\plain\\f\\s ") +
			    strlen(font_link) + strlen(style_link) + 1);
    sprintf(output.new_par, "{\\pard\\plain\\f%s\\s%s ", font_link,
	    style_link);

    ext = ".2rtf";
  }
  else {
    error(EXIT, 0, "formatter `%s' is not supported for %s", 
	  setter_names[c_line.setter], dtd_names[c_line.dtd]);
  }
  /* Read SDATA translation tables.  */
  {
    char file[20];		/* File names.  */

    sdata.next = NULL;
    get_sdata_local(ext, &sdata);

    sprintf(file, "ISOlat1%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOlat2%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOnum%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOpub%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOdia%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOtech%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "GFextra%s", ext);
    get_sdata_translations(file, &sdata);
  }
}

void smemo_element_start(struct stack *stack, int depth)
{
  char *element = stack->element;
  static first = 1;
    
  if (first) {
    dtd_init(stack, depth);
    first = 0;
  }
  if (dtd.pass == 1) {
    if (c_line.family == FAM_TEX) {
      if (strcmp(element, "FIGBODY") == 0)
	start_figbody(stack, depth, 1);
    }
    else if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
      if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
	int head_level = element[1] - '0';
	start_heading(stack, depth, head_level, 1);
      }
      else if (strcmp(element, "OL") == 0)
	start_ordered_list(stack, depth, 1, 0);
      else if (strcmp(element, "LI") == 0)
	start_list_item(stack, depth, 1);
      else if (strcmp(element, "FIG") == 0)
	start_fig(stack, depth, 1);
      else if (dtd.version < 5 && strcmp(element, "FN") == 0)
	start_note(stack, depth, 1);
      else {
	/* Check for NOTE architectural form.  */
	struct attr *arch_ptr = query_attribute(stack, "SARC");
	
	if (arch_ptr != NULL) {
	  if (strcmp(arch_ptr->values, "NOTE") == 0)
	    start_note(stack, depth, 1);
	}
      }
    }
  }
  else {
    if (strcmp(element, "P") != 0)
      text.par_pending = 0;
    text.new_par = 0;
    if (strcmp(element, "P") == 0)
      start_paragraph(stack, depth);
    else if (strcmp(element, "Q") == 0)
      start_shortquote(stack, depth);
    else if (strcmp(element, "SMEMO") == 0) {
      init_text();
      init_structure();
      init_display();
      init_figure();
      init_list();
      output.discard_text = 0;
      start_document(stack, depth);
    }
    else if (dtd.version < 5 && strcmp(element, "CODE") == 0) {
      char *type = check_attribute(stack, "BREAK")->values;

      if (strcmp(type, "INTEXT") == 0)
	start_code_inline(stack, depth);
      else
	start_code_lines(stack, depth);
    }
    else if (strcmp(element, "FIG") == 0)
      start_fig(stack, depth, 0);
    else if (strcmp(element, "FIGBODY") == 0)
      start_figbody(stack, depth, 0);
    else if (strcmp(element, "FIGCAP") == 0)
      start_figcap(stack, depth);
    else if (dtd.version < 5 && strcmp(element, "FN") == 0)
      start_note(stack, depth, 0);
    else if (strcmp(element, "OL") == 0)
      start_ordered_list(stack, depth, 0, 0);
    else if (strcmp(element, "UL") == 0)
      start_unordered_list(stack, depth, 0);
    else if (strcmp(element, "SL") == 0)
      start_simple_list(stack, depth);
    else if (strcmp(element, "TL") == 0)
      start_tagged_list(stack, depth);
    else if (strcmp(element, "LI") == 0)
      start_list_item(stack, depth, 0);
    else if (strcmp(element, "TLIT") == 0)
      start_tagged_list_tag(stack, depth);
    else if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
      int head_level = element[1] - '0';
      start_heading(stack, depth, head_level, 0);
    }
    else if (strcmp(element, "APPENDIX") == 0)
      start_appendix(stack, depth);
    else if (strcmp(element, "REF") == 0)
      start_reference(stack, depth);
    else if (strcmp(element, "HDREF") == 0 || strcmp(element, "FIGREF") == 0
	     || strcmp(element, "FNREF") == 0
	     || strcmp(element, "LIREF") == 0) {
      char *type = check_attribute(stack, "TYPE")->values;

      start_long_reference(stack, depth, strcmp(type, "NOPAGE"));
    }
    else if (dtd.version < 5 && strncmp(element, "HP", 2) == 0
	     && element[3] == '\0')
      start_phrase(stack, depth);
    else if (strcmp(element, "TEXEQN") == 0) {
      if (dtd.version < 5) {
	char *type = check_attribute(stack, "BREAK")->values;

	if (strcmp(type, "INTEXT") == 0)
	  start_texeqn(stack, depth, 0);
	else
	  start_texeqn(stack, depth, 1);
      }
      else
	start_texeqn(stack, depth, 0);
    }
    else if (strcmp(element, "TEXEQN-DISPLAY") == 0)
      start_texeqn(stack, depth, 1);
    else if (strcmp(element, "FROM") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\from{");
    }
    /* ALINE is no longer used in smemo.  */
    else if (strcmp(element, "NAME") == 0 || strcmp(element, "ALINE") == 0) {
      if (c_line.family == FAM_TEX || structure.infrontm)
	start_aline(stack, depth);
    }
    else if (strcmp(element, "TO") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\to{");
      /* Storage for ASCII and RTF is done by ALINE or NAME.  */
    }
    else if (strcmp(element, "CC") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\cc{");
    }
    else if (strcmp(element, "THROUGH") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\through{");
    }
    else if (strcmp(element, "SUBJECT") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\subject{");
	text.new_par = 1;
      }
      else if (c_line.family == FAM_PLAIN || c_line.setter == RTF)
	start_storage("SUBJECT");
    }
    else if (strcmp(element, "DATE") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\date{");
	text.new_par = 1;
      }
      else if (c_line.family == FAM_PLAIN || c_line.setter == RTF)
	start_storage("DATE");
    }
    else if (strcmp(element, "ACTIONBY") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\actionby{");
	text.new_par = 1;
      }
      else if (c_line.family == FAM_PLAIN || c_line.setter == RTF)
	start_storage("ACTIONBY");
    }
    else if (strcmp(element, "DOCNUM") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\docnum{");
	text.new_par = 1;
      }
      else if (c_line.family == FAM_PLAIN || c_line.setter == RTF)
	start_storage("DOCNUM");
    }
    else if (strcmp(element, "X-HEAD-T") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\xheadt{");
	text.new_par = 1;
      }
      else if (c_line.family == FAM_PLAIN || c_line.setter == RTF)
	start_storage("X-HEAD-T");
    }
    else if (dtd.version < 5 && strcmp(element, "X-HEAD-D") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\xheadd{");
      /* Storage for ASCII and RTF is done by ALINE or NAME.  */
    }
    else if (strcmp(element, "CLOSING") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\closing{");
      }
      else 
	output.need_gap = 1;
    }
    else if (strcmp(element, "SIGNED") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\signed{");
      }
      else 
	output.need_gap = 1;
    }
    else if (strcmp(element, "BODY") == 0) {
      /* Write the complete memo header.  */
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\begin{document}");
	output.need_wrap = 1;
	gfputs("\\begin{memo}");
	output.need_wrap = 1;
      }
      else if (c_line.family == FAM_PLAIN) {
	struct stored_text *link = &stored_text; /* Steps through list.  */
	struct stored_text *text_link = &stored_text; /* Steps through list. */
	int got_date = 0;	/* Whether date line has been found.  */
	char *tag;		/* Text to be printed at start of lines. */

	/* For each type of heading, search the stored text.  */
	while (link->next != NULL) {
 	  if (strcmp(link->key, "SUBJECT") == 0) {
	    gfprintf("Subject: %s", link->text);
	    output.need_wrap = 1;
	  }
	  link = link->next;
	}
	link = &stored_text;
	tag = "To: ";
	while (link->next != NULL) {
	  if (strcmp(link->key, "TO") == 0) {
	    gfprintf("%s%s", tag, link->text);
	    output.need_wrap = 1;
	    tag = "    ";
	  }
	  link = link->next;
	}
	link = &stored_text;
	tag = "Through: ";
	while (link->next != NULL) {
	  if (strcmp(link->key, "THROUGH") == 0) {
	    gfprintf("%s%s", tag, link->text);
	    output.need_wrap = 1;
	    tag = "         ";
	  }
	  link = link->next;
	}
	link = &stored_text;
	tag = "cc: ";
	while (link->next != NULL) {
	  if (strcmp(link->key, "CC") == 0) {
	    gfprintf("%s%s", tag, link->text);
	    output.need_wrap = 1;
	    tag = "    ";
	  }
	  link = link->next;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "ACTIONBY") == 0) {
	    gfprintf("Action By: %s", link->text);
	    output.need_wrap = 1;
	  }
	  link = link->next;
	}
	/* This one is a little tricky: step through the list with
	 * two pointers, to get the xheader tag and the text
	 * in synchronisation.  Multiple text lines are possible.
	 */
	link = &stored_text;
	text_link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "X-HEAD-T") == 0) {
	    tag = galloc(strlen(link->text) + 3);
	    sprintf(tag, "%s: ", link->text);
	    text_link = link->next;
	    while (text_link->next != NULL) {
	      if (strcmp(text_link->key, "X-HEAD-T") == 0)
		break;		/* From the inner loop.  */
	      if ((dtd.version < 5 && strcmp(text_link->key, "X-HEAD-D") == 0)
		  || (dtd.version >=5
		      && strcmp(text_link->key, "X-HEADER") == 0)) {
		gfprintf("%s%s", tag, text_link->text);
		output.need_wrap = 1;
		/* Replace the tag with blanks.  */
		sprintf(tag, "%*s", (int) (strlen(link->text) + 2), "");
	      }
	      text_link = text_link->next;
	    }
	    gfree(tag);
	  }
	  link = link->next;
	}
	link = &stored_text;
	tag = "From: ";
	while (link->next != NULL) {
	  if (strcmp(link->key, "FROM") == 0) {
	    gfprintf("%s%s", tag, link->text);
	    output.need_wrap = 1;
	    tag = "      ";
	  }
	  link = link->next;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "DATE") == 0) {
	    gfprintf("Date: %s", link->text);
	    output.need_wrap = 1;
	    got_date = 1;
	  }
	  link = link->next;
	}
	link = &stored_text;
	if (got_date == 0) {
	  /* Put today's date.  */
	  time_t second;
	  struct tm *local;
	  char ftime[30];
	  char *datesty = check_style("datesty");
	  time(&second);
	  local = localtime(&second);
	  if (strcmp(datesty, "ddmonthyyyy") == 0) 
	    strftime(ftime, 30, "Date: %d %B %Y", local);
	  else if (strcmp(datesty, "monthddyyyy") == 0)
	    strftime(ftime, 30, "Date: %B %d, %Y", local);
	  else if (strcmp(datesty, "slashddmmyy") == 0)
	    strftime(ftime, 30, "Date: %d/%m/%y", local);
	  else if (strcmp(datesty, "slashmmddyy") == 0)
	    strftime(ftime, 30, "Date: %m/%d/%y", local);
	  else if (strcmp(datesty, "ISO") == 0)
	    strftime(ftime, 30, "Date: %Y-%m-%d", local);

	  gfputs(ftime);
	  output.need_wrap = 1;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "DOCNUM") == 0) {
	    gfprintf("ref: %s", link->text);
	    output.need_wrap = 1;
	  }
	  link = link->next;
	}
	output.need_gap = 1;
	/* Free the stored text, if no other storage.  */
	if (output.store_text == 0)
	  free_storage();
      }
      else if (c_line.setter == RTF) {
	char *font = check_style("fpar");
	char *style = check_style("spar");
	struct stored_text *link = &stored_text; /* Steps through list.  */
	struct stored_text *text_link = &stored_text;
	int got_date = 0;	/* Whether date line has been found.  */
	char *tag;		/* Text to be printed at start of lines. */

	/* For each type of heading, search the stored text.  */
	while (link->next != NULL) {
	  if (strcmp(link->key, "SUBJECT") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s Subject: %s",
		     font, style, link->text);
	    output.need_line = 1;
	  }
	  link = link->next;
	}
	link = &stored_text;
	tag = "To: ";
	while (link->next != NULL) {
	  if (strcmp(link->key, "TO") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s %s%s",
		     font, style, tag, link->text);
	    output.need_line = 1;
	    tag = "    ";
	  }
	  link = link->next;
	}
	link = &stored_text;
	tag = "Through: ";
	while (link->next != NULL) {
	  if (strcmp(link->key, "THROUGH") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s %s%s",
		     font, style, tag, link->text);
	    output.need_line = 1;
	    tag = "        ";
	  }
	  link = link->next;
	}
	link = &stored_text;
	tag  = "cc: ";
	while (link->next != NULL) {
	  if (strcmp(link->key, "CC") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s %s%s",
		     font, style, tag, link->text);
	    output.need_line = 1;
	    tag = "    ";
	  }
	  link = link->next;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "ACTIONBY") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s Action By: %s",
		     font, style, link->text);
	    output.need_line = 1;
	  }
	  link = link->next;
	}
	/* This one is a little tricky: step through the list with
	 * two pointers, to get the xheader tag and the text
	 * in synchronisation.  Multiple text lines are possible.
	 */
	link = &stored_text;
	text_link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "X-HEAD-T") == 0) {
	    tag = galloc(strlen(link->text) + 3);
	    sprintf(tag, "%s: ", link->text);
	    text_link = link->next;
	    while (text_link->next != NULL) {
	      if (strcmp(text_link->key, "X-HEAD-T") == 0)
		break;		/* From the inner loop.  */
	      if ((dtd.version < 5 && strcmp(text_link->key, "X-HEAD-D") == 0)
		  || (dtd.version >=5
		      && strcmp(text_link->key, "X-HEADER") == 0)) {
		gfprintf("}{\\pard\\plain\\f%s\\s%s %s%s",
			 font, style, tag, text_link->text);
		output.need_line = 1;
		/* Replace the tag with blanks.  */
		sprintf(tag, "%*s", (int) (strlen(link->text) + 2), "");
	      }
	      text_link = text_link->next;
	    }
	    gfree(tag);
	  }
	  link = link->next;
	}
	link = &stored_text;
	tag = "From: ";
	while (link->next != NULL) {
	  if (strcmp(link->key, "FROM") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s %s%s",
		     font, style, tag, link->text);
	    output.need_line = 1;
	  }
	  link = link->next;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "DATE") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s Date: %s",
		     font, style, link->text);
	    output.need_line = 1;
	    got_date = 1;
	  }
	  link = link->next;
	}
	if (got_date == 0) {
	  /* Always use the current date.  */
	  gfprintf("}{\\pard\\plain\\f%s\\s%s Date: \\chdate",
		   font, style);
	  output.need_line = 1;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "DOCNUM") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s ref: %s",
		     font, style, link->text);
	    output.need_line = 1;
	  }
	  link = link->next;
	}
	output.need_gap = 1;
	/* Free the stored text, if no other storage.  */
	if (output.store_text == 0)
	  free_storage();
      }
    }
    else {
      /* Check for architectural forms.  */
      struct attr *arch_ptr = query_attribute(stack, "SARC");
      
      if (arch_ptr != NULL) {
	if (strcmp(arch_ptr->values, "NOTE") == 0)
	  start_note(stack, depth, 0);
	else if (strcmp(arch_ptr->values, "PHRASE") == 0)
	  start_phrase(stack, depth);
	else if (strcmp(arch_ptr->values, "CODE") == 0)
	  start_code_inline(stack, depth);
	else if (strcmp(arch_ptr->values, "LISTING") == 0)
	  start_code_lines(stack, depth);
      }	
    }
  }
}

void smemo_element_end(struct stack *stack, int depth)
{
  char *element = stack->element;

  if (dtd.pass == 1) {
    /* 1st pass: just keeping track of counters.  */
    if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
      if (strcmp(element, "OL") == 0)
	end_ordered_list(stack, depth, 1);
    }
  }
  else {
    text.aline_pending = 0;
    text.new_par = 0;
    text.par_pending = 0;
    if (strcmp(element, "P") == 0)
      end_paragraph(stack, depth);
    else if (strcmp(element, "Q") == 0)
      end_shortquote(stack, depth);
    else if (strcmp(element, "MEMOFRONT") == 0
	     || (dtd.version < 5 && strcmp(element, "FRONTM") == 0))
      structure.infrontm = 0;
    else if (dtd.version < 5 && strcmp(element, "CODE") == 0) {
      char *type = check_attribute(stack, "BREAK")->values;

      if (strcmp(type, "INTEXT") == 0)
	end_code_inline(stack, depth);
      else
	end_code_lines(stack, depth);
    }
    else if (dtd.version < 5 && strcmp(element, "CODE-LINES") == 0)
      end_code_lines(stack, depth);
    else if (strcmp(element, "FIG") == 0)
      end_fig(stack, depth);
    else if (strcmp(element, "FIGCAP") == 0)
      end_figcap(stack, depth);
    else if (dtd.version < 5 && strcmp(element, "FN") == 0)
      end_note(stack, depth);
    else if (strcmp(element, "OL") == 0)
      end_ordered_list(stack, depth, 0);
    else if (strcmp(element, "UL") == 0)
      end_unordered_list(stack, depth);
    else if (strcmp(element, "SL") == 0)
      end_simple_list(stack, depth);
    else if (strcmp(element, "LI") == 0)
      end_list_item(stack, depth);
    else if (strcmp(element, "TL") == 0)
      end_tagged_list(stack, depth);
    else if (strcmp(element, "TLIT") == 0)
      end_tagged_list_tag(stack, depth);
    else if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
      int head_level = element[1] - '0';
      end_heading(stack, depth, head_level, 0);
    }
    else if (dtd.version < 5 && strncmp(element, "HP", 2) == 0
	     && element[3] == '\0')
      end_phrase(stack, depth);
    else if (strcmp(element, "TEXEQN") == 0) {
      if (dtd.version < 5) {
	char *type = check_attribute(stack, "BREAK")->values;

	if (strcmp(type, "INTEXT") == 0)
	  end_texeqn(stack, depth, 0);
	else
	  end_texeqn(stack, depth, 1);
      }
      else
	end_texeqn(stack, depth, 0);
    }
    else if (strcmp(element, "TEXEQN-DISPLAY") == 0)
      end_texeqn(stack, depth, 1);
    /* ALINE is no longer used in smemo.  */
    else if (strcmp(element, "NAME") == 0 || strcmp(element, "ALINE") == 0) {
      if (c_line.family == FAM_TEX || structure.infrontm)
	end_aline(stack, depth);
      else if (c_line.family != FAM_TEX)
	output.need_line = 1;
    }
    else if (strcmp(element, "SUBJECT") == 0
	     || strcmp(element, "DATE") == 0
	     || strcmp(element, "ACTIONBY") == 0
	     || strcmp(element, "DOCNUM") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("}");
	output.need_wrap = 1;
      }
      else if (c_line.family == FAM_PLAIN || c_line.setter == RTF)
	end_storage();
    }
    else if (strcmp(element, "X-HEAD-T") == 0) {
      if (c_line.family == FAM_TEX) {
	if (dtd.version < 5)
	  gfputs("}");
	else
	  gfputs("}\\xheadd{");
      }
      else if (c_line.family == FAM_PLAIN || c_line.setter == RTF)
	end_storage();
    }
    else if ((dtd.version < 5 && strcmp(element, "X-HEAD-D") == 0)
	     || (dtd.version >= 5 && strcmp(element, "X-HEADER") == 0)) {
      if (c_line.family == FAM_TEX) {
	gfputs("}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "FROM") == 0
	     || strcmp(element, "TO") == 0
	     || strcmp(element, "CC") == 0
	     || strcmp(element, "THROUGH") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("}");
	output.need_wrap = 1;
      }
      /* Storage for these elements is done by ALINE or NAME.  */
    }
    else if (strcmp(element, "CLOSING") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("}");
	output.need_wrap = 1;
      }
      else 
	output.need_gap = 1;
    }
    else if (strcmp(element, "SIGNED") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "SMEMO") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\end{memo}");
	output.need_wrap = 1;
      }
      end_document(stack, depth);
    }
    else {
      /* Check for architectural forms.  */
      struct attr *arch_ptr = query_attribute(stack, "SARC");
      
      if (arch_ptr != NULL) {
	if (strcmp(arch_ptr->values, "NOTE") == 0)
	  end_note(stack, depth);
	else if (strcmp(arch_ptr->values, "PHRASE") == 0)
	  end_phrase(stack, depth);
	else if (strcmp(arch_ptr->values, "CODE") == 0)
	  end_code_inline(stack, depth);
	else if (strcmp(arch_ptr->values, "LISTING") == 0)
	  end_code_lines(stack, depth);
      }	
    }
  }
}

/* Amount of memory to grab at once when reading files.  */
#define BLOCK 1000

/* Process an external entity reference.  */
void smemo_x_ent(struct stack *stack, int depth,
		  struct entity_info *entity_ptr)
{
  if (dtd.pass == 1)
    return;

  if (strcmp(entity_ptr->notation, "ASCII") == 0
      || strcmp(entity_ptr->notation, "ISO646") == 0) {
    FILE *in;
    char *string = galloc(BLOCK);
    long buff_size = BLOCK;
    long string_len = 0;
    int temp;
    char *filename = entity_ptr->filename;

    if (filename == NULL)
      error(EXIT, 0, "unable to open external entity\n");

    /* skip over the GI added by nsgmls.  */
    while (*filename != '>' && *filename != '\0')
      filename++;
    if (*filename == '\0')
      {
	error (EXIT, errno, "expecting a GI prefixed to %s",
	       entity_ptr->filename);
      }
    filename++;

    if ((in = fopen(filename, "r")) == NULL)
      error(EXIT, errno, "unable to open %s", filename);
    
    /* read the file into a string.  */
    while ((temp = fgetc(in)) != EOF) {
      if (!gf_isascii(temp)) {
	error(EXIT, 0, "non-ASCII character %d in %s", 
	      (unsigned char) temp, filename);
      }
      string[string_len] = temp;
      if (++string_len == buff_size) {
	buff_size += BLOCK;
	string = grealloc(string, buff_size);
      }
    }
    string[string_len] = '\0';
    if (fclose(in) != 0)
      error(WARN, 0, "failed to close %s", filename);

    /* process the string as usual.  */
    smemo_chars(stack, depth, string);

    gfree(string);
  }
  else {
    error(EXIT, 0, "%s: notation %s is not supported in this context",
	  entity_ptr->filename, entity_ptr->notation);
  }
}

/* Process a text string.  */
void smemo_chars(struct stack *stack, int depth, char *string)
{
  if (output.discard_text) {
    /* Don't call print_escaped while discarding text: it can introduce
     * wraps etc.
     */
    return;
  }
  if (!(text.contents->respect_spaces && text.contents->preserve_breaks)) {
    tidy_string(string, text.contents->respect_spaces,
		text.contents->preserve_breaks);
     if (!text.contents->respect_spaces && text.new_par)
       strip_leading_blanks(string);
  }
  string = replace_sdata(string, &sdata, text.contents->tt,
			 text.contents->math);

  print_escaped(string, dtd.sent_blanks, text.contents->tt,
		text.contents->math);
}

int smemo_end()
{
  dtd.pass++;

  /* Two passes through the document are usually needed.  */
  if (dtd.pass > 2)
    return(1); /* Finished.  */
  else 
    return(0); /* Do another pass.  */
}
