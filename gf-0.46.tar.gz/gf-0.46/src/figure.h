/* Header for figures.  */

struct figure {
  int fig_counter;		/* Count of figure number.  */
  int got_fig_caption;		/* Whether current figure has a caption.  */
  int got_PostScript;		/* Whether the document contains one or more
				 * PostScript figures.
				 */
};

extern struct figure figure;

extern void init_figure(void);
extern void start_gen_fig(struct stack *stack, int depth);
extern void end_gen_fig(struct stack *stack, int depth);
extern void end_gen_figbody(struct stack *stack, int depth);
extern void start_gen_artwork(struct stack *stack, int depth);
extern void start_gen_figcap(struct stack *stack, int depth);

extern void start_fig(struct stack *stack, int depth, int store);
extern void end_fig(struct stack *stack, int depth);
extern void start_figbody(struct stack *stack, int depth, int store);
extern void start_figcap(struct stack *stack, int depth);
extern void end_figcap(struct stack *stack, int depth);
