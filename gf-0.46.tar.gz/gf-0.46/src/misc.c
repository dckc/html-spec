/* Miscellaneous utilities.
 * Copyright (C) 1993, 1994, 1995, Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

/* Need **environ and stat() from POSIX 1003.1.  */
#define _POSIX_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include <time.h>
#ifdef HAVE_UNISTD_H
# include <unistd.h>
#endif
#include <errno.h>

#include "gf.h"

/* Check whether a given file exists. Returns 1 if exists, 0 if not.  */
int exists(char *file_name)
{
  struct stat file_info;
    
  if (stat(file_name, &file_info) == 0)
    return 1;
  else 
    return 0;
}

/* Check whether a given file exists in the user's library directory.
 * Returns pointer to full file name if exists, else NULL.
 */
char *exists_user_dir(char *file_name) 
{
  char *temp = galloc(strlen(userdir) + 1 + strlen(file_name) + 1);

  sprintf(temp, "%s/%s", userdir, file_name);
  if (exists(temp)) {
    verbose(temp, OK, READ);
    return(temp);
  }
  verbose(temp, FAIL, READ);
  gfree(temp);

  return(NULL);
}

/* Check whether a given file exists in the system library directory.
 * Returns pointer to full file name if exists, else NULL.
 */
char *exists_system_dir(char *file_name)
{
  char *temp = galloc(strlen(libdir) + 1
		      + strlen(file_name) + 1);
  sprintf(temp, "%s/%s", libdir, file_name);
  if (exists(temp)) {
    verbose(temp, OK, READ);
    return(temp);
  }
  verbose(temp, FAIL, READ);
  gfree(temp);
  return(NULL);
}

/* Compare the modification times of two files.  Return the number of
 * seconds difference time(file1) - time(file2).
 */
double diff_filetime(char *file1, char *file2)
{
  struct stat file1_info, file2_info;
    
  if (stat(file1, &file1_info) != 0)
    error(EXIT, errno, "Couldn't get attributes of %s", file1);
  if (stat(file2, &file2_info) != 0)
    error(EXIT, errno, "Couldn't get attributes of %s", file2);

#ifdef HAVE_DIFFTIME
  return difftime(file1_info.st_mtime, file2_info.st_mtime);
#else
  return file1_info.st_mtime - file2_info.st_mtime;
#endif
}

/* Safer version of malloc: dies if out of memory.  */
void *galloc(size_t size)
{
  void *block;

  errno = 0;
  block = malloc(size);
  if (block == NULL) {
    error(EXIT, 0, "failed to obtain requested memory (%ld bytes)", 
	  (long) size);
  }
  return(block);
}

void gfree(void *block)
{
  errno = 0;
  free(block);
  if (errno != 0)
    error(WARN, 0, "free() failed");
}

/* Reallocate a block of memory to size bytes.  */
void *grealloc(void *block, size_t size)
{
  void *new_block;

  errno = 0;
  new_block = (void *) realloc(block, size);
  if (new_block == NULL) {
    error(EXIT, 0, "failed to obtain requested memory (%ld bytes)", 
	  (long) size);
  }
  return(new_block);
}

/* Read a string from an input stream. The string
 * is terminated by EOF or any of the characters
 * in sep_chars, if this is not equal to NULL.
 * The last character read (the terminator) is written to *last_char,
 * if this is not NULL.
 * An internal buffer is maintained and automatically expanded
 * as necessary to handle long strings. Unexpected errors cause
 * the program to abort.
 */

/* Specify how much memory to grab in each chunk.  */
#define BLOCK 100

char *read_string(FILE *stream, char *sep_chars, int *last_char) 
{
  static char *string;
  static int buff_size = 0;
  int string_len;
  int done;
  int ch;

  if (buff_size == 0) {
    buff_size = BLOCK;
    string = galloc(buff_size);
  }

  string_len = 0;
  done = 0;
  while (done == 0) {
    if (string_len + 1 >= buff_size) {
      buff_size += BLOCK;
      string = grealloc(string, buff_size);
    }
    string[string_len] = ch = getc(stream);    
    if (ch == EOF) {
      if (ferror(stream))
	error(EXIT, 0, "file error in read_string()");
      if (last_char != NULL) 
	*last_char = EOF;
      done = 1;
    }
    else if (sep_chars != NULL
	     && strchr(sep_chars, string[string_len]) != NULL) {
      if (last_char != NULL)
	*last_char = string[string_len];
      done = 1;
    }
    else 
      string_len++;
  }
  string[string_len] = '\0';

  return(string);
}

/* Skip over any characters in the input stream in the set `sep_chars'.
 * Returns the first character not in the set, after putting it back
 * on the stream.
 */
int skip_chars(FILE *stream, char *sep_chars)
{
  int ch;

  if (sep_chars == NULL)
    error(EXIT, 0, "bad call to skip_chars");
  
  while(1) {
    ch = getc(stream);
    /* Should be safe even with EOF.  */
    if (strchr(sep_chars, ch) == NULL) {
      ungetc(ch, stream);
      return(ch);
    }
  }
}

/* Convert a string to lower case.  */
void lower_case(char *string)
{
  char *ch = string;
  
  while(*ch != '\0') {
    if (isupper(*ch))
      *ch = tolower(*ch);
    ch++;
  }
}

/* Case insensitive version of strcmp.  */
int ci_strcmp(char *s1, char *s2)
{
  int c1, c2;
  do {
    c1 = tolower((int)(unsigned char) *s1++);
    c2 = tolower((int)(unsigned char) *s2++);
    if (c1 == '\0')
        return c1 - c2;
  }
  while (c1 == c2);

  return c1 - c2;
}

/* Print a file name, when in verbose mode.  */
void verbose(char *file_name, enum success status, enum io_mode mode)
{
  if (c_line.verbose) {
    if (mode == WRITE)
      fputs("->", stderr);
    fprintf(stderr, "%s", file_name);
    if (status == FAIL)
      fputs(" (failed)", stderr);
    fputc('\n', stderr);
  }
}

/* Print a command when in verbose mode.  */
void verbose_command(char *command)
{
  if (c_line.verbose) {
    fprintf(stderr, "Executing: %s\n", command);
  }
}

/* Print a putenv call when in verbose mode.  */
void verbose_putenv(char *str)
{
  if (c_line.verbose) {
    fprintf(stderr, "%s\n", str);
  }
}
