/* Header for tables.  */

struct table {
  /* Linked list with the number of columns in the current and any nested
   * tables.
   */
  struct tbl_cols {
    int cols;			/* Number of columns.  */
    struct tbl_cols *prev;	/* Pointer to parent table.  */
  } *tbl_cols;
};

extern struct table table;

/* Footer rows for one or more tables from the general DTD. Each link
 * contains data for a single table, which consists of a linked list
 * of footer rows.
 */
struct gen_tbl_foot {
  struct tbl_foot_row {
    char *tbl_foot;
    struct tbl_foot_row *next;
  } tbl_foot_row;
  struct gen_tbl_foot *prev;
};

extern struct gen_tbl_foot *gen_tbl_foot;

extern void init_table(void);
extern void start_gen_table(struct stack *stack, int depth);
extern void end_gen_table(struct stack *stack, int depth);
extern void start_gen_foot_row(struct stack *stack, int depth);
extern void end_gen_foot_row(struct stack *stack, int depth);
