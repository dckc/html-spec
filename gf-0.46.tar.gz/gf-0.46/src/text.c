/* Text phrases, lines, paragraphs, short quotations etc.
 * Copyright (C) 1993, 1994, 1996 Gary Houston
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "text.h"

struct text text;

/* Initialize text data structures.  */
void init_text(void)
{
  static int first = 1;		/* First time here?  */

  text.par_pending = 0;
  text.aline_pending = 0;
  text.new_par = 0;

  /* Set the default text mode (only on the first pass).  */
  if (first) {
    text.contents = NULL;
    set_text_mode(0, 0, 0, 0);
    first = 0;
  }
}

/* Set the text mode for the current element (this describes the element
 * contents in the source document).
 */
void set_text_mode(int tt, int math, int respect_spaces,
		   int preserve_breaks)
{
  /* Save the current text contents list.  */
  struct contents *old_list = text.contents;
    
  /* Push a new link on to the list.  */
  text.contents = galloc(sizeof(struct contents));
  
  /* Initialize the data.  */
  text.contents->tt = tt;
  text.contents->math = math;
  text.contents->respect_spaces = respect_spaces;
  text.contents->preserve_breaks = preserve_breaks;
  text.contents->prev = old_list;
}

/* Restore the previous text mode.  */
void restore_text_mode(void)
{
  /* Save the previous text contents list.  */
  struct contents *old_list = text.contents->prev;
    
  /* Free the current link.  */
  gfree(text.contents);
  
  /* Restore the previous link.  */
  text.contents = old_list;
}

/* Set the default text mode (as in the first text contents link).  */
void default_text_mode(void)
{
  struct contents *ptr = text.contents; /* Finds the first link.  */

  /* Find the first link.  */
  while (ptr->prev != NULL)
    ptr = ptr->prev;

  /* Set the mode.  */
  set_text_mode(ptr->tt, ptr->math, ptr->respect_spaces, ptr->preserve_breaks);
}

void start_paragraph(struct stack *stack, int depth)
{
  /* Usually only want to emit paragraph separation code 
   * between paragraphs, not each time a paragraph starts.
   * E.g., not at beginning of each list item.
   */
  if (text.par_pending)
    output.need_par = 1;
  
  text.new_par = 1;
}

void end_paragraph(struct stack *stack, int depth)
{
  /* Need_par should be set to zero by any other closing element,
   * or by an opening element other than a paragraph.
   */
  text.par_pending = 1;
}

void start_shortquote(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX || c_line.setter == TEXINFO) {
    gfputs("``");
    /* If the next character printed is an opening single quote, a
     * thinspace will be inserted by the output routine.
     */
    output.done_open_quote = 1;
  }
  else if (c_line.family == FAM_PLAIN || c_line.setter == RTF)
    gfputs("\"");
}

void end_shortquote(struct stack *stack, int depth)
{
  if (output.done_apost == 1) {
    /* If the last character printed was an apostrophe, need to insert extra
     * thin space.
     */
    if (c_line.family == FAM_TEX)
      gfputs("\\thinspace");
    else if (c_line.setter == TEXINFO) {
      gfputs("@iftex");
      output.need_wrap = 1;
      gfputs("@thinspace");
      output.need_wrap = 1;
      gfputs("@end iftex");
      output.need_wrap = 1;
    }
  }
  if (c_line.family == FAM_TEX || c_line.setter == TEXINFO)
    gfputs("''");
  else if (c_line.family == FAM_PLAIN || c_line.setter == RTF)
    gfputs("\"");
}

/* Highlighted phrases, including those defined through
 * architectural forms.
 */
void start_phrase(struct stack *stack, int depth)
{
  char *element = stack->element;

  if (c_line.family == FAM_TEX) {
    if (strcmp(element, "HP0") == 0)
      gfputs("\\hpzero{");
    else if (strcmp(element, "HP1") == 0)
      gfputs("\\hpone{");
    else if (strcmp(element, "HP2") == 0)
      gfputs("\\hptwo{");
    else if (strcmp(element, "HP3") == 0)
      gfputs("\\hpthree{");
    else 
      gfprintf("\\phrase{%s}{", element);
  }
  else if (c_line.family == FAM_PLAIN) {
    char *delim;

    if (strcmp(element, "HP0") == 0)
      delim = check_style("hp0-delimiter");
    else if (strcmp(element, "HP1") == 0)
      delim = check_style("hp1-delimiter");
    else if (strcmp(element, "HP2") == 0)
      delim = check_style("hp2-delimiter");
    else if (strcmp(element, "HP3") == 0)
      delim = check_style("hp3-delimiter");
    else
      delim = check_style("phrase-delimiter");
    gfputs(delim);
  }
  else if (c_line.setter == RTF) {
    char *font;
    char *style;

    if (strcmp(element, "HP0") == 0) {
      font = check_style("fhp0");
      style = check_style("shp0");
    }
    else if (strcmp(element, "HP1") == 0) {
      font = check_style("fhp1");
      style = check_style("shp1");
    }
    else if (strcmp(element, "HP2") == 0) {
      font = check_style("fhp2");
      style = check_style("shp2");
    }
    else if (strcmp(element, "HP3") == 0) {
      font = check_style("fhp3");
      style = check_style("shp3");
    }
    else {
      font = check_style("fphrase");
      style = check_style("sphrase");
    }
    gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
  }
  else if (c_line.setter == TEXINFO)
    gfputs("@emph{");
}

void end_phrase(struct stack *stack, int depth)
{
  char *element = stack->element;

  if (c_line.family == FAM_TEX || c_line.setter == TEXINFO)
    gfputs("}");
  else if (c_line.family == FAM_PLAIN) {
    char *delim;

    if (strcmp(element, "HP0") == 0)
      delim = check_style("hp0-delimiter");
    else if (strcmp(element, "HP1") == 0)
      delim = check_style("hp1-delimiter");
    else if (strcmp(element, "HP2") == 0)
      delim = check_style("hp2-delimiter");
    else if (strcmp(element, "HP3") == 0)
      delim = check_style("hp3-delimiter");
    else
      delim = check_style("phrase-delimiter");
    gfputs(delim);
  }
  else if (c_line.setter == RTF)
    gfprintf("}%s", output.new_par);
}

/* Emphasized text: similar to hp.  */
void start_emphasize(struct stack *stack, int depth)
{
  if (c_line.setter == LATEX2E)
    gfputs("\\emph{");
  else if (c_line.family == FAM_PLAIN) {
    char *delim;

    delim = check_style("em-delimiter");
    gfputs(delim);
  }
  else if (c_line.setter == RTF) {
    char *font;
    char *style;

    font = check_style("fem");
    style = check_style("sem");

    gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
  }
}

void end_emphasize(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX)
    gfputs("}");
  else if (c_line.family == FAM_PLAIN) {
    char *delim;

    delim = check_style("em-delimiter");
    gfputs(delim);
  }
  else if (c_line.setter == RTF)
    gfprintf("}%s", output.new_par);
}

/* Explicit bold text.  */
void start_bold(struct stack *stack, int depth)
{
  if (c_line.setter == LATEX2E)
    gfputs("\\textbf{");
  else if (c_line.family == FAM_PLAIN) {
    char *delim = check_style("bold-delimiter");

    gfputs(delim);
  }
  else if (c_line.setter == RTF) {
    char *font;
    char *style;

    font = check_style("fbold");
    style = check_style("sbold");

    gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
  }
}

void end_bold(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX)
    gfputs("}");
  else if (c_line.family == FAM_PLAIN) {
    char *delim = check_style("bold-delimiter");

    gfputs(delim);
  }
  else if (c_line.setter == RTF)
    gfprintf("}%s", output.new_par);
}

/* Explicit italic text.  */
void start_italic(struct stack *stack, int depth)
{
  if (c_line.setter == LATEX2E)
    gfputs("\\textit{");
  else if (c_line.family == FAM_PLAIN) {
    char *delim = check_style("italic-delimiter");

    gfputs(delim);
  }
  else if (c_line.setter == RTF) {
    char *font;
    char *style;

    font = check_style("fitalic");
    style = check_style("sitalic");

    gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
  }
}

void end_italic(struct stack *stack, int depth)
{
  if (c_line.setter == LATEX2E)
    gfputs("}");
  else if (c_line.family == FAM_PLAIN) {
    char *delim = check_style("italic-delimiter");

    gfputs(delim);
  }
  else if (c_line.setter == RTF)
    gfprintf("}%s", output.new_par);
}

/* Explicit underlined text.  */
void start_underline(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX)
    gfputs("\\underline{");
  else if (c_line.family == FAM_PLAIN) {
    char *delim = check_style("underline-delimiter");

    gfputs(delim);
  }
  else if (c_line.setter == RTF) {
    char *font;
    char *style;

    font = check_style("funderline");
    style = check_style("sunderline");

    gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
  }
}

void end_underline(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX)
    gfputs("}");
  else if (c_line.family == FAM_PLAIN) {
    char *delim = check_style("underline-delimiter");

    gfputs(delim);
  }
  else if (c_line.setter == RTF)
    gfprintf("}%s", output.new_par);
}

/* Program code embedded in the text.  */
void start_code_inline(struct stack *stack, int depth)
{
  char *element = stack->element; /* Name of the element.  */

  if (c_line.family == FAM_TEX)
    gfprintf("\\code{%s}{", element);
  else if (c_line.family == FAM_PLAIN) {
    char *delimiter = check_style("code-delimiter-intext-l");

    gfputs(delimiter);
  }
  else if (c_line.setter == RTF) {
    char *font = check_style("fcode");
    char *style = check_style("scode");
  
    gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
  }
  else if (c_line.setter == TEXINFO)
    gfputs("@samp{");

  /* Typewriter font, but do not respect spaces or line breaks.  */
  set_text_mode(1, 0, 1, 0);
}

void end_code_inline(struct stack *stack, int depth)
{
  restore_text_mode();
  if (c_line.family == FAM_TEX || c_line.setter == TEXINFO)
    gfputs("}");
  else if (c_line.family == FAM_PLAIN) {
    char *delimiter = check_style("code-delimiter-intext-r");

    gfputs(delimiter);
  }
  else if (c_line.setter == RTF)
    gfprintf("}%s", output.new_par);

  text.par_pending = 0;
}
