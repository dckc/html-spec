/* Header for list elements.  */

struct list {
  /* Linked list with data for each currently open list element. Lists can
   * be nested in many DTDs. This is only needed for primitive formatters
   * like ASCII.
   */
  struct list_node {
    /* Type of list.  Values are: ordered, unordered, simple, tagged (others
     * are currently only supported for LaTeX).
     */
    char *type;
    int count;			/* Counter if node is an ordered list.  */
    int compact;		/* 1 for compact list, 0 otherwise.  */
    struct list_node *prev;	/* The first link never gets used.  */
    struct list_node *next;
  } list_node;

  int got_glossary_def;		/* Flag for 1st definition of a term.  */
  int dl_new_entry;		/* Flag for when def list needs a new entry. */
};

extern struct list list;

/* A structure which can hold the data from several nested definition lists.
 */
struct dl_info {
  /* Each definition list can have several entries.  */
  struct dl_entry {
    /* Each entry can have several terms, or "tags".  */
    struct dl_tag_list {
      char *dl_tag;
      struct dl_tag_list *next;
    } dl_tag_list;
    /* The definition or "data" for an entry.  */
    char *dl_data;
    struct dl_entry *next;
  } dl_entry;
  /* A definition list can have a single heading.  */
  struct dl_entry dl_head_info;
  /* A pointer to the parent definition list (if nested).  */
  struct dl_info *prev;
};

/* Likewise for nested unstructured definition lists.  */
struct uns_dl_info {
  /* Compact flag specifies the list style.  */
  int compact;
  /* Each definition list can have several entries.  */
  struct uns_dl_entry {
    /* Each entry can be a term ("tag") or a definition ("data").  */
    char *dl_tag;
    char *dl_data;
    struct uns_dl_entry *next;
  } uns_dl_entry;
  /* A pointer to the parent list (if nested).  */
  struct uns_dl_info *prev;
};

extern struct dl_info *dl_info;
extern struct uns_dl_info *uns_dl_info;

extern void init_list(void);
extern void start_ordered_list(struct stack *stack, int depth, int store,
			       int compact);
extern void end_ordered_list(struct stack *stack, int depth, int store);
extern void start_unordered_list(struct stack *stack, int depth, int compact);
extern void end_unordered_list(struct stack *stack, int depth);
extern void start_simple_list(struct stack *stack, int depth);
extern void end_simple_list(struct stack *stack, int depth);
extern void start_list_item(struct stack *stack, int depth, int store);
extern void end_list_item(struct stack *stack, int depth);

extern void start_tagged_list(struct stack *stack, int depth);
extern void end_tagged_list(struct stack *stack, int depth);
extern void start_tagged_list_tag(struct stack *stack, int depth);
extern void end_tagged_list_tag(struct stack *stack, int depth);

extern void start_glossary_list(struct stack *stack, int depth);
extern void end_glossary_list(struct stack *stack, int depth);
extern void start_glossary_tag(struct stack *stack, int depth);
extern void end_glossary_tag(struct stack *stack, int depth);
extern void start_glossary_def(struct stack *stack, int depth);

extern void start_def_list(struct stack *stack, int depth);
extern void end_def_list(struct stack *stack, int depth);
extern void start_def_tag_heading(struct stack *stack, int depth);
extern void end_def_tag_heading(struct stack *stack, int depth);
extern void start_def_data_heading(struct stack *stack, int depth);
extern void end_def_data_heading(struct stack *stack, int depth);
extern void start_def_tag(struct stack *stack, int depth);
extern void end_def_tag(struct stack *stack, int depth);
extern void start_def_data(struct stack *stack, int depth);
extern void end_def_data(struct stack *stack, int depth);

extern void start_uns_def_list(struct stack *stack, int depth, int compact);
extern void end_uns_def_list(struct stack *stack, int depth);
extern void start_uns_def_tag(struct stack *stack, int depth);
extern void end_uns_def_tag(struct stack *stack, int depth);
extern void start_uns_def_data(struct stack *stack, int depth);
extern void end_uns_def_data(struct stack *stack, int depth);
