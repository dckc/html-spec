/* Routines for the spaper formatters.
 * Copyright (C) 1993-1996 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 *
 * Public functions: spaper_element_start,
 * spaper_element_end, spaper_x_ent, spaper_chars, spaper_end.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include "gf.h"
#include "text.h"
#include "structure.h"
#include "header.h"
#include "displayed.h"
#include "link.h"
#include "list.h"
#include "table.h"
#include "math.h"
#include "figure.h"
#include "index.h"

/* Translations for mapping SDATA to output.  */
static struct sdata_table sdata;

/* Data local to this DTD.  */
static struct {
  int pass;			/* Pass number through the document.  */
  int version;			/* Version of the DTD.  */
  int sent_blanks;		/* Blanks after each "sentence": 1 or 2.  */
  struct name {
    char *name;			/* One author name.  */
    char *address_id;		/* ID of the address for this name, if any.  */
    struct name *next;		/* Pointer to the next author.  */
  } names;
  struct address {
    char *address;		/* Author address.  */
    char *id;			/* ID of this address.  */
    int name_number;		/* Which name this is contained within.  */
    struct address *next;	/* Pointer to the next address.  */
  } addresses;
} dtd;

/* Initialise data structures (once).  */
static void dtd_init(struct stack *stack, int depth)
{
  /* Version number.  */
  struct attr *version_ptr = query_attribute(stack, "VERSION");
  char *dummy;			/* Dummy pointer.  */
  char *ext;			/* Extension for SDATA files.  */

  dtd.pass = 1;			/* 1st pass through document.  */

  output.discard_text = 1;	/* Don't print text on first pass.  */

  xlink.cross_ref.next = NULL; /* Linked list for cross-ref information.  */

  dtd.names.next = NULL;
  dtd.names.address_id = NULL;
  dtd.addresses.next = NULL;
  dtd.addresses.id = NULL;

  if (version_ptr == NULL)
    dtd.version = 3;		/* Versions 2 and 3 had incorrect DTD.  */
  else
    dtd.version = strtol(version_ptr->values, &dummy, 10);

  /* Initialize data structures.  These also get called at the beginning
   * of the second pass.
   */
  init_text();
  init_structure();
  init_display();
  init_figure();
  init_header();		/* Don't call this again.  */
  init_list();

  if (c_line.family == FAM_TEX) {
    char *width = check_style("line-width");

    output.line_width = strtol(width, &dummy, 10); /* Auto line breaking.  */
    ix.need_index = 0;

    ext = ".2tex";
  }
  else if (c_line.family == FAM_PLAIN) {
    char *temp = check_style("line-width");

    output.line_width = strtol(temp, &dummy, 10); /* Auto line breaking.  */

    /* Find how many blanks should be printed after each sentence-like
     * construction.
     */
    if (strcmp(check_style("sent-spacing"), "single") == 0)
      dtd.sent_blanks = 1;
    else
      dtd.sent_blanks = 2;

    if (c_line.setter == AB)
      ext = ".2ab";
    else if (c_line.setter == AS)
      ext = ".2as";
    else if (c_line.setter == L1B)
      ext = ".2l1b";
    else if (c_line.setter == L1S)
      ext = ".2l1s";
  }
  else if (c_line.setter == RTF) {
    char *font_link = check_style("fpar");    /* Paragraph font link.  */
    char *style_link = check_style("spar");   /* Paragraph style link.  */

    output.line_width = 50000;	/* An output line can be this long.
				 * If a line was longer, a blank would be lost.
				 */

    /* Set up the text for new paragraphs.  */
    output.new_par = galloc(strlen("{\\pard\\plain\\f\\s ") +
			    strlen(font_link) + strlen(style_link) + 1);
    sprintf(output.new_par, "{\\pard\\plain\\f%s\\s%s ", font_link,
	    style_link);

    /* Find how many blanks should be printed after each sentence-like
     * construction.
     */
    if (strcmp(check_style("sent-spacing"), "single") == 0)
      dtd.sent_blanks = 1;
    else
      dtd.sent_blanks = 2;

    ext = ".2rtf";
  }
  else if (c_line.setter == TEXINFO) {
    output.line_width = 0;	/* Never use auto line breaking.  */
    text.contents->preserve_breaks = 1;  /* Wrap lines as in source doc.  */
    dtd.sent_blanks = 2;

    ext = ".2texi";
  }
  else {
    error(EXIT, 0, "formatter `%s' is not supported for %s",
	  setter_names[c_line.setter], dtd_names[c_line.dtd]);
  }

  /* Read SDATA translation tables.  */
  {
    char file[20];		/* File names.  */

    sdata.next = NULL;
    get_sdata_local(ext, &sdata);

    sprintf(file, "ISOlat1%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOlat2%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOnum%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOpub%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOdia%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOtech%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "GFextra%s", ext);
    get_sdata_translations(file, &sdata);
  }
}

void spaper_element_start(struct stack *stack, int depth)
{
  char *element = stack->element;
  static int first = 1;

  if (first) {
    dtd_init(stack, depth);
    first = 0;
  }
  if (dtd.pass == 1) {
    if (c_line.family == FAM_TEX) {
      if (strcmp(element, "TOC") == 0) {
	char *toc_page = check_style("toc-page");
	
	if (strcmp(toc_page, "toc-full-title") == 0)
	  header.need_titlepage = 1;
      }
      else if (strcmp(element, "FIGLIST") == 0) {
	char *lof_page = check_style("lof-page");
	
	if (strcmp(lof_page, "lof-full-title") == 0)
	  header.need_titlepage = 1;
      }
      else if (strcmp(element, "INDEX") == 0)
	ix.need_index = 1;
      else if (strcmp(element, "FIGBODY") == 0)
	start_figbody(stack, depth, 1);
    }
    else {
      struct attr *arch_ptr = query_attribute(stack, "SARC");

      text.new_par = 0;		/* Texinfo is storing headings.  */

      if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
	int head_level = element[1] - '0';

	start_heading(stack, depth, head_level, 1);
      }
      else if (strcmp(element, "OL") == 0)
	start_ordered_list(stack, depth, 1, 0);
      else if (strcmp(element, "LI") == 0)
	start_list_item(stack, depth, 1);
      else if (strcmp(element, "FIG") == 0)
	start_fig(stack, depth, 1);
      else if (strcmp(element, "APPENDIX") == 0)
	start_appendix(stack, depth);
      else if (strcmp(element, "INDEX") == 0)
	start_index(stack, depth, 1);
      else if (dtd.version < 5 && strcmp(element, "FN") == 0)
	start_note(stack, depth, 1);
      /* Check for architectural forms.  */
      else if (arch_ptr != NULL) {
	if (c_line.setter == TEXINFO && structure.inheading) {
	  /* Texinfo: need to process %text; in headings.  */
	  if (strcmp(arch_ptr->values, "NOTE") == 0)
	    start_note(stack, depth, 0);
	  else if (strcmp(arch_ptr->values, "PHRASE") == 0)
	    start_phrase(stack, depth);
	  else if (strcmp(arch_ptr->values, "CODE") == 0)
	    start_code_inline(stack, depth);
	}
	else { /* Not Texinfo, but still process notes.  */
	  if (strcmp(arch_ptr->values, "NOTE") == 0)
	    start_note(stack, depth, 1);
	}
      }
      else if (c_line.setter == TEXINFO && structure.inheading) {
	/* Texinfo: need to process %text; in headings.  */
	if (strcmp(element, "Q") == 0)
	  start_shortquote(stack, depth);
	else if (dtd.version < 5 && strncmp(element, "HP", 2) == 0
		 && element[3] == '\0')
	  start_phrase(stack, depth);
	else if (dtd.version < 5 && strcmp(element, "CODE") == 0) {
	  char *type = check_attribute(stack, "BREAK")->values;

	  if (strcmp(type, "INTEXT") == 0)
	    start_code_inline(stack, depth);
	}
	else if (strcmp(element, "TEXEQN") == 0)
	  start_texeqn(stack, depth, 0);
      }
    }
  }
  else {      /* Pass 2.  */
    if (strcmp(element, "P") != 0) {
      text.par_pending = 0;
    }
    text.new_par = 0;
    if (strcmp(element, "P") == 0)
      start_paragraph(stack, depth);
    else if (strcmp(element, "Q") == 0)
      start_shortquote(stack, depth);
    else if (strcmp(element, "SPAPER") == 0) {
      /* Reinitialize the data structures.  */
      init_text();
      init_structure();
      init_display();
      init_figure();
      init_list();
      output.discard_text = 0;
      start_document(stack, depth);
    }
    else if (dtd.version < 5 && strcmp(element, "CODE") == 0) {
      char *type = check_attribute(stack, "BREAK")->values;

      if (strcmp(type, "INTEXT") == 0)
	start_code_inline(stack, depth);
      else
	start_code_lines(stack, depth);
    }
    else if (strcmp(element, "FIG") == 0)
      start_fig(stack, depth, 0);
    else if (strcmp(element, "FIGBODY") == 0)
      start_figbody(stack, depth, 0);
    else if (strcmp(element, "FIGCAP") == 0)
      start_figcap(stack, depth);
    else if (dtd.version < 5 && strcmp(element, "FN") == 0)
      start_note(stack, depth, 0);
    else if (strcmp(element, "OL") == 0)
      start_ordered_list(stack, depth, 0, 0);
    else if (strcmp(element, "UL") == 0)
      start_unordered_list(stack, depth, 0);
    else if (strcmp(element, "SL") == 0)
      start_simple_list(stack, depth);
    else if (strcmp(element, "TL") == 0)
      start_tagged_list(stack, depth);
    else if (strcmp(element, "LI") == 0)
      start_list_item(stack, depth, 0);
    else if (strcmp(element, "TLIT") == 0)
      start_tagged_list_tag(stack, depth);
    else if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
      int head_level = element[1] - '0';
      start_heading(stack, depth, head_level, 0);
    }
    else if (strcmp(element, "APPENDIX") == 0)
      start_appendix(stack, depth);
    else if (strcmp(element, "REF") == 0)
      start_reference(stack, depth);
    else if (strcmp(element, "HDREF") == 0 || strcmp(element, "FIGREF") == 0
	     || strcmp(element, "FNREF") == 0
	     || strcmp(element, "LIREF") == 0) {
      char *type = check_attribute(stack, "TYPE")->values;

      start_long_reference(stack, depth, strcmp(type, "NOPAGE"));
    }
    else if (dtd.version < 5 && strncmp(element, "HP", 2) == 0
	     && element[3] == '\0')
      start_phrase(stack, depth);
    else if (strcmp(element, "TEXEQN") == 0) {
      if (dtd.version < 5) {
	char *type = check_attribute(stack, "BREAK")->values;

	if (strcmp(type, "INTEXT") == 0)
	  start_texeqn(stack, depth, 0);
	else
	  start_texeqn(stack, depth, 1);
      }
      else
	start_texeqn(stack, depth, 0);
    }
    else if (strcmp(element, "TEXEQN-DISPLAY") == 0)
      start_texeqn(stack, depth, 1);
    else if (strcmp(element, "LINE") == 0)
      start_aline(stack, depth);
    else if (strcmp(element, "AUTHOR") == 0) {
      if (dtd.version < 5) {
	if (c_line.family == FAM_TEX)
	  gfputs("\\author{");
	/* Storage for other formatters is done by ALINE.  */
      }
      /* For later versions, subelements are stored in the spaper array.  */
    }
    else if (strcmp(element, "ALINE") == 0) {
      /* Prior to version 5, ALINE is used for title and author lines.
       * From version 5 it is used for address lines.
       */

      /* Hack for old documents: now want a new \author command for each line,
       * rather than separating them with \\.
       */
      if (dtd.version < 5 && strcmp(stack[-1].element, "AUTHOR") == 0
	  && c_line.family == FAM_TEX) {
	if (text.aline_pending) {
	  gfputs("}");		/* Close the current author.  */
	  output.need_wrap = 1;
	  gfputs("\\author{");
	}
      }
      else if (c_line.family == FAM_TEX) {
	/* Otherwise separate address and title lines with \\.  */
	start_aline(stack, depth);
      }
      else if (dtd.version < 5)
	start_aline(stack, depth);
      else {
	/* Otherwise, ADDRESS is being stored.  */
	if (text.aline_pending == 1)
	  gfputs(" ");
      }
    }
    else if (strcmp(element, "NAME") == 0) {
      /* <name> is used from version 5 of the DTD in AUTHOR.  */
      /* IDREF to the address.  */
      struct attr *address = query_attribute(stack, "ADDRESS");
      /* Pointer to the structure where the name will be stored.  */
      struct name *name_ptr = &dtd.names;

      /* Add a new name to the linked list.  */
      while (name_ptr->next != NULL)
	name_ptr = name_ptr->next;
      name_ptr->next = galloc(sizeof(struct name));
      name_ptr->next->next = NULL;
      name_ptr->next->address_id = NULL;
      if (address != NULL && strcmp(address->type, "IMPLIED") != 0) {
	name_ptr->address_id = galloc(strlen(address->values) + 1);
	strcpy(name_ptr->address_id, address->values);
      }
      start_storage("NAME");
    }
    else if (strcmp(element, "ADDRESS") == 0) {
      text.aline_pending = 0;
      if (dtd.version < 5) {
	/* Old versions do not allow ID and IDREF: can print directly.  */

	if (c_line.family == FAM_TEX) {
	  static int address_count = 0; /* Address number.  */

	  address_count++;
	  /* Close the \author statement then print address.  */
	  gfprintf("\\addref{%d}}\\address{%d}{", address_count,
		   address_count);
	}
	else {
	  /* Add this text to the AUTHOR storage.  */
	  start_aline(stack, depth);
	  gfputs(" (");
	}
      }
      else {
	/* Later versions.  */
	/* Get the ID of the address, if any.  */
	struct attr *id = query_attribute(stack, "ID");
	/* Pointer to the structure where the address will be stored.  */
	struct address *address_ptr = &dtd.addresses;

	/* Find the last link in the list.  */
	while (address_ptr->next != NULL)
	  address_ptr = address_ptr->next;
	/* Add a new link.  */
	address_ptr->next = galloc(sizeof(struct address));
	address_ptr->next->next = NULL;
	address_ptr->next->id = NULL;
	/* Store the ID.  */
	if (id != NULL && strcmp(id->type, "IMPLIED") != 0) {
	  address_ptr->id = galloc(strlen(id->values) + 1);
	  strcpy(address_ptr->id, id->values);
	}
	start_storage("ADDRESS");
      }
    }
    /* Address components.  */
    else if (strcmp(element, "ORG") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\org{");
    }
    else if (strcmp(element, "STREET") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\street{");
    }
    else if (strcmp(element, "CITY") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\city{");
    }
    else if (strcmp(element, "REGION") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\region{");
    }
    else if (strcmp(element, "COUNTRY") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\country{");
    }
    else if (strcmp(element, "POSTCODE") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\postcode{");
    }
    else if (strcmp(element, "POSTBOX") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\postbox{");
    }
    else if (strcmp(element, "THANKS") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\thanks{");
      else
	start_storage("THANKS");
    }
    else if (strcmp(element, "TITLE") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\title{");
      else if (dtd.version < 4)
	start_storage("TITLE");
      /* storage for other formatters for later DTDs is done by LINE.  */
    }
    else if (strcmp(element, "DATE") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\date{");
      else
	start_storage("DATE");
    }
    else if (strcmp(element, "DOCNUM") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\docnum{");
      else
	start_storage("DOCNUM");
    }
    else if (strcmp(element, "TOC") == 0)
      start_toc(stack, depth);
    else if (strcmp(element, "FIGLIST") == 0)
      start_lof(stack, depth);
    else if (strcmp(element, "INDEX") == 0)
      start_index(stack, depth, 0);
    else if (strcmp(element, "IX") == 0)
      start_index_entry(stack, depth);
    else if (strcmp(element, "ABSTRACT") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\gfabstract{");
      else
	start_storage("ABSTRACT");
    }
    else if (strcmp(element, "COPYRITE") == 0)
      start_copyrite(stack, depth);
    else if (strcmp(element, "NOPRINT") == 0)
      start_copy_noprint(stack, depth);
    else if (strcmp(element, "BODY") == 0) {
      /* Write the complete title.  */
      if (c_line.family == FAM_TEX) {
	char *toc_page = check_style("toc-page");
	char *lof_page = check_style("lof-page");

	/* Print the author and address information.  */
	if (dtd.version > 4) {
	  /* Pointer to the stored author names.  */
	  struct name *name_ptr = &dtd.names;
	  /* Pointer to the stored address information.  */
	  struct address *address_ptr;
	  int name_count = 0;	/* Counts the name lines.  */
	  int address_count;	/* Counts the address lines.  */
	  int found;		/* Whether address has been found.  */
	 
	  while (name_ptr->next != NULL) {
	    gfprintf("\\author{%s", name_ptr->name);
	    /* If this name has an address IDREF, find the corresponding
	     * address.  Otherwise, find an address with this name number.
	     */
	    address_ptr = &dtd.addresses;
	    address_count = 0;
	    found = 0;
	    while (address_ptr->next != NULL) {
	      address_count++;
	      if (name_ptr->address_id != NULL) {
		if (strcmp(name_ptr->address_id, address_ptr->id) == 0) {
		  gfprintf("\\addref{%d}", address_count);
		  found = 1;
		}
	      }
	      else {
		if (address_ptr->name_number == name_count) {
		  gfprintf("\\addref{%d}", address_count);	
		  found = 1;
		}
	      }
	      address_ptr = address_ptr->next;
	    }
	    if (name_ptr->address_id != NULL && found == 0) {
	      error(WARN, 0, "missing address with id=%s", 
		    name_ptr->address_id);
	    }
	    name_ptr = name_ptr->next;
	    name_count++;
	    gfputs("}");
	    output.need_wrap = 1;
	  }
	  /* Print the address lines.  */
	  address_ptr = &dtd.addresses;
	  address_count = 0;
	  while (address_ptr->next != NULL) {
	    address_count++;
	    gfprintf("\\address{%d}{%s}", address_count, address_ptr->address);
	    output.need_wrap = 1;
	    address_ptr = address_ptr->next;
	  }
	}
	if (ix.need_index) {
	  gfputs("\\makeindex");
	  output.need_wrap = 1;
	}
	gfputs("\\begin{document}");
	output.need_wrap = 1;
	if (strcmp(toc_page, "toc-always") == 0) {
	  gfputs("\\gftoc");
	  header.need_titlepage = 1;
	  output.need_wrap = 1;
	}
	if (strcmp(lof_page, "lof-always") == 0) {
	  gfputs("\\gflof");
	  header.need_titlepage = 1;
	  output.need_wrap = 1;
	}
	if (header.need_titlepage)
	  gfputs("\\gftitlepage");
	else
	  gfputs("\\gfmaketitle");

	output.need_wrap = 1;
      }
      else if (c_line.family == FAM_PLAIN) {
	struct stored_text *link = &stored_text; /* Steps through list.  */
	int got_date = 0;	/* Whether date line has been found.  */

	output.alignment = CENTRE; /* Centre the header text.  */
	/* For each type of heading, search the stored text.  */
	while (link->next != NULL) {
	  if (strcmp(link->key, "TITLE") == 0) {
	    gfputs(link->text);
	    output.need_wrap = 1;
	  }
	  link = link->next;
	}
	if (dtd.version < 5) {
	  link = &stored_text;
	  while (link->next != NULL) {
	    if (strcmp(link->key, "AUTHOR") == 0) {
	      gfputs(link->text);
	      output.need_wrap = 1;
	    }
	    link = link->next;
	  }
	}
	else {
	  /* Pointer to the stored author names.  */
	  struct name *name_ptr = &dtd.names;
	  /* Pointer to the stored address information.  */
	  struct address *address_ptr;
	  int name_count = 0;	/* Counts the name lines.  */
	  int address_count;	/* Counts the address lines.  */
	  int found;		/* Whether address has been found.  */
	 
	  while (name_ptr->next != NULL) {
	    gfputs(name_ptr->name);
	    /* If this name has an address IDREF, find the corresponding
	     * address.  Otherwise, find an address with this name number.
	     */
	    address_ptr = &dtd.addresses;
	    address_count = 0;
	    found = 0;
	    while (address_ptr->next != NULL) {
	      address_count++;
	      if (name_ptr->address_id != NULL) {
		if (strcmp(name_ptr->address_id, address_ptr->id) == 0) {
		  gfprintf("(%d)", address_count);
		  found = 1;
		}
	      }
	      else {
		if (address_ptr->name_number == name_count) {
		  gfprintf("(%d)", address_count);	
		  found = 1;
		}
	      }
	      address_ptr = address_ptr->next;
	    }
	    if (name_ptr->address_id != NULL && found == 0) {
	      error(WARN, 0, "missing address with id=%s", 
		    name_ptr->address_id);
	    }
	    name_ptr = name_ptr->next;
	    name_count++;
	    output.need_line = 1;
	  }
	  /* Print the address lines.  */
	  address_ptr = &dtd.addresses;
	  address_count = 0;
	  while (address_ptr->next != NULL) {
	    address_count++;
	    gfprintf("(%d) %s", address_count, address_ptr->address);
	    output.need_line = 1;
	    address_ptr = address_ptr->next;
	  }
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "DATE") == 0) {
	    gfputs(link->text);
	    output.need_wrap = 1;
	    got_date = 1;
	  }
	  link = link->next;
	}
	if (got_date == 0) {
	  /* Put today's date.  */
	  time_t second;
	  struct tm *local;
	  char ftime[30];
	  char *datesty = check_style("datesty");
	  time(&second);
	  local = localtime(&second);
	  if (strcmp(datesty, "ddmonthyyyy") == 0) 
	    strftime(ftime, 30, "%d %B %Y", local);
	  else if (strcmp(datesty, "monthddyyyy") == 0)
	    strftime(ftime, 30, "%B %d, %Y", local);
	  else if (strcmp(datesty, "slashddmmyy") == 0)
	    strftime(ftime, 30, "%d/%m/%y", local);
	  else if (strcmp(datesty, "slashmmddyy") == 0)
	    strftime(ftime, 30, "%m/%d/%y", local);
	  else if (strcmp(datesty, "ISO") == 0)
	    strftime(ftime, 30, "%Y-%m-%d", local);
	  
	  gfputs(ftime);
	  output.need_wrap = 1;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "ABSTRACT") == 0) {
	    output.need_gap = 1;
	    gfputs("Abstract");
	    output.need_gap = 1;
	    gfputs(link->text);
	    output.need_gap = 1;
	  }
	  link = link->next;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "COPYRITE") == 0) {
	    output.need_gap = 1;
	    gfputs(link->text);
	    output.need_gap = 1;
	  }
	  link = link->next;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "THANKS") == 0) {
	    output.need_gap = 1;
	    gfputs(link->text);
	    output.need_gap = 1;
	  }
	  link = link->next;
	}
	link = &stored_text;
	output_flush();	         /* Flush any pending centred text.  */
	output.alignment = LEFT; /* Reset to left alignment.  */
	while (link->next != NULL) {
	  if (strcmp(link->key, "DOCNUM") == 0) {
	    gfprintf("ref: %s", link->text);
	    output.need_wrap = 1;
	  }
	  link = link->next;
	}
	output.need_gap = 1;
      }
      else if (c_line.setter == RTF) {
	char *font;
	char *style;
	struct stored_text *link = &stored_text;
	int got_date = 0;	/* Whether date line has been found.  */

	/* For each type of heading, search the stored text.  */
	font = check_style("ftitle");
	style = check_style("stitle");
	while (link->next != NULL) {
	  if (strcmp(link->key, "TITLE") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s\\qc %s",
		     font, style, link->text);
	    output.need_line = 1;
	  }
	  link = link->next;
	}
	font = check_style("fsub");
	style = check_style("ssub");
	if (dtd.version < 5) {
	  link = &stored_text;
	  while (link->next != NULL) {
	    if (strcmp(link->key, "AUTHOR") == 0) {
	      gfprintf("}{\\pard\\plain\\f%s\\s%s\\qc %s",
		       font, style, link->text);
	      output.need_line = 1;
	    }
	    link = link->next;
	  }
	}
	else {
	  /* Pointer to the stored author names.  */
	  struct name *name_ptr = &dtd.names;
	  /* Pointer to the stored address information.  */
	  struct address *address_ptr;
	  int name_count = 0;	/* Counts the name lines.  */
	  int address_count;	/* Counts the address lines.  */
	  int found;		/* Whether address has been found.  */
	 
	  while (name_ptr->next != NULL) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s\\qc %s",
		     font, style, name_ptr->name);
	    /* If this name has an address IDREF, find the corresponding
	     * address.  Otherwise, find an address with this name number.
	     */
	    address_ptr = &dtd.addresses;
	    address_count = 0;
	    found = 0;
	    while (address_ptr->next != NULL) {
	      address_count++;
	      if (name_ptr->address_id != NULL) {
		if (strcmp(name_ptr->address_id, address_ptr->id) == 0) {
		  gfprintf("(%d)", address_count);
		  found = 1;
		}
	      }
	      else {
		if (address_ptr->name_number == name_count) {
		  gfprintf("(%d)", address_count);	
		  found = 1;
		}
	      }
	      address_ptr = address_ptr->next;
	    }
	    if (name_ptr->address_id != NULL && found == 0) {
	      error(WARN, 0, "missing address with id=%s", 
		    name_ptr->address_id);
	    }
	    name_ptr = name_ptr->next;
	    name_count++;
	    output.need_line = 1;
	  }
	  /* Print the address lines.  */
	  address_ptr = &dtd.addresses;
	  address_count = 0;
	  while (address_ptr->next != NULL) {
	    address_count++;
	    gfprintf("}{\\pard\\plain\\f%s\\s%s\\qc(%d) %s",
		     font, style, address_count, address_ptr->address);
	    output.need_line = 1;
	    address_ptr = address_ptr->next;
	  }
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "DATE") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s\\qc %s",
		  font, style, link->text);
	    output.need_line = 1;
	    got_date = 1;
	  }
	  link = link->next;
	}
	if (got_date == 0) {
	  /* Always use the current date.  */
	  gfprintf("}{\\pard\\plain\\f%s\\s%s\\qc\\chdate",
		   font, style);
	  output.need_line = 1;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "ABSTRACT") == 0) {
	    output.need_gap = 1;
	    gfprintf("}{\\pard\\plain\\f%s\\s%s\\qc Abstract",
		     font, style);
	    output.need_gap = 1;
	    font = check_style("fpar");
	    style = check_style("spar");
	    gfprintf("}{\\pard\\plain\\f%s\\s%s %s",
		     font, style, link->text);
	    output.need_gap = 1;
	  }
	  link = link->next;
	}
	font = check_style("fpar");
	style = check_style("spar");
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "COPYRITE") == 0) {
	    output.need_gap = 1;
	    gfprintf("}{\\pard\\plain\\f%s\\s%s\\qc ",
		     font, style);
	    gfputs(link->text);
	    output.need_gap = 1;
	  }
	  link = link->next;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "THANKS") == 0) {
	    output.need_gap = 1;
	    gfprintf("}{\\pard\\plain\\f%s\\s%s\\qc ",
		     font, style);
	    gfputs(link->text);
	    output.need_gap = 1;
	  }
	  link = link->next;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "DOCNUM") == 0) {
	    gfprintf("}{\\pard\\plain\\f%s\\s%s ref: %s",
		     font, style, link->text);
	    output.need_line = 1;
	  }
	  link = link->next;
	}
	output.need_gap = 1;
      }
      else if (c_line.setter == TEXINFO) {
	struct stored_text *link; /* Pointer to stored text link.  */
	char *title;		  /* Title text.  */
	char *copyright = NULL;	  /* Copyright text.  */
	/* Temporary "array" of counters for get_node().  */
	int counters[1];
	struct info_tree *tree_ptr; /* Pointer to the document tree.  */
	int title_lines;	    /* Counts the number of title lines.  */
	char *bk;		    /* Line break method.  */
	char *chapter_page;	    /* Whether chapter has new page.  */
	char *headers;		    /* How running headers printed.  */
	char *paper;		    /* Paper size.  */
	int got_date = 0;	    /* Whether date line has been found.  */

	gfputs("@c %%**start of header");
	output.need_wrap = 1;
	gfputs("@setfilename ");
	if (strcmp(c_line.sgml_file[0], "-") == 0) 
	  gfputs("untitled.info");
	else
	  gfprintf("%s.info", c_line.base_name[0]);
	output.need_wrap = 1;
	gfputs("@settitle ");
	/* Get the first title line.  */
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "TITLE") == 0)
	    break;
	  link = link->next;
	}
	if (link == NULL || link->next == NULL) {
	  /* Should not happen.  */
	  title = "Untitled";
	}
	else
	  title = link->text;
	gfputs(title);
	output.need_wrap = 1;
	chapter_page = check_style("chapter-page");
	if (strcmp(chapter_page, "same") == 0)
	  gfputs("@setchapternewpage off");
	else if (strcmp(chapter_page, "new") == 0)
	  gfputs("@setchapternewpage on");
	else if (strcmp(chapter_page, "odd") == 0)
	  gfputs("@setchapternewpage odd");
	output.need_wrap = 1;
	paper = check_style("paper");
	if (strcmp(paper, "A4") == 0) {
	  gfputs("@iftex");
	  output.need_wrap = 1;
	  gfputs("@afourpaper");
	  output.need_wrap = 1;
	  gfputs("@end iftex");
	}
	else if (strcmp(paper, "smallbook") == 0)
	  gfputs("@smallbook");
	/* For default paper size: nothing.  */
	output.need_wrap = 1;
	gfputs("@c %%**end of header");
	output.need_wrap = 1;
	output_flush();		/* Flush pending text.  */
	output.need_wrap = 1;
	
	link = get_stored_text("COPYRITE");
	if (link != NULL && link->next != NULL) {
	  copyright = link->text;
	  gfputs("@ifinfo");
	  output.need_wrap = 1;
	  gfputs(link->text);
	  output.need_wrap = 1;
	  gfputs("@end ifinfo");
	  output.need_wrap = 1;
	}
	/* Define line-breaking behaviour.  */
	bk = check_style("break-method");
	if (strcmp(bk, "no-box") == 0)
	  gfputs("@finalout");
	else if (strcmp(bk, "always-break") == 0) {
	  gfputs("@iftex");
	  output.need_wrap = 1;
	  gfputs("@emergencystretch=@hsize");
	  output.need_wrap = 1;
	  gfputs("@end iftex");
	}
	output.need_wrap = 1;
	gfputs("@titlepage");
	output.need_wrap = 1;
	title_lines = 0;
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "TITLE") == 0) {
	    title_lines++;
	    if (title_lines == 1)
	      gfprintf("@title %s", link->text);
	    else
	      gfprintf("@subtitle %s", link->text);
	    output.need_wrap = 1;
	  }
	  link = link->next;
	}
	link = &stored_text;
	while (link->next != NULL) {
	  if (strcmp(link->key, "DATE") == 0) {
	    gfprintf("@subtitle %s", link->text);
	    output.need_wrap = 1;
	    got_date = 1;
	  }
	  link = link->next;
	}
	if (got_date == 0) {
	  /* Put today's date.  */
	  gfputs("@subtitle @today{}");
	  output.need_wrap = 1;
	}
	if (dtd.version < 5) {
	  link = &stored_text;
	    while (link->next != NULL) {
	      if (strcmp(link->key, "AUTHOR") == 0) {
		gfprintf("@author %s", link->text);
		output.need_wrap = 1;
	      }
	      link = link->next;
	    }
	}
	else {
	  /* Pointer to the stored author names.  */
	  struct name *name_ptr = &dtd.names;
	  /* Pointer to the stored address information.  */
	  struct address *address_ptr;
	  int name_count = 0;	/* Counts the name lines.  */
	  int address_count;	/* Counts the address lines.  */
	  int found;		/* Whether address has been found.  */
	 
	  while (name_ptr->next != NULL) {
	    gfprintf("@author %s", name_ptr->name);
	    /* If this name has an address IDREF, find the corresponding
	     * address.  Otherwise, find an address with this name number.
	     */
	    address_ptr = &dtd.addresses;
	    address_count = 0;
	    found = 0;
	    while (address_ptr->next != NULL) {
	      address_count++;
	      if (name_ptr->address_id != NULL) {
		if (strcmp(name_ptr->address_id, address_ptr->id) == 0) {
		  gfprintf("(%d)", address_count);
		  found = 1;
		}
	      }
	      else {
		if (address_ptr->name_number == name_count) {
		  gfprintf("(%d)", address_count);	
		  found = 1;
		}
	      }
	      address_ptr = address_ptr->next;
	    }
	    if (name_ptr->address_id != NULL && found == 0) {
	      error(WARN, 0, "missing address with id=%s", 
		    name_ptr->address_id);
	    }
	    name_ptr = name_ptr->next;
	    name_count++;
	    output.need_wrap = 1;
	  }
	  /* Print the address lines.  */
	  address_ptr = &dtd.addresses;
	  address_count = 0;
	  while (address_ptr->next != NULL) {
	    address_count++;
	    gfprintf("@author (%d) %s", address_count, address_ptr->address);
	    output.need_wrap = 1;
	    address_ptr = address_ptr->next;
	  }
	}
	if (copyright != NULL) {
	  gfputs("@page");
	  output.need_wrap = 1;
	  gfputs("@vskip 0pt plus 1filll");
	  output.need_wrap = 1;
	  gfputs(copyright);
	  output.need_wrap = 1;
	}
	gfputs("@end titlepage");
	output.need_wrap = 1;
	headers = check_style("headers");
	if (strcmp(headers, "none") == 0)
	  gfputs("@headings off");
	else if (strcmp(headers, "single-sided") == 0)
	  gfputs("@headings single");
	else if (strcmp(headers, "double-sided") == 0)
	  gfputs("@headings double");
	output.need_wrap = 1;
	
	/* Create the first node.  */
	gfputs("@node Top,");
	/* Get the name of the first sectional node.  */
	counters[0] = 0;
	tree_ptr = get_node(&info_tree, 1, counters);
	if (tree_ptr == NULL) {
	  /* No sections.  */
	  gfputs("(dir)");
	}
	else
	  gfputs(tree_ptr->node);
	gfputs(",(dir),(dir)");
	output.need_wrap = 1;
	gfputs("@ifinfo");
	output.need_wrap = 1;
	gfputs(title);
	output.need_wrap = 1;
	gfputs("@end ifinfo");
	output.need_gap = 1;
	output.need_par = 1;	/* Suppress @noindent.  */
      }
      /* Free the stored text, if no other storage.  */
      if (output.store_text == 0)
	free_storage();	
    }
    else {
      /* Check for architectural forms.  */
      struct attr *arch_ptr = query_attribute(stack, "SARC");

      if (arch_ptr != NULL) {
	if (strcmp(arch_ptr->values, "NOTE") == 0)
	  start_note(stack, depth, 0);
	else if (strcmp(arch_ptr->values, "PHRASE") == 0)
	  start_phrase(stack, depth);
	else if (strcmp(arch_ptr->values, "CODE") == 0)
	  start_code_inline(stack, depth);
	else if (strcmp(arch_ptr->values, "LISTING") == 0)
	  start_code_lines(stack, depth);
      }
    }
  }
}

void spaper_element_end(struct stack *stack, int depth)
{
  char *element = stack->element;

  if (dtd.pass == 1) {
    if (c_line.family == FAM_TEX)
      return;
    /* 1st pass: just keeping track of counters.  */
    if (strcmp(element, "OL") == 0)
      end_ordered_list(stack, depth, 1);
    else if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
      int head_level = element[1] - '0';

      end_heading(stack, depth, head_level, 1);
    }
    else if (strcmp(element, "PAPERFRONT") == 0
	     || (dtd.version < 5 && strcmp(element, "FRONTM") == 0))
      structure.infrontm = 0;
    else if (c_line.setter == TEXINFO && structure.inheading) {
      /* Texinfo: need to process notes, phrases, short quotes etc.
       * in headings.
       */
      if (strcmp(element, "Q") == 0)
	end_shortquote(stack, depth);
      else if (dtd.version < 5 && strncmp(element, "HP", 2) == 0
	       && element[3] == '\0')
	end_phrase(stack, depth);
      else if (dtd.version < 5 && strcmp(element, "CODE") == 0) {
	char *type = check_attribute(stack, "BREAK")->values;

	if (strcmp(type, "INTEXT") == 0)
	  end_code_inline(stack, depth);
      }
      else if (strcmp(element, "TEXEQN") == 0)
	end_texeqn(stack, depth, 0);
      else {
	/* Check for architectural forms.  */
	struct attr *arch_ptr = query_attribute(stack, "SARC");

	if (arch_ptr != NULL) {
	  if (strcmp(arch_ptr->values, "NOTE") == 0)
	    end_note(stack, depth);
	  else if (strcmp(arch_ptr->values, "PHRASE") == 0)
	    end_phrase(stack, depth);
	  else if (strcmp(arch_ptr->values, "CODE") == 0)
	    end_code_inline(stack, depth);
	}
      }
    }
  }
  else {
    text.aline_pending = 0;
    text.new_par = 0;
    text.par_pending = 0;
    if (strcmp(element, "P") == 0)
      end_paragraph(stack, depth);
    else if (strcmp(element, "Q") == 0)
      end_shortquote(stack, depth);
    else if (strcmp(element, "PAPERFRONT") == 0
	     || (dtd.version < 5 && strcmp(element, "FRONTM") == 0))
      structure.infrontm = 0;
    else if (strcmp(element, "NOPRINT") == 0)
      end_copy_noprint(stack, depth);
    else if (dtd.version < 5 && strcmp(element, "CODE") == 0) {
      char *type = check_attribute(stack, "BREAK")->values;

      if (strcmp(type, "INTEXT") == 0)
	end_code_inline(stack, depth);
      else
	end_code_lines(stack, depth);
    }
    else if (strcmp(element, "FIG") == 0)
      end_fig(stack, depth);
    else if (strcmp(element, "FIGCAP") == 0)
      end_figcap(stack, depth);
    else if (dtd.version < 5 && strcmp(element, "FN") == 0)
      end_note(stack, depth);
    else if (strcmp(element, "OL") == 0)
      end_ordered_list(stack, depth, 0);
    else if (strcmp(element, "UL") == 0)
      end_unordered_list(stack, depth);
    else if (strcmp(element, "SL") == 0)
      end_simple_list(stack, depth);
    else if (strcmp(element, "LI") == 0)
      end_list_item(stack, depth);
    else if (strcmp(element, "TL") == 0)
      end_tagged_list(stack, depth);
    else if (strcmp(element, "TLIT") == 0)
      end_tagged_list_tag(stack, depth);
    else if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
      int head_level = element[1] - '0';
      end_heading(stack, depth, head_level, 0);
    }
    else if (dtd.version < 5 && strncmp(element, "HP", 2) == 0
	     && element[3] == '\0')
      end_phrase(stack, depth);
    else if (strcmp(element, "TEXEQN") == 0) {
      if (dtd.version < 5) {
	char *type = check_attribute(stack, "BREAK")->values;

	if (strcmp(type, "INTEXT") == 0)
	  end_texeqn(stack, depth, 0);
	else
	  end_texeqn(stack, depth, 1);
      }
      else
	end_texeqn(stack, depth, 0);
    }
    else if (strcmp(element, "TEXEQN-DISPLAY") == 0)
      end_texeqn(stack, depth, 1);
    else if (strcmp(element, "LINE") == 0)
      end_aline(stack, depth);
    else if (strcmp(element, "AUTHOR") == 0) {
      if (dtd.version < 5) {
	if (c_line.family == FAM_TEX) {
	  gfputs("}");
	  output.need_wrap = 1;
	}
	/* For later versions, subelements are stored in the spaper array.  */
      }
    }
    else if (strcmp(element, "ABSTRACT") == 0
	     || strcmp(element, "COPYRITE") == 0
	     || strcmp(element, "THANKS") == 0
	     || strcmp(element, "DOCNUM") == 0
	     || strcmp(element, "DATE") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("}");
	output.need_wrap = 1;
      }
      else {
	end_storage();
      }
    }
    else if (strcmp(element, "TITLE") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("}");
	output.need_wrap = 1;
      }
      else if (dtd.version < 4)
	end_storage();
    }
    else if (strcmp(element, "ALINE") == 0) {
      if (c_line.family == FAM_TEX)
	end_aline(stack, depth);
      else {
	if (dtd.version < 5)
	  end_aline(stack, depth);
	else
	  text.aline_pending = 1;
      }
    }
    else if (strcmp(element, "NAME") == 0) {
      struct stored_text *text_ptr = end_storage();
      struct name *name_ptr = &dtd.names;

      /* Get to the 2nd to last link in the list.  */
      while (name_ptr->next->next != NULL)
	name_ptr = name_ptr->next;
      name_ptr->name = galloc(strlen(text_ptr->text) + 1);
      strcpy(name_ptr->name, text_ptr->text);
    }
    else if (strcmp(element, "ADDRESS") == 0) {
      if (dtd.version < 5) {
	if (c_line.family == FAM_TEX);
	  /* Do nothing, since \author will close the macro call.  */
	else {
	  gfputs(") ");
	  end_aline(stack, depth);
	}
	text.aline_pending = 1;
      }
      else {
	struct stored_text *text_ptr = end_storage();
	struct address *address_ptr = &dtd.addresses;
	struct name *name_ptr = &dtd.names;

	/* Get to the 2nd to last link in the list.  */
	while (address_ptr->next->next != NULL)
	  address_ptr = address_ptr->next;
	address_ptr->address = galloc(strlen(text_ptr->text) + 1);
	strcpy(address_ptr->address, text_ptr->text);
	/* Record the current name number.  */
	address_ptr->name_number = 0;
	while (name_ptr->next->next != NULL) {
	  address_ptr->name_number++;
	  name_ptr = name_ptr->next;
	}
      }
    }
    else if (strcmp(element, "ORG") == 0
	     || strcmp(element, "STREET") == 0
	     || strcmp(element, "CITY") == 0
	     || strcmp(element, "REGION") == 0
	     || strcmp(element, "COUNTRY") == 0
	     || strcmp(element, "CONTACT") == 0
	     || strcmp(element, "POSTCODE") == 0
	     || strcmp(element, "POSTBOX") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("}");
    }
    else if (strcmp(element, "IX") == 0)
      end_index_entry(stack, depth);
    else if (strcmp(element, "SPAPER") == 0)
      end_document(stack, depth);
    else {
      /* Check for architectural forms.  */
      struct attr *arch_ptr = query_attribute(stack, "SARC");

      if (arch_ptr != NULL) {
	if (strcmp(arch_ptr->values, "NOTE") == 0)
	  end_note(stack, depth);
	else if (strcmp(arch_ptr->values, "PHRASE") == 0)
	  end_phrase(stack, depth);
	else if (strcmp(arch_ptr->values, "CODE") == 0)
	  end_code_inline(stack, depth);
	else if (strcmp(arch_ptr->values, "LISTING") == 0)
	  end_code_lines(stack, depth);
      }	
    }
  }
}

/* Amount of memory to grab at once when reading files.  */
#define BLOCK 1000

/* Process an external entity reference.  */
void spaper_x_ent(struct stack *stack, int depth,
		  struct entity_info *entity_ptr)
{
  if (dtd.pass == 1)
    return;

  if (strcmp(entity_ptr->notation, "ASCII") == 0
      || strcmp(entity_ptr->notation, "ISO646") == 0) {
    FILE *in;
    char *string = galloc(BLOCK);
    long buff_size = BLOCK;
    long string_len = 0;
    int temp;
    char *filename = entity_ptr->filename;

    if (filename == NULL)
      error(EXIT, 0, "unable to open external entity\n");

    /* skip over the GI added by nsgmls.  */
    while (*filename != '>' && *filename != '\0')
      filename++;
    if (*filename == '\0')
      {
	error (EXIT, errno, "expecting a GI prefixed to %s",
	       entity_ptr->filename);
      }
    filename++;

    if ((in = fopen(filename, "r")) == NULL)
      error(EXIT, errno, "unable to open %s", filename);
    
    /* read the file into a string.  */
    while ((temp = fgetc(in)) != EOF) {
      if (!gf_isascii(temp)) {
	error(EXIT, 0, "non-ASCII character %d in %s", 
	      (unsigned char) temp, filename);
      }
      string[string_len] = temp;
      if (++string_len == buff_size) {
	buff_size += BLOCK;
	string = grealloc(string, buff_size);
      }
    }
    string[string_len] = '\0';
    if (fclose(in) != 0)
      error(WARN, 0, "failed to close %s", filename);

    /* process the string as usual.  */
    spaper_chars(stack, depth, string);

    gfree(string);
  }
  else {
    error(EXIT, 0, "%s: notation %s is not supported in this context",
	  entity_ptr->filename, entity_ptr->notation);
  }
}

/* Process a string.  */
void spaper_chars(struct stack *stack, int depth, char *string)
{
  if (output.discard_text) {
    /* Don't call print_escaped while discarding text: it can introduce
     * wraps etc.
     */
    return;
  }
  if (!(text.contents->respect_spaces && text.contents->preserve_breaks)) {
    tidy_string(string, text.contents->respect_spaces,
		text.contents->preserve_breaks);
    if (!text.contents->respect_spaces && text.new_par)
      strip_leading_blanks(string);
  }
  string = replace_sdata(string, &sdata, text.contents->tt,
			 text.contents->math);

  print_escaped(string, dtd.sent_blanks, text.contents->tt,
		text.contents->math);
}

int spaper_end()
{
  dtd.pass++;

  /* Two passes through the document are usually needed.  */
  if (dtd.pass > 2)
    return(1); /* Finished.  */
  else 
    return(0); /* Do another pass.  */
}
