/* Functions for transforming strings.
 * Copyright (C) 1993, 1994, Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "gf.h"

/* Number of bytes to allocate when extending buffers.  */
#define BLOCK 100

/* Read an sdata translation table from a file.  Each line
 * of the file gives an SDATA key, a TAB character
 * and the replacement text.
 */
static void read_sdata_file(char *path, struct sdata_table *table)
{
  FILE *stream;
  int last_char;
  char *string;

  if ((stream = fopen(path, "r")) == NULL)
    error(EXIT, 0, "unable to open %s", path);
  
  /* Find the end of the linked list.  */
  while (table->next != NULL)
    table = table->next;

  /* Read the file.  */
  while ((string = read_string(stream, "\t\n", &last_char)), 
	 last_char == '\t') {
    table->key = galloc(strlen(string) + 1);
    strcpy(table->key, string);
    string = read_string(stream, "\n", &last_char);
    table->value = galloc(strlen(string) + 1);
    strcpy(table->value, string);
    table->next = galloc(sizeof(struct sdata_table));
    table = table->next;
    table->next = NULL;
  }
  
  if (fclose(stream) != 0)
    error(WARN, 0, "failed to close %s", path);
}

/* Find and read an SDATA translation table, from the user's lib directory
 * or the system lib directory.
 */
void get_sdata_translations(char *file_name, struct sdata_table *table)
{
  char *temp;

  if ((temp = exists_user_dir(file_name)) == NULL) {
    if ((temp = exists_system_dir(file_name)) == NULL) {
      error(WARN, 0, "unable to open %s", file_name);
      return;
    }
  }
  read_sdata_file(temp, table);
  gfree(temp);
}

/* Read an SDATA translation table specific to the current document.  The
 * extension argument is appended to the base name of the document.
 */
void get_sdata_local(char *extension, struct sdata_table *table)
{
  int i;
  char *temp;			/* Constructed file name.  */

  for (i = 0; i < c_line.num_files; i++) {
    temp = galloc(strlen(c_line.base_name[i]) + strlen(extension) + 1);
    sprintf(temp, "%s%s", c_line.base_name[i], extension);
    if (exists(temp)) {
      verbose(temp, OK, READ);
      read_sdata_file(temp, table);
    }
    else
      verbose(temp, FAIL, READ);
    gfree(temp);
  }
}

/* Search for a key in an SDATA structure.  If found, a pointer
 * to the string is returned, otherwise NULL.
 */
char *query_sdata(struct sdata_table *sdata, char *key)
{
  struct sdata_table *ptr = sdata;
  while (ptr->next != NULL) {
    if (strcmp(ptr->key, key) == 0)
      return ptr->value;
    ptr = ptr->next;
  }
  return(NULL);
}
    
/* Convert non-ASCII characters in a string into SDATA words.  They
 * can then be processed by the standard output routines.
 * An internal buffer is maintained to hold the replacement 
 * string. An sdata_table is supplied which contains the mappings.
 * Unrecognised non-ASCII characters are passed through unchanged.
 */
char *map_non_ASCII(char *text, struct sdata_table *sdata)
{
  static char *buffer;		/* Output buffer.  */
  static int buffer_size = 0;	/* Size of the buffer.  */
  char *out_ptr = buffer;	/* Pointer to a place in the buffer.  */
  int buffer_length = 0;	/* Length of the output string.  */
  char *in_ptr = text;		/* Steps though the input string.  */
  char *start = text;		/* Marks start of a "word".  */

  if (buffer_size == 0) {
    /* Initialise the buffer.  */
    buffer_size = BLOCK;
    buffer = galloc(buffer_size);
    out_ptr = buffer;
  }

  while (*in_ptr != '\0') {
    
    /* Make a word out of ASCII text.  */
    while (*in_ptr != '\0' && gf_isascii(*in_ptr))
      in_ptr++;
    
    if (in_ptr > start) {
      /* Expand the buffer if needed.  */
      while (buffer_length + in_ptr - start + 1 > buffer_size) {
	buffer_size += BLOCK;
	buffer = grealloc(buffer, buffer_size);
	out_ptr = buffer + buffer_length;
      }
      /* Copy the word to the output string.  */
      buffer_length += in_ptr - start;
      while (start < in_ptr)
	*out_ptr++ = *start++;
    }
    if (*in_ptr != '\0') {
      /* Replace a non-ASCII character.  */
      char decimal[10];		/* Temporary decimal string.  */
      char failed[10];		/* Pseudo-SDATA string. */
      char *value;		/* Result of SDATA lookup.  */
      int i;
      
      /* Convert the character to a decimal string.  Two casts are
       * needed in case chars are signed.
       */
      sprintf(decimal, "%d", (int)(unsigned char) *in_ptr);
      
      /* Try to translate.  */
      if ((value = query_sdata(sdata, decimal)) == NULL) {
	error(WARN, 0, "unresolved non-ASCII character: %s", decimal);
	sprintf(failed, "[%6s]", decimal);
	value = failed;
      }
      /* Expand the buffer if needed.  */
      while (buffer_length + strlen(value) + 3 > buffer_size) {
	buffer_size += BLOCK;
	buffer = grealloc(buffer, buffer_size);
	out_ptr = buffer + buffer_length;
      }
      /* Copy the string, delimited as SDATA.  */
      buffer_length += strlen(value) + 2;
      *out_ptr++ = SDATA_TEMP;
      for (i = 0; i < strlen(value); i++)
	*out_ptr++ = value[i];
      *out_ptr++ = SDATA_TEMP;

      in_ptr++;
      start = in_ptr;
    }
  }
  *out_ptr = '\0';
  return buffer;
}

/* Replace SDATA entities in a text string with typesetter code.  An internal
 * buffer is maintained to hold the output string.  Tricky things:
 * TeX substitution code can depend on which elements are open.
 * ISO diacritical marks are given after the letter to which they apply.
 * SDATA delimiters are retained, so that the code will not be escaped
 * later.
 */
char *replace_sdata(
   char *text,			/* Input string.  */
   struct sdata_table *sdata,	/* SDATA translation table.  */
   int in_tt,			/* Whether in CODE element (or equivalent).  */
   int in_tex)			/* Whether in native TeX mode (ignored if
				 * TeX is not the formatter).
				 */
{
  static char *buffer;		/* Where the output is stored.  */
  static int buffer_size = 0;	/* Size of the output buffer.  */
  int buffer_length = 0;	/* Length of the output string.  */
  char *in_ptr = text;		/* Steps through the input string.  */
  char *out_ptr = buffer;	/* Steps through the output string.  */
  
  if (buffer_size == 0) {
    buffer_size = BLOCK;
    buffer = galloc(BLOCK);
    out_ptr = buffer;
  }
  
  while (*in_ptr != '\0') {
    /* Step through the string, looking for the start of SDATA.  */
    if (*in_ptr == SDATA_TEMP) {
      char *key = ++in_ptr;	/* SDATA entity.  */
      char *value = NULL;	/* Replacement text.  */
      char dia_swap_char;	/* Accented character to be swapped.  */
      int i;

      /* Find the matching SDATA delimiter.  */
      while (*in_ptr != SDATA_TEMP && *in_ptr != '\0')
	in_ptr++;
      if (*in_ptr == '\0')
	error(EXIT, 0, "unbalanced SDATA delimiter in `%s'", text);
      /* Temporarily replace the second delimiter with '\0'.  */
      *in_ptr = '\0';
      dia_swap_char = '\0';
      if (c_line.family == FAM_TEX) {
	/* Check for the diacritical entities, which need to be swapped
	 * with the previous character.
	 * [caron ], [dblac ] and [ogon  ] are omitted.
	 */
	if (strcmp(key, "[acute ]") == 0 || strcmp(key, "[breve ]") == 0
	    || strcmp(key, "[cedil ]") == 0 || strcmp(key, "[circ  ]") == 0
	    || strcmp(key, "[die   ]") == 0 || strcmp(key, "[dot   ]") == 0
	    || strcmp(key, "[grave ]") == 0 || strcmp(key, "[macr  ]") == 0
	    || strcmp(key, "[ring  ]") == 0 || strcmp(key, "[tilde ]") == 0
	    || strcmp(key, "[uml   ]") == 0) {
	  if (out_ptr == buffer) {
	    /* This was the first character of the string: do not attempt
	     * to format the symbol.
	     */
	    value = key;
	  }
	  else {
	    /* Remove the character to be swapped.  */
	    out_ptr--;
	    dia_swap_char = *out_ptr;
	  }
	}
	else if (in_tt) {
	  /* Some characters are rendered differently in the code element.  */
	  if (strcmp(key, "[lt    ]") == 0)
	    value = "<";
	  else if (strcmp(key, "[gt    ]") == 0)
	    value = ">";
	  else if (strcmp(key, "[bsol  ]") == 0)
	    value = "\\char`\\\\{}";
	  else if (strcmp(key, "[horbar]") == 0)
	    value = "-";
	  else if (strcmp(key, "[verbar]") == 0)
	    value = "|";
	  else if (strcmp(key, "[lowbar]") == 0)
	    value = "\\char`\\_{}";
	  else if (strcmp(key, "[lcub  ]") == 0)
	    value = "\\char`\\{{}";
	  else if (strcmp(key, "[rcub  ]") == 0)
	    value = "\\char`\\}{}";
	  /* This is for a bug in LaTeX 2e.  */
	  else if (c_line.setter == LATEX2E && strcmp(key, "[pound ]") == 0)
	    value = "\\textrm{\\pounds}";
	}
      }
      if (value == NULL) {
	if ((value = query_sdata(sdata, key)) == NULL) {
	  error(WARN, 0, "unresolved SDATA entity: %s", key);
	  value = "-UNKNOWN-";
	}
      }
      /* Copy the value to the output string, including the SDATA delimiters
       * and possibly the trailing curly brace for [breve ] or [cedil ].
       */
      while (buffer_length + strlen(value) + 3 + 1 >= buffer_size) {
	buffer_size += BLOCK;
	buffer = grealloc(buffer, buffer_size);
	out_ptr = buffer + buffer_length;
	if (dia_swap_char != '\0')
	  out_ptr--;
      }
      *out_ptr++ = SDATA_TEMP;
      for (i = 0; i < strlen(value); i++)
	*out_ptr++ = value[i];

      /* Yet another kludge for macros which work best with the argument
       * in braces.
       */
      if (c_line.family == FAM_TEX
	  && (strcmp(key, "[breve ]") == 0 || strcmp(key, "[cedil ]") == 0)) {
	*out_ptr++ = dia_swap_char;
	*out_ptr++ = '}';
      }

      *out_ptr++ = SDATA_TEMP;
      buffer_length += strlen(value) + 2;

      if (c_line.family == FAM_TEX
	  && (strcmp(key, "[breve ]") == 0 || strcmp(key, "[cedil ]") == 0))
	buffer_length++;
      else {
	/* Put back the swapped accented character, if needed.  */
	if (dia_swap_char != '\0')
	  *out_ptr++ = dia_swap_char;
      }
      
      /* Put the input string back to its original state.  */
      *in_ptr++ = SDATA_TEMP;
    }
    else {
      /* Ordinary character: copy to the output string.  */
      if (buffer_length + 1 >= buffer_size) {
	buffer_size += BLOCK;
	buffer = grealloc(buffer, buffer_size);
	out_ptr = buffer + buffer_length;
      }
      *out_ptr++ = *in_ptr++;
      buffer_length++;
    }
  }
  *out_ptr = '\0';
  return(buffer);
}

/* Macro used in print_escape:  add an extra space if needed after anything
 * looking like a sentence.  This assumes that multiple blanks have already
 * been removed.
 */
#define END_SENTENCE				\
	if (*in_ptr == ' ' && in_ptr != text	\
	    && sent_blanks == 2 && !in_tt	\
	    && (*(in_ptr - 1) == '.' 		\
		|| *(in_ptr - 1) == '?'		\
		|| *(in_ptr - 1) == '!'		\
		|| *(in_ptr - 1) == ':'		\
		|| *(in_ptr - 1) == ';'))	\
          replace = "  ";

/* Print a string, escaping special characters depending on the typesetter. 
 * Text within SDATA delimiters is never escaped.
 */
void print_escaped(
   char *text,			/* String (assumed writable).  */
   int sent_blanks,		/* Blanks between "sentences": 1 or 2.  */
   int in_tt,			/* Whether in CODE or equivalent.  */
   int in_tex)			/* Whether in native TeX mode.  */
{
  char *in_ptr = text;		/* Steps through the string.  */
  char *start = text;		/* Start of the current "word".  */
  int col_adjust = 0;		/* Extra columns for tab calculations.  */
  
  /* Step through the string, printing words delimited by escaped
   * characters or SDATA.
   */
  while (*in_ptr != '\0') {
    char *replace = NULL;	/* Replacement text.  If this is still NULL
				 * after checking for special characters,
				 * don't need to print anything yet.
				 */
    int delayed_wrap = 0;	/* Whether a line wrap will be needed.  */
    int delayed_line = 0;	/* Whether a line break will be needed.  */
    if (*in_ptr == SDATA_TEMP) {
      /* Print the current word.  */
      if (in_ptr > start) {
	*in_ptr = '\0';		/* Temporarily terminate the string.  */
	gfputs(start);
	*in_ptr = SDATA_TEMP;	/* Restore to the original state.  */
      }
      /* Print the resolved SDATA string.  */
      start = ++in_ptr;	/* Start of the SDATA string.  */
      for (; *in_ptr != SDATA_TEMP && *in_ptr != '\0'; in_ptr++)
	/* Do nothing.  */;
      if (*in_ptr == '\0')
	error(EXIT, 0, "unexpected end to SDATA object in `%s'", text);
      *in_ptr = '\0';		/* Temporarily terminate the string.  */
      gfputs(start);
      *in_ptr = SDATA_TEMP;	/* Restore to the original state.  */
      start = ++in_ptr;		/* Start a new word.  */
    }
    else {
      /* Current character is not SDATA delimiter.  */
      /* Tab is replaced with enough spaces to reach a column divisible
       * by eight when spaces are respected.  This could fail if the
       * string did not start at the beginning of the line (e.g., when
       * subelements can be embedded.)
       * If spaces are not respected, `\t' will already
       * have been replaced by ` '.
       */
      if (*in_ptr == '\t') {
	char *last_break = in_ptr;
	int mod_col;
	int abs_col;

	/* Find the start of the current line.  */
	while (*last_break != '\n' && last_break > text)
	  last_break--;
	if (*last_break == '\n')
	  last_break++;
	abs_col = in_ptr - last_break + col_adjust;
	mod_col = abs_col - abs_col / 8 * 8;
	  
	switch (mod_col) {
	case 0: replace = "        "; break;
	case 1: replace = "       "; break;
	case 2: replace = "      "; break;
	case 3: replace = "     "; break;
	case 4: replace = "    "; break;
	case 5: replace = "   "; break;
	case 6: replace = "  "; break;
	case 7: replace = " "; break;
	}
	/* Extra space for future tab calculations.  */
	col_adjust += 7 - mod_col;
      }
      else if (c_line.family == FAM_TEX && !in_tex) {
	if (*in_ptr == '\\') {
	  if (in_tt)
	    replace = "\\char`\\\\{}";
	  else
	    replace = "$\\backslash$";
	}
	else if (*in_ptr == '#')
	  replace = "\\#";
	else if (*in_ptr == '%') 
	  replace = "\\%";
	else if (*in_ptr == '|') {
	  if (in_tt) 
	    replace = "|";
	  else 
	    replace = "$|$";
	}
	/* I don't think this is needed anymore. 
	 * --- Take care with *, since it will be swallowed e.g., by \\.
	 * else if (*in_ptr == '*') {
	 * replace = "{*}";
	 * }
	 */
	else if (*in_ptr == '_') {
	  if (in_tt) 
	    replace = "\\char`\\_{}";
	  else
	    replace = "\\_";
	}
	else if (*in_ptr == '^')
	  replace = "\\char`\\^{}";
	else if (*in_ptr == '<') {
	  if (in_tt)
	    replace = "<";
	  else
	    replace = "$<$";
	}
	else if (*in_ptr == '[') {
	  if (in_tt)
	    replace = "[";
	  else 
	    replace = "\\char`\\[{}";
	}
	else if (*in_ptr == ']') {
	  if (in_tt) 
	    replace = "]";
	  else 
	    replace = "\\char`\\]{}";
	}
	else if (*in_ptr == '>') {
	  if (in_tt) 
	    replace = ">";
	  else 
	    replace = "$>$";
	}
	else if (*in_ptr == '~') 
	  replace = "\\char`\\~{}";
	else if (*in_ptr == '&') 
	  replace = "\\&";
	else if (*in_ptr == '$') 
	  replace = "\\$";
	else if (*in_ptr == '{') {
	  if (in_tt) 
	    replace = "\\char`\\{{}";
	  else 
	    replace = "\\{";
	}
	else if (*in_ptr == '}') {
	  if (in_tt) 
	    replace = "\\char`\\}{}";
	  else 
	    replace = "\\}";
	}
	else if (*in_ptr == '"') {
	  if (in_tt) 
	    replace = "\\char`\\\"{}";
	  else 
	    replace = "{\\tt\\char`\\\"}";
	}
	/* Escape ligatures.  */
	else if (*in_ptr == '-' && *(in_ptr + 1) == '-')
	  replace = "{-}";
	else if (*in_ptr == '\'' && *(in_ptr + 1) == '\'')
	  replace = "{'}";
	else if (*in_ptr == '`' && *(in_ptr + 1) == '`')
	  replace = "{`}";
	else if (*in_ptr == '?' && *(in_ptr + 1) == '`')
	  replace = "{?}";
	else if (*in_ptr == '!' && *(in_ptr + 1) == '`')
	  replace = "{!}";
      }
      else if (c_line.family == FAM_PLAIN) {
	/* Add an extra space at the end of anything looking like a 
	 * sentence.  This assumes that multiple blanks have already
	 * been removed.
	 */
	END_SENTENCE
      }
      else if (c_line.setter == RTF) {
	if (*in_ptr == '\\')
	  replace = "\\\\";
	else if (*in_ptr == '{')
	  replace = "\\{";
	else if (*in_ptr == '}')
	  replace = "\\}";
	else if (*in_ptr == '\n') {
	  /* `\n' will have been replaced with ' ' unless breaks are to
	   * be respected.
	   */
	  replace = "";
	  delayed_line = 1;
	}
	else
	  END_SENTENCE
      }
      else if (c_line.setter == TEXINFO && !in_tex) {
	if (*in_ptr == '@')
	  replace = "@@";
	else if (*in_ptr == '{')
	  replace = "@{";
	else if (*in_ptr == '}')
	  replace = "@}";
	else if (*in_ptr == '\n') {
	  /* `\n' will have been removed if breaks are not respected.  */
	  replace = "";
	  delayed_wrap = 1;
	}
	/* Check for sentences ending with a capital letter.  The convention
	 * in the SGML source is that these are real sentences, while TeX
	 * by default assumes they are abbreviations.  Can only fix periods
	 * in this way, not symbols like ?!:; .
	 */
	else if (*in_ptr == '.' && *(in_ptr + 1) == ' '
		 && in_ptr != text
		 && !in_tt
		 && *(in_ptr - 1) >= 'A'
		 && *(in_ptr - 1) <= 'Z')
		 replace = "@.";
	/* Add an extra space at the end of anything looking like a 
	 * sentence.
	 */
	else 
	  END_SENTENCE
      }
      if (*in_ptr == '\n')
	col_adjust = 0;
      if (replace != NULL) {
	/* A character needs to be escaped: first print the current word.  */
	char last_char = *in_ptr; /* Save the last character.  */

	if (in_ptr > start) {
	  *in_ptr = '\0';	  /* Temporarily terminate the string.  */
	  gfputs(start);
	  *in_ptr = last_char;	  /* Restore to the original state.  */
	}
	/* Print the replacement text for the escaped character, if it's
	 * not empty.
	 */
	if (replace[0] != '\0')
	  gfputs(replace);

	/* Prepare a new line if needed.  */
	if (delayed_wrap)
	  output.need_wrap = 1;
	if (delayed_line)
	  output.need_line = 1;

	start = ++in_ptr;	/* Skip the character and start a new word.  */
      }
      else /* Continue the current "word".  */
	in_ptr++;
    }
  }
  /* Print any left-over characters.  */
  if (in_ptr > start)
    gfputs(start);
}
