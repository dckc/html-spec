/* Lists.
 * Copyright (C) 1993, 1994, 1995 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "list.h"
#include "text.h"
#include "structure.h"
#include "link.h"

struct list list;
struct dl_info *dl_info;
struct uns_dl_info *uns_dl_info;

/* Initialize list data structures.  */
void init_list()
{
  list.list_node.prev = NULL;
  list.list_node.next = NULL;
  dl_info = NULL;
}

/* Return a pointer to the last link in the list data structure.  */
static struct list_node *get_list_node(void)
{
  struct list_node *ptr = &list.list_node;

  while (ptr->next != NULL)
    ptr = ptr->next;
  return(ptr);
}

/* Create and return a pointer to a new list node.
 * 'type' can be "ordered", "unordered" etc.
 * 'compact' is 1 for compact list, 0 otherwise.
 */
static struct list_node *new_list_node(char *type, int compact)
{
  struct list_node *ptr = get_list_node();

  ptr->next = galloc(sizeof(struct list_node));
  ptr->next->prev = ptr;
  ptr = ptr->next;
  ptr->next = NULL;

  ptr->count = 0;
  ptr->compact = compact;
  ptr->type = galloc(strlen(type) + 1);
  strcpy(ptr->type, type);

  return(ptr);
}

/* Destroy the last node in the list data structure.  */
static void delete_list_node(void)
{
  struct list_node *ptr = get_list_node();
  if (ptr->prev == NULL)
    return;			/* Already at beginning.  */
  gfree(ptr->type);
  ptr = ptr->prev;
  gfree(ptr->next);
  ptr->next = NULL;
}

/* 'store' is 1 if the document structure is to be stored, or 0 if printed
 * output is to be produced.  'compact' is 1 for a compact list or 0
 * otherwise.
 */
void start_ordered_list(struct stack *stack, int depth, int store, int compact)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\begin{enumerate}");
  }
  else if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
    new_list_node("ordered", compact);
    if (store == 0)
      output.need_gap = 1;
  }
  else if (c_line.setter == TEXINFO) {
    if (store) {
      /* Number items during the first pass, for cross-references.  */
      new_list_node("ordered", compact);
    }
    else {
      output.need_gap = 1;
      output.need_par = 1;	/* Suppress noindent.  */
      gfputs("@enumerate");
    }
  }
}

void end_ordered_list(struct stack *stack, int depth, int store)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\end{enumerate}");
    output.need_wrap = 1;
  }
  else if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
    delete_list_node();		/* Done even in 1st pass.  */
    if (store == 0) {
      output.need_gap = 1;
    }
  }
  else if (c_line.setter == TEXINFO) {
    if (store) 
    delete_list_node();		/* Done even in 1st pass.  */
    else {
      output.need_wrap = 1;
      gfputs("@end enumerate");
      output.need_gap = 1;
    }
  }
  text.new_par = 1;
}

void start_unordered_list(struct stack *stack, int depth, int compact)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\begin{itemize}");
  }
  else  if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
    new_list_node("unordered", compact);
    output.need_gap = 1;
  }
  else if (c_line.setter == TEXINFO) {
    new_list_node("unordered", compact);
    output.need_gap = 1;
    output.need_par = 1;	/* Suppress noindent.  */
    gfputs("@itemize @bullet");
  }
}

void end_unordered_list(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\end{itemize}");
    output.need_wrap = 1;
  }
  else  if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
    delete_list_node();
    output.need_gap = 1;
  }
  else if (c_line.setter == TEXINFO) {
    delete_list_node();
    output.need_wrap = 1;
    gfputs("@end itemize");
    output.need_gap = 1;
  }
  text.new_par = 1;
}

void start_simple_list(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\begin{simplelist}");
  }
  else  if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
    new_list_node("simple", 0);
    output.need_gap = 1;
  }
  else if (c_line.setter == TEXINFO) {
    new_list_node("simple", 0);
    output.need_gap = 1;
    output.need_par = 1;	/* Suppress noindent.  */
    gfputs("@itemize @minus");
  }
}

void end_simple_list(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\end{simplelist}");
    output.need_wrap = 1;
  }
  else  if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
    delete_list_node();
    output.need_gap = 1;
  }
  else if (c_line.setter == TEXINFO) {
    delete_list_node();
    output.need_wrap = 1;
    gfputs("@end itemize");
    output.need_gap = 1;
  }
  text.new_par = 1;
}

/* The store argument is 1 if the document structure is to be stored, or 0
 * if printed output is to be produced.
 */
void start_list_item(struct stack *stack, int depth, int store) 
{
  if (c_line.family == FAM_TEX) {
    struct attr *id = query_attribute(stack, "ID");
    output.need_wrap = 1;
    gfputs("\\item ");
    if (id != NULL && strcmp(id->type, "IMPLIED") != 0)
      gfprintf("\\label{%s}", id->values);
  }
  else if (c_line.family == FAM_PLAIN || c_line.setter == RTF
	   || c_line.setter == TEXINFO) {
    struct list_node *node_ptr = get_list_node();
    char *list_type = node_ptr->type;
    int compact = node_ptr->compact;
    
    if (store) {
      /* Collect possible cross-ref targets.  */
      /* list_type will be NULL if the type of the list wasn't stored:
       * can happen since often only ordered lists are processed on the
       * first pass.
       */
      if (list_type != NULL && strcmp(list_type, "ordered") == 0) {
	struct attr *id = query_attribute(stack, "ID");
	char new_text[10];
	char all_text[100] = "";
	
	node_ptr->count++;
	if (id != NULL && strcmp(id->type, "IMPLIED") != 0) {
	  /* Step through the linked list, combining all 
	   * ordered list counters into a string.
	   */
	  node_ptr = &list.list_node;
	  while (node_ptr->next != NULL) {
	    node_ptr = node_ptr->next;	/* First counter is never used.  */
	    if (strcmp(node_ptr->type, "ordered") == 0) {
	      if (all_text[0] != '\0')
		strcat(all_text, ".");
	      sprintf(new_text, "%d", node_ptr->count);
	      strcat(all_text, new_text);
	    }
	  }
	  if (c_line.setter == TEXINFO)
	    add_cross_ref(id->values, structure.node, all_text);
	  else
	    add_cross_ref(id->values, NULL, all_text);
	}
      }
    }
    /* Not storing.  */
    else {
      if (c_line.setter == TEXINFO) {
	output.need_wrap = 1;
	gfputs("@item");
	output.need_wrap = 1;
      }
      else { /* ASCII or RTF.  */
	if (compact)
	  output.need_wrap = 1;
	else
	  output.need_gap = 1;
	if (strcmp(list_type, "unordered") == 0) {
	  char *bullet = check_style("ul-bullet");

	  gfputs(bullet);

	  /* Change the lead text so that wrapped lines in the list item
	   * will be indented.
	   */
	  push_lead_blanks(strlen(bullet));
	}
	/* if (strcmp(list_type, "simple") == 0) - do nothing.  */
	else if (strcmp(list_type, "ordered") == 0) {
	  char new_text[10];
	  struct list_node *node_ptr = get_list_node(); /* Current node.  */
	  char *delim = check_style("ol-sep"); /* Symbol to delimit counter. */
	  char *dot = "";	/* Becomes a dot the second time through.  */
	  int label_len = 0;	/* Accumulates total label width.  */
	
	  node_ptr->count++;
	  /* Step through the linked list, printing all counters.  */
	  node_ptr = &list.list_node;
	  while (node_ptr->next != NULL) {
	    node_ptr = node_ptr->next;	/* First counter is never used.  */
	    if (strcmp(node_ptr->type, "ordered") == 0) {
	      sprintf(new_text, "%d", node_ptr->count);
	      gfprintf("%s%s", dot, new_text);
	      label_len += strlen(dot) + strlen(new_text);
	      dot = ".";
	    }
	  }
	  gfputs(delim);
	  label_len += strlen(delim);

	  /* Change the lead text so that wrapped lines in the list item
	   * will be indented.
	   */
	  push_lead_blanks(label_len);
	}
      }
    }
  }
}

void end_list_item(struct stack *stack, int depth)
{
  if (c_line.family == FAM_PLAIN || c_line.family == FAM_RTF) {
    struct list_node *node_ptr = get_list_node();
    char *list_type = node_ptr->type;

    if (list_type != NULL
	&& (strcmp(list_type, "unordered") == 0
	    || strcmp(list_type, "ordered") == 0)) {
      /* Restore the lead text.  */
      pop_lead_text();
    }
  }
}

void start_tagged_list(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\begin{description}");
  }
  else  if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
    new_list_node("tagged", 0);
    output.need_gap = 1;
  }
  else if (c_line.setter == TEXINFO) {
    new_list_node("tagged", 0);
    output.need_gap = 1;
    output.need_par = 1;	/* Suppress noindent.  */
    gfputs("@table @emph");
  }
}

void end_tagged_list(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\end{description}");
    output.need_wrap = 1;
  }
  else  if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
    delete_list_node();
    output.need_gap = 1;
    text.new_par = 1;
  }
  else if (c_line.setter == TEXINFO) {
    delete_list_node();
    output.need_gap = 1;
    gfputs("@end table");
    output.need_gap = 1;
  }
}

void start_tagged_list_tag(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\item[");
  }
  else if (c_line.family == FAM_PLAIN) {
    char *left_delim = check_style("tl-delimiter-l");

    output.need_line = 1;
    gfputs(left_delim);
  }
  else if (c_line.setter == RTF) {
    char *font = check_style("ftaglist");
    char *style = check_style("staglist");
  
    output.need_line = 1;
    gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
  }
  else if (c_line.setter == TEXINFO) {
    output.need_wrap = 1;
    gfputs("@item ");
  }
}

void end_tagged_list_tag(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX)
    gfputs("]");
  else if (c_line.family == FAM_PLAIN) {
    char *right_delim = check_style("tl-delimiter-r");
    gfputs(right_delim);
  }
  else if (c_line.setter == RTF) {
    gfprintf("}%s ", output.new_par);
  }
  else if (c_line.setter == TEXINFO)
    output.need_wrap = 1;
}  

/* Glossary list.  */
/* Only supports LaTeX.  */
void start_glossary_list(struct stack *stack, int depth)
{
  list.got_glossary_def = 0;
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\begin{glosslist}");
    output.need_wrap = 1;
  }
  else 
    error(EXIT, 0, "glossary list only supports LaTeX");
}

void end_glossary_list(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    /* Close the last definition.  */
    if (list.got_glossary_def)
      gfputs("}");
    output.need_wrap = 1;
    gfputs("\\end{glosslist}");
    output.need_wrap = 1;
  }
}

void start_glossary_tag(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    /* Close the preceding definition if needed.  */
    if (list.got_glossary_def)
      gfputs("}");
    output.need_wrap = 1;
    gfputs("\\glossitem[");
    list.got_glossary_def = 0;
  }
}

void end_glossary_tag(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    gfputs("]{");
  }
}

/* Glossary definition.  */
void start_glossary_def(struct stack *stack, int depth)
{
  /* Start a new line, if this is not the first definition.  */
  if (c_line.family == FAM_TEX && list.got_glossary_def) {
    gfputs("\\glossaryline");
    output.need_wrap = 1;
  }
  list.got_glossary_def = 1;
}

/* Definition list as used by the ISO general DTD.  Multiple columns of
 * terms are permitted: the number of columns should be the same for
 * each entry.  A header can also be supplied.  Content model is:
 * <!ELEMENT dl	      - -  ((dthd+, ddhd)?, (dt+, dd)*)>
 * The strategy is to save the entire list to a structure,
 * delaying writing the output until all information is available. A 
 * complication is the possibility of nested definition lists.
 */
/* Only supports LaTeX.  */
void start_def_list(struct stack *stack, int depth)
{
  struct dl_info *temp_def_list = dl_info; /* Current def list.  */

  dl_info = galloc(sizeof(struct dl_info)); /* New def list.  */
  dl_info->prev = temp_def_list;
  dl_info->dl_entry.next = NULL;
  dl_info->dl_head_info.dl_tag_list.next = NULL;
  dl_info->dl_head_info.dl_data = NULL;

  list.dl_new_entry = 1;
  if (c_line.family != FAM_TEX) 
    error(EXIT, 0, "Definition list only supports LaTeX");
}

/* Recursively free a list of tags within a dl_info structure.  */
static void free_dl_tag_list(struct dl_tag_list *tag_list)
{
  if (tag_list->next == NULL)
    return;
  free_dl_tag_list(tag_list->next);
  gfree(tag_list->next);
  gfree(tag_list->dl_tag);
  tag_list->next = NULL;
}

/* Recursively free a list of entries within a dl_info structure.  */
static void free_dl_entry_list(struct dl_entry *entry_list)
{
  if (entry_list->next == NULL)
    return;
  free_dl_entry_list(entry_list->next);
  gfree(entry_list->next);
  free_dl_tag_list(&entry_list->dl_tag_list);
  gfree(entry_list->dl_data);
  entry_list->next = NULL;
}

/* Free the current link in the dl_info list.  */
static void free_dl_list(void)
{
  /* Pointer to the dl_info structure.  */
  struct dl_info *temp_dl_info;

  free_dl_entry_list(&dl_info->dl_entry);
  free_dl_tag_list(&dl_info->dl_head_info.dl_tag_list);
  if (dl_info->dl_head_info.dl_data != NULL)
    gfree(dl_info->dl_head_info.dl_data);

  temp_dl_info = dl_info;
  dl_info = dl_info->prev;
  gfree(temp_dl_info);
}

/* Write the complete definition list.  */
void end_def_list(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    struct dl_tag_list *tag_list;
    struct dl_entry *entry;
    int tag_count;
    int first_count = 0;

    /* A line wrap here or in start_def_list would be unwise.  */
    gfputs("\\dlinit");
    output.need_wrap = 1;
    /* Write the test copies of the tags, which TeX will measure before
     * constructing the list.
     */
    tag_list = &dl_info->dl_head_info.dl_tag_list;
    tag_count = 0;
    while (tag_list->next != NULL) {
      tag_count++;
      gfprintf("\\dlheadtest%d{%s}", tag_count, tag_list->dl_tag);
      output.need_wrap = 1;
      tag_list = tag_list->next;
    }
    first_count = tag_count;
    entry = &dl_info->dl_entry;
    while (entry->next != NULL) {
      tag_list = &entry->dl_tag_list;
      tag_count = 0;
      while (tag_list->next != NULL) {
	tag_count++;
	gfprintf("\\dltest%d{%s}", tag_count, tag_list->dl_tag);
	output.need_wrap = 1;
	tag_list = tag_list->next;
      }
      if (first_count == 0)
	first_count = tag_count;
      else {
	if (first_count != tag_count)
	  error(WARN, 0, "Definition list has irregular number of tags");
      }
      entry = entry->next;
    }
    /* Write the real definition list.  */
    gfputs("\\begin{dl}%");
    output.need_wrap = 1;
    tag_list = &dl_info->dl_head_info.dl_tag_list;
    tag_count = 0;
    while (tag_list->next != NULL) {
      tag_count++;
      gfprintf("\\dltitletag%d{%s}%%", tag_count, tag_list->dl_tag);
      output.need_wrap = 1;
      tag_list = tag_list->next;
    }
    if (dl_info->dl_head_info.dl_data != NULL) {
      gfputs("\\dltitletext{");
      gfputs(dl_info->dl_head_info.dl_data);
      gfputs("}");
      output.need_wrap = 1;
    }
    entry = &dl_info->dl_entry;
    while (entry->next != NULL) {
      tag_list = &entry->dl_tag_list;
      tag_count = 0;
      output.need_wrap = 1;
      while (tag_list->next != NULL) {
	tag_count++;
	gfprintf("\\dltag%d{%s}%%", tag_count, tag_list->dl_tag);
	output.need_wrap = 1;
	tag_list = tag_list->next;
      }
      gfputs("\\dltext{");
      gfputs(entry->dl_data);
      gfputs("}");
      entry = entry->next;
    }
    /* No line wrap here.  */
    gfputs("\\end{dl}");
  }

  /* Free the current definition list.  */
  free_dl_list();

  if (output.store_text == 0)
    free_storage();

  text.new_par = 1;
}

/* Definition list elements. In each case, store the text then add it
 * to the structure.
 */
void start_def_tag_heading(struct stack *stack, int depth)
{
  start_storage("DTHD");
}

void end_def_tag_heading(struct stack *stack, int depth)
{
  struct dl_tag_list *tag_list = &dl_info->dl_head_info.dl_tag_list;
  struct stored_text *text_ptr = end_storage();
  char *text = text_ptr->text;

  /* Create a new link in the header tag list.  */
  while (tag_list->next != NULL)
    tag_list = tag_list->next;
  tag_list->next = galloc(sizeof(struct dl_tag_list));
  tag_list->next->next = NULL;
  tag_list->dl_tag = galloc(strlen(text) + 1);
  strcpy(tag_list->dl_tag, text);
  /* Hide the stored DTHD information, so that it doesn't get picked
   * up again later.
   */
  strcpy(text_ptr->key, "");
}

void start_def_data_heading(struct stack *stack, int depth)
{
  start_storage("DDHD");
}

void end_def_data_heading(struct stack *stack, int depth)
{
  struct dl_entry *entry = &dl_info->dl_head_info;
  struct stored_text *text_ptr = end_storage();
  char *text = text_ptr->text;

  entry->dl_data = galloc(strlen(text) + 1);
  strcpy(entry->dl_data, text);
  /* Hide the stored DDHD information, so that it doesn't get picked
   * up again later (if lists are nested).
   */
  strcpy(text_ptr->key, "");
}

void start_def_tag(struct stack *stack, int depth)
{
  start_storage("DT");
}

void end_def_tag(struct stack *stack, int depth)
{
  struct dl_entry *entry = &dl_info->dl_entry;
  struct dl_tag_list *tag_list;
  struct stored_text *text_ptr = end_storage();
  char *text = text_ptr->text;

  if (list.dl_new_entry) {
    /* If this is the first tag of a new entry, create a new entry.  */
    while (entry->next != NULL)
      entry = entry->next;
    entry->next = galloc(sizeof(struct dl_entry));
    entry->next->next = NULL;
    entry->dl_tag_list.next = NULL;

    list.dl_new_entry = 0;
  }
  else {
    while (entry->next->next != NULL)
      entry = entry->next;
  }
  /* Create a new tag.  */
  tag_list = &entry->dl_tag_list;
  while (tag_list->next != NULL)
    tag_list = tag_list->next;
  tag_list->next = galloc(sizeof(struct dl_tag_list));
  tag_list->next->next = NULL;
  tag_list->dl_tag = galloc(strlen(text) + 1);
  strcpy(tag_list->dl_tag, text);
  /* Hide the stored DT information, so that it doesn't get picked
   * up again later.
   */
  strcpy(text_ptr->key, "");
}

void start_def_data(struct stack *stack, int depth)
{
  start_storage("DD");
}

void end_def_data(struct stack *stack, int depth)
{
  struct dl_entry *entry = &dl_info->dl_entry;
  struct stored_text *text_ptr = end_storage();
  char *text = text_ptr->text;

  while (entry->next->next != NULL)
    entry = entry->next;
  entry->dl_data = galloc(strlen(text) + 1);
  strcpy(entry->dl_data, text);

  /* Will need to create a new entry when the next DT is reached.  */
  list.dl_new_entry = 1;
  /* Hide the stored DD information, so that it doesn't get picked
   * up again later.
   */
  strcpy(text_ptr->key, "");
}

/* Definition list as used by the HTML DTD.  This is typeset with a
 * single column of terms.  Terms and definitions can be supplied
 * independently of each other.  Content model is:
 * <!ELEMENT DL    - -  (DT*, DD?)+>
 * which is the same as:
 * <!ELEMENT DL    - -  (DT | DD)+>
 * This code will still work if a DTD uses a more restrictive model, e.g.,
 * <!ELEMENT DL    - -  (DT+, DD)+> or
 * <!ELEMENT DL    - -  (DT, DD)+>
 * although other typesetting styles would be feasible in this cases.
 * The strategy is to save the entire list to a structure,
 * delaying writing the output until all information is available. A 
 * complication is the possibility of nested definition lists.
 * _uns_ = "unstructured".
 * The 'compact' parameter is 1 if a compact list is to be produced.
 */
void start_uns_def_list(struct stack *stack, int depth, int compact)
{
  struct uns_dl_info *temp_def_list = uns_dl_info; /* Current def list.  */

  uns_dl_info = galloc(sizeof(struct uns_dl_info)); /* New def list.  */
  uns_dl_info->prev = temp_def_list;
  uns_dl_info->uns_dl_entry.next = NULL;
  uns_dl_info->compact = compact;
}

/* Recursively free a list of entries within a uns_dl_info structure.  */
static void free_uns_dl_entry_list(struct uns_dl_entry *entry_list)
{
  if (entry_list->next == NULL)
    return;
  free_uns_dl_entry_list(entry_list->next);
  gfree(entry_list->next);
  if (entry_list->dl_tag != NULL)
    gfree(entry_list->dl_tag);
  if (entry_list->dl_data != NULL)
    gfree(entry_list->dl_data);
  entry_list->next = NULL;
}

/* Free the current link in the dl_info list.  */
static void free_uns_dl_list(void)
{
  /* Pointer to the uns_dl_info structure.  */
  struct uns_dl_info *temp_info;

  free_uns_dl_entry_list(&uns_dl_info->uns_dl_entry);
  temp_info = uns_dl_info;
  uns_dl_info = uns_dl_info->prev;
  gfree(temp_info);
}

/* 'Usual' length of a line.  */
#define NOMINAL_LINE_WIDTH 80
/* The amount of extra space to use between columns of a def list.  */
#define SEP_SPACES 5

/* Write the complete definition list.  */
void end_uns_def_list(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    struct uns_dl_entry *entry;

    /* A line wrap here or in start_uns_def_list would be unwise.  */
    gfputs("\\udlinit");
    output.need_wrap = 1;
    /* Write the test copies of the terms, which TeX will measure before
     * constructing the list.
     */
    entry = &uns_dl_info->uns_dl_entry;
    while (entry->next != NULL) {
      if (entry->dl_tag != NULL) {
	gfprintf("\\udltest{%s}", entry->dl_tag);
	output.need_wrap = 1;
      }
      entry = entry->next;
    }
    /* Write the definition list.  */
    gfputs("\\begin{udl}{");
    if (uns_dl_info->compact)
      gfputs("compact}");
    else
      gfputs("normal}");
    entry = &uns_dl_info->uns_dl_entry;
    while (entry->next != NULL) {
      output.need_wrap = 1;
      if (entry->dl_tag != NULL) {
	gfprintf("\\udltag{%s}", entry->dl_tag);
      }
      if (entry->dl_data != NULL) {
	/* dl_data could be very large: don't use gfprintf.  */
	gfputs("\\udltext{");
	gfputs(entry->dl_data);
	gfputs("}");
      }
      entry = entry->next;
    }
    /* Do not put a linebreak here, to avoid getting extra space.  */
    gfputs("\\end{udl}");
    output.need_wrap = 1;
  }
  else if (c_line.family == FAM_PLAIN || c_line.family == FAM_RTF) {
    struct uns_dl_entry *entry;
    int longest = 0;
    int page_width = output.line_width;
    int got_term = 0;		/* Flag: whether a term has been printed.  */

    /* This gap may get lost occasionally, since the stored text above
     * flushes the output buffer.  If there was no linefeed then, only
     * one linefeed will be printed.
     */
    output.need_gap = 1;

    /* Find the width of the longest term.  */
    entry = &uns_dl_info->uns_dl_entry;
    while (entry->next != NULL) {
      if (entry->dl_tag != NULL) {
	if (strlen(entry->dl_tag) > longest)
	  longest = strlen(entry->dl_tag);
      }
      entry = entry->next;
    }

    /* Limit the column width to roughly a third of a page width.  */
    if (output.line_width > NOMINAL_LINE_WIDTH || output.line_width == 0)
      page_width = NOMINAL_LINE_WIDTH;
    page_width = page_width - strlen(output.lead_text->text);
    if (page_width < 0)
      page_width = 0;
    if (3 * longest > page_width)
      longest = page_width / 3;

    /* Get the final width of the terms column.  */
    longest = longest + SEP_SPACES;

    /* Write the definition list.  */
    entry = &uns_dl_info->uns_dl_entry;
    while (entry->next != NULL) {
      if (entry->dl_tag != NULL) {
	if (got_term) {
	  /* Two consecutive terms.  */
	  output.need_line = 1;
	}
	gfputs(entry->dl_tag);
	if (strlen(entry->dl_tag) > longest) {
	  /* Need to move the definition to the next line.  */
	  output.need_line = 1;
	  got_term = 0;
	}
	else {
	  char bbuffer[NOMINAL_LINE_WIDTH]; /* Temporary space for blanks.  */
	  int fill;		/* Number of blank spaces required.  */

	  fill = longest - strlen(entry->dl_tag);
	  memset(bbuffer, ' ', fill);
	  bbuffer[fill] = '\0';
	  gfputs(bbuffer);
	  got_term = 1;
	}
      }
      if (entry->dl_data != NULL) {
	/* Add blanks to lead_text so definitions are indented.  */
	push_lead_blanks(longest);
	/* if (got_term == 0) lead_text will add leading blanks.  */
	gfputs(entry->dl_data);
	pop_lead_text();
	if (uns_dl_info->compact)
	  output.need_line = 1;
	else
	  output.need_gap = 1;
	got_term = 0;
      }
      entry = entry->next;
    }
    output.need_gap = 1;
  }
  else {
    error(EXIT, 0, "unstructured def list does not support %s",
	  setter_names[c_line.setter]);
  }

  /* Free the current definition list.  */
  free_uns_dl_list();

  if (output.store_text == 0)
    free_storage();

  text.new_par = 1;
}

/* Definition list elements. In each case, store the text then add it
 * to the structure.
 */
void start_uns_def_tag(struct stack *stack, int depth)
{
  start_storage("UNSDT");
}

void end_uns_def_tag(struct stack *stack, int depth)
{
  struct uns_dl_entry *entry = &uns_dl_info->uns_dl_entry;
  struct stored_text *text_ptr = end_storage();
  char *text = text_ptr->text;

  /* Create a new entry with the term data.  */
  while (entry->next != NULL)
    entry = entry->next;
  entry->next = galloc(sizeof(struct uns_dl_entry));
  entry->next->next = NULL;
  entry->dl_tag = galloc(strlen(text) + 1);
  strcpy(entry->dl_tag, text);
  entry->dl_data = NULL;

  /* Hide the stored UNSDT information, so that it doesn't get picked
   * up again later.
   */
  strcpy(text_ptr->key, "");
}

void start_uns_def_data(struct stack *stack, int depth)
{
  start_storage("UNSDD");
}

void end_uns_def_data(struct stack *stack, int depth)
{
  struct uns_dl_entry *entry = &uns_dl_info->uns_dl_entry;
  struct stored_text *text_ptr = end_storage();
  char *text = text_ptr->text;

  /* Create a new entry with the definition data.  */
  while (entry->next != NULL)
    entry = entry->next;
  entry->next = galloc(sizeof(struct uns_dl_entry));
  entry->next->next = NULL;
  entry->dl_data = galloc(strlen(text) + 1);
  strcpy(entry->dl_data, text);
  entry->dl_tag = NULL;

  /* Hide the stored UNSDD information, so that it doesn't get picked
   * up again later.
   */
  strcpy(text_ptr->key, "");
}

