/* Mathematics.
 * Copyright (C) 1993 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "math.h"
#include "text.h"
#include "structure.h"

/* TeX equations.
 * The display argument is 1 if the equation should be displayed,
 * otherwise zero.
 */
void start_texeqn(struct stack *stack, int depth, int display)
{
  if (c_line.family == FAM_TEX) {
    if (display) {
      output.need_wrap = 1;
      gfputs("\\[");
    }
    else
      gfputs("$");
  }
  else if (c_line.family == FAM_PLAIN) {
    char *delimiter;

    if (display) {
      delimiter = check_style("tex-delimiter-display");
      output.need_wrap = 1;
    }
    else
      delimiter = check_style("tex-delimiter-intext");
    gfputs(delimiter);
    if (display)
      output.need_wrap = 1;
  }
  else if (c_line.setter == RTF) {
    char *delimiter;
    if (display) {
      delimiter = check_style("tex-delimiter-display");
      output.need_gap = 1;
      gfputs(delimiter);
      output.need_line = 1;
    }
    else {
      delimiter = check_style("tex-delimiter-intext");
      gfputs(delimiter);
    }
  }
  else if (c_line.setter == TEXINFO) {
    /* Setting up the text is delayed until the end of the equation.  */
    start_storage("TEXEQN");
  }
  if (display)
    set_text_mode(0, 1, 0, 0);
  else
    set_text_mode(0, 1, 0, 1);
}

void end_texeqn(struct stack *stack, int depth, int display)
{
  restore_text_mode();

  if (c_line.family == FAM_TEX) {
    if (display) {
      gfputs("\\]");
      output.need_wrap = 1;
      text.new_par = 1;
    }
    else
      gfputs("$");
  }
  else if (c_line.family == FAM_PLAIN) {
    char *delimiter;

    if (display) {
      delimiter = check_style("tex-delimiter-display");
      output.need_wrap = 1;
      gfputs(delimiter);
      output.need_wrap = 1;
      text.new_par = 1;
    }
    else{
      delimiter = check_style("tex-delimiter-intext");
      gfputs(delimiter);
    }
  }
  else if (c_line.setter == RTF) {
    char *delimiter;

    if (display) {
      delimiter = check_style("tex-delimiter-display");
      output.need_line = 1;
      gfputs(delimiter);
      output.need_par = 1;
      text.new_par = 1;
    }
    else {
      delimiter = check_style("tex-delimiter-intext");
      gfputs(delimiter);
    }
  }
  else if (c_line.setter == TEXINFO) {
    /* Write the equation twice: once for TeX and once for Info.  */
    struct stored_text *link = &stored_text; /* Steps through list.  */
    char *eqn = NULL;		/* Equation text.  */

    end_storage();

    /* Get the stored equation.  */
    link = &stored_text;
    while (link->next != NULL) {
      if (strcmp(link->key, "TEXEQN") == 0)
	eqn = link->text;
      link = link->next;
    }
    if (eqn == NULL) 
      error(EXIT, 0, "missing TeX equation");
    
    /* If a TeX equation occurs in a section title, don't use the full
     * treatment (Texinfo can't process math in a section title).
     */
    if (structure.inheading) {
      gfputs("$");
      set_text_mode(0, 1, 0, 0);
      if (!(text.contents->respect_spaces && text.contents->preserve_breaks)) {
	tidy_string(eqn, text.contents->respect_spaces,
		    text.contents->preserve_breaks);
      }
      print_escaped(eqn, 1, 0, 0);
      restore_text_mode();
      gfputs("$");
    }
    else {
      output.need_wrap = 1;
      gfputs("@tex");
      output.need_wrap = 1;
      if (display) {
	gfputs("$$");
	set_text_mode(0, 1, 0, 1);
      }
      else {
	gfputs("$");
	set_text_mode(0, 1, 0, 0);
      }
      gfputs(eqn);
      restore_text_mode();
      if (display)
	gfputs("$$");
      else
	gfputs("$");
      output.need_wrap = 1;
      gfputs("@end tex");
      output.need_wrap = 1;
      gfputs("@ifinfo");
      output.need_wrap = 1;
      if (display)
	gfputs("$$");
      else
	gfputs("$");
      /* Print the equation again, escaping any Texinfo special chars.  */
      if (!(text.contents->respect_spaces && text.contents->preserve_breaks)) {
	tidy_string(eqn, text.contents->respect_spaces,
		    text.contents->preserve_breaks);
      }
      print_escaped(eqn, 1, 0, 0);
      
      if (display) {
	gfputs("$$");
	text.new_par = 1;
      }
      else
	gfputs("$");
      output.need_wrap = 1;
      gfputs("@end ifinfo");
      output.need_wrap = 1;
    }
    /* Free the stored text, if it's not being stored for some other reason. */
    if (output.store_text == 0)
      free_storage();
  }
}
