/* Document header, chapters, sections etc.
 * Copyright (C) 1993, 1994, 1995, 1996 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "structure.h"
#include "text.h"
#include "displayed.h"
#include "figure.h"
#include "link.h"
#include "header.h"

struct structure structure;
struct info_tree info_tree;

/* Initialize data structures.  */
void init_structure(void)
{
  static int first = 1;		/* Whether this is the first time here.  */
  int i;

  if (first && c_line.setter == TEXINFO) {
    /* Initialize the string which holds the current node.  */
    structure.node_size = 80;
    structure.node = galloc(structure.node_size);
    strcpy(structure.node, "Top");

    /* Initialise the tree structure.  */
    info_tree.node = galloc(strlen("Top") + 1);
    strcpy(info_tree.node, "Top");
    info_tree.title = NULL;
    info_tree.branches.next = NULL;
  }
  structure.infrontm = 1;
  structure.inbackm = 0;
  structure.inheading = 0;
  structure.inappendix = 0;
  for (i = 0; i < MAX_H_LEVEL + 1; i++)
    structure.h_counters[i] = 0;
  
  first = 0;
}

/* Print the document header.  */
void start_document(struct stack *stack, int depth)
{
  if (c_line.setter == LATEX2E) {
    char *packages = check_style("latex2e-packages");
    char *docclass = check_style("latex2e-documentclass");
    char *ps_packages = NULL;
    
    if (figure.got_PostScript)
      ps_packages = check_style("latex2e-ps-packages");
    
    gfputs(docclass);
    output.need_wrap = 1;
    if (packages[0] != '\0') {
      gfputs(packages);
      output.need_wrap = 1;
    }
    if (ps_packages != NULL && ps_packages[0] != '\0') {
      gfputs(ps_packages);
      output.need_wrap = 1;
    }
  }
  /* Do nothing for ASCII.  */
  else if (c_line.setter == RTF) {
    char *fonts = check_style("rtf-fonts");   /* Font table.  */
    char *styles = check_style("rtf-styles"); /* Style table.  */
    char *init = check_style("rtf-init");         /* Misc. controls.  */

    gfprintf("{\\rtf1\\ansi \\deff0{\\fonttbl%s}\n{\\stylesheet%s}",
	     fonts, styles);
    output.need_wrap = 1;
    gfprintf("%s{", init);
    output.need_wrap = 1;
  }
  else if (c_line.setter == TEXINFO) {
    gfputs("\\input texinfo    @c -*-texinfo-*-");
    output.need_wrap = 1;
  }
}

/* Terminate the document and flush the output buffer.  */
void end_document(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\end{document}");
    output_close();
  }
  else if (c_line.family == FAM_PLAIN) {
    output_close();
  }
  else if (c_line.setter == RTF) {
    /* One brace for the paragraph and one for the document.  */
    gfputs("}}");
    output_close();
  }
  else if (c_line.setter == TEXINFO) {
    char *toc_page = check_style("texinfo-toc-page");
      
    if (strcmp(toc_page, "toc-short-always") == 0
	|| (header.need_toc && strcmp(toc_page, "toc-short") == 0)
	|| strcmp(toc_page, "toc-both-always") == 0
	|| (header.need_toc && strcmp(toc_page, "toc-both") == 0)) {
      output.need_wrap = 1;
      gfputs("@shortcontents");
    }
    if (strcmp(toc_page, "toc-long-always") == 0
	|| (header.need_toc && strcmp(toc_page, "toc-long") == 0)
	|| strcmp(toc_page, "toc-both-always") == 0
	|| (header.need_toc && strcmp(toc_page, "toc-both") == 0)) {
      output.need_wrap = 1;
      gfputs("@contents");
    }
    output.need_wrap = 1;
    gfputs("@bye");
    output_close();
  }
}

/* Find a given node within the tree holding the Texinfo document
 * structure.  num_steps is the number of integer counters which
 * should be used from the following array, each of which indicates
 * which branch should be used at a given level.  The counts begin
 * at 0, unlike section numbers perhaps.
 * The function returns NULL if the node does not exist.
 */
struct info_tree
*get_node(struct info_tree *tree, int num_steps, int counters[])
{
  int i, j;
  struct info_tree *tree_ptr = tree;	/* Steps through the tree.  */
  
  for (i = 0; i < num_steps; i++) {
    struct branches *branch_ptr = &tree_ptr->branches; 
    
    /* Move to the required branch of current sub-tree.  */
    for (j = 0; j < counters[i]; j++) {
      if (branch_ptr->next == NULL)
	return(NULL);
      branch_ptr = branch_ptr->next;
    }
    if (branch_ptr->next == NULL)
      return(NULL);
    tree_ptr = branch_ptr->branch;
  }
  return(tree_ptr);
}

/* Search a texinfo tree for a given node name.  Return a pointer to the 
 * node or NULL if not found.
 */
struct info_tree 
*match_node(struct info_tree *tree, char *node)
{
  /* Check the current node, then step through each of its branches
   * recursively calling match_node.
   */
  struct info_tree *tree_ptr = tree; /* Steps through the tree.  */
  struct branches *branch_ptr;	     /* Steps through the branches of a node */

  if (strcmp(tree_ptr->node, node) == 0)
    return(tree_ptr);
  branch_ptr = &tree_ptr->branches;
  while (branch_ptr->next != NULL) {
    if (match_node(branch_ptr->branch, node) != NULL)
      return(branch_ptr->branch);
    branch_ptr = branch_ptr->next;
  }
  /* After trying all the branches, must have failed.  */
  return(NULL);
}

/* Add a new node to the Texinfo tree.  "node" is the name of the node,
 * "title" is its title, depth is the depth in the tree: 1 to create a
 * top-level heading and use one counter from the counters[] array etc.
 * (but this function can not create the "Top" node).
 * "counters" is an array with the section number at each level (numbered 
 * from 0).
 */
void add_node(char *node, char *title, int depth, int counters[])
{
  int i;

  if (counters[depth - 1] == 0) {
    /* Add a new node at a lower level in the tree structure.  */
    struct info_tree *tree_ptr; /* Pointer to the document tree.  */
    
    /* Get the parent node.  */
    if (depth == 1)
      tree_ptr = &info_tree; /* Top node.  */
    else {
      tree_ptr = get_node(&info_tree, depth - 1, counters);
      if (tree_ptr == NULL)
	error(EXIT, 0, "tree out of order for node %s", node);
    }
    /* Make the new branch.  */
    tree_ptr->branches.branch = galloc(sizeof(struct info_tree));
    tree_ptr->branches.next = galloc(sizeof(struct branches));
    tree_ptr->branches.next->next = NULL;
    tree_ptr = tree_ptr->branches.branch;
    tree_ptr->node = node;
    tree_ptr->title = galloc(strlen(title) + 1);
    strcpy(tree_ptr->title, title);
    tree_ptr->branches.next = NULL;
  }
  else {
    /* Make a node at the current level.  */
    struct info_tree *tree_ptr;  /* Pointer to the document tree.  */
    struct branches *branch_ptr; /* Steps through the branches of a node.  */
    
    /* Get the position of the parent node.  */
    tree_ptr = get_node(&info_tree, depth - 1, counters);
    if (tree_ptr == NULL)
      error(EXIT, 0, "tree out of order");
    branch_ptr = &tree_ptr->branches;
    
    /* Step through the existing branches.  */
    for (i = 0; i < counters[depth - 1]; i++) {
      branch_ptr = branch_ptr->next;
      if (branch_ptr == NULL)
	error(EXIT, 0, "tree out of order");
    }
    /* Make the new branch.  */
    branch_ptr->next = galloc(sizeof(struct branches));
    branch_ptr->next->next = NULL;
    branch_ptr->branch = galloc(sizeof(struct info_tree));
    tree_ptr = branch_ptr->branch;
    tree_ptr->node = node;
    tree_ptr->title = galloc(strlen(title) + 1);
    strcpy(tree_ptr->title, title);
    tree_ptr->branches.next = NULL;
  }
}

/* Escape characters which can not appear in a node name.  This is done
 * in-place, with the string assumed writable.
 */
void escape_node_name(char *text)
{
  char *ptr = text;		/* Steps through the string.  */

  tidy_string (text, 0, 0);
  while (*ptr != '\0') {
    if (*ptr == '@')
      *ptr = '*';
    else if (*ptr == ',')
      *ptr = ';';
    else if (*ptr == ':')
      *ptr = ';';
    else if (*ptr == '\'')
      *ptr = '^';
    else if (*ptr == '`')
      *ptr = '^';
    else if (*ptr == '{')
      *ptr = '(';
    else if (*ptr == '}')
      *ptr = ')';
    
    ptr++;
  }
}

/* Format a section number.  */
static char *sect_num(int section)
{
  char temp[5];
  static char sect_string[30];
  int i;
  
  sect_string[0] = '\0';
  for (i = 1; i <= section; i++) {
    /* If in appendix, use letters for top level sections.  */
    if (structure.inappendix && i == 1)
      sprintf(temp, "%c", (char) (structure.h_counters[i] + 'A' - 1));
    else 
      sprintf(temp, "%d", structure.h_counters[i]);
    strcat(sect_string, temp);
    if (i < section)
      strcat(sect_string, ".");
  }
  return(sect_string);
}

/* The head_level argument supplies the depth of the nested heading.
 * The store argument is 1 if the document structure is to be stored, or 0
 * if printed output is to be produced.
 */
void start_heading(struct stack *stack, int depth, int head_level, int store)
{
  struct attr *id = query_attribute(&stack[-1], "ID");

  if (head_level < 0 || head_level > MAX_H_LEVEL)
    error(EXIT, 0, "illegal heading level");

  if (c_line.family == FAM_TEX) {
    if (head_level == 0) {
      output.need_wrap = 1;
      gfputs("\\part{");
    }
    else if (head_level == 1) {
      output.need_wrap = 1;
      gfputs("\\section{");
    }
    else if (head_level == 2) {
      output.need_wrap = 1;
      gfputs("\\subsection{");
    }
    else if (head_level == 3) {
      output.need_wrap = 1;
      gfputs("\\subsubsection{");
    }
    else if (head_level == 4) {
      output.need_wrap = 1;
      gfputs("\\paragraph{");
    }
    else { /* Enough already.  */
      output.need_wrap = 1;
      gfputs("\\subparagraph{");
    }
    if (id != NULL && strcmp(id->type, "IMPLIED") != 0)
      gfprintf("\\label{%s}", id->values);
  }
  else if (c_line.family == FAM_PLAIN) {
    char *num_depth_string = check_style("num-depth");
    int num_depth;		/* Greatest heading level to be numbered.  */
    int i;
    char *ptr;

    if ((structure.infrontm || structure.inbackm) && store == 0) {
      /* General DTD begins abstract etc., with a heading.  */
      output.need_gap = 1;
    }
    else {
      num_depth = strtol(num_depth_string, &ptr, 10);
      /* Increment the counter and zero the counters with a lower level.  */
      structure.h_counters[head_level]++;
      for (i = head_level + 1; i < MAX_H_LEVEL; i++)
	structure.h_counters[i] = 0;

      if (store) {
	/* Collect possible cross-ref targets.  */
	if (id != NULL && strcmp(id->type, "IMPLIED") != 0) {
	  char *sect_string =  sect_num(head_level);
	  add_cross_ref(id->values, NULL, sect_string);
	}
      }
      else {
	output.need_gap = 1;
	if (num_depth >= head_level) {
	  char *sect_string =  sect_num(head_level);
	
	  gfprintf("%s ", sect_string);
	}
      }
    }
  }
  else if (c_line.setter == RTF) {
    char *num_depth_string = check_style("num-depth");
    int num_depth;		/* Greatest heading level to be numbered.  */
    int i;
    char *ptr;
    char *font; 
    char *style;
    char style_name[20];
      
    if (structure.infrontm || structure.inbackm) {
      if (store == 0) {
	/* Get the links to the font and style.  */
	sprintf(style_name, "fht%d", head_level);
	font = check_style(style_name);
	sprintf(style_name, "sht%d", head_level);
	style = check_style(style_name);
	
	gfputs("\\sect");
	output.need_wrap = 1;
	gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
      }
    }
    else {
      num_depth = strtol(num_depth_string, &ptr, 10);
      /* Increment the counter and zero the counters with a lower level.  */
      structure.h_counters[head_level]++;
      for (i = head_level + 1; i < MAX_H_LEVEL; i++)
	structure.h_counters[i] = 0;

      if (store) {
	/* Collect possible cross-ref targets.  */
	if (id != NULL && strcmp(id->type, "IMPLIED") != 0) {
	  char *sect_string =  sect_num(head_level);
	  add_cross_ref(id->values, NULL, sect_string);
	}
      }
      else {
	/* Get the links to the font and style.  */
	sprintf(style_name, "fht%d", head_level);
	font = check_style(style_name);
	sprintf(style_name, "sht%d", head_level);
	style = check_style(style_name);
	
	gfputs("\\sect");
	output.need_wrap = 1;
	gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
	if (num_depth >= head_level) {
	  char *sect_string =  sect_num(head_level);
	
	  gfprintf("%s ", sect_string);
	}
      }
    }
  }
  else if (c_line.setter == TEXINFO) {
    /* Start storage of the section title.  Setting up the section 
     * information is deferred until the end of the title.
     */
    start_storage("HEADING");
    output.discard_text = 0;	/* Need to collect this text.  */
    text.new_par = 1;
  }
  structure.inheading = 1;
}

/* The head_level argument supplies the depth of the nested heading.
 * The store argument is 1 if the document structure is to be stored, or 0
 * if printed output is to be produced.
 */

void end_heading(struct stack *stack, int depth, int head_level, int store)
{
  if (head_level < 0 || head_level > MAX_H_LEVEL)
    error(EXIT, 0, "illegal heading level");

  structure.inheading = 0;

  if (c_line.family == FAM_TEX) {
    gfputs("}");
    output.need_wrap = 1;
  }
  else if (c_line.family == FAM_PLAIN && store == 0) {
    output.need_gap = 1;
  }
  else if (c_line.setter == RTF && store == 0) {
    output.need_gap = 1;
  }
  else if (c_line.setter == TEXINFO) {
    struct stored_text *link = end_storage(); /* Steps through list.  */
    char *num_depth_string = check_style("num-depth");
    int num_depth;		/* Greatest heading level to be numbered.  */
    int i;
    char *ptr;			/* Dummy pointer.  */
    char *heading = NULL;	/* section heading */
    struct attr *id = query_attribute(&stack[-1], "ID");

    if (store)
      output.discard_text = 1;	/* Continue discarding text.  */
    if (structure.infrontm || structure.inbackm) {
      if (store == 0) {
	/* General DTD begins abstract and preface with a heading.  */
	output.need_wrap = 1;
	gfputs("@unnumberedsec ");
	/* Get the stored section title.  */
	while (link->next != NULL) {
	  if (strcmp(link->key, "HEADING") == 0)
	    gfputs(link->text);
	  link = link->next;
	}
	output.need_wrap = 1;
      }
    }
    else {
      num_depth = strtol(num_depth_string, &ptr, 10);
      /* Increment the counter and zero the counters with a lower level. 
       * Texinfo will generate its own section numbers when formatting;
       * these numbers are used for node titles if needed.
       */
      structure.h_counters[head_level]++;
      for (i = head_level + 1; i < MAX_H_LEVEL; i++)
	structure.h_counters[i] = 0;

      if (store) {
	/* Save the document structure to a tree.  */
	char *titles;		/* Value of the node-titles attribute.  */
	char *node_name = NULL;	/* What to name this node.  */
	char label[50];		/* Temporary string for node name.  */
	int count;		/* Counter for non-unique node names.  */
	char *temp_name;	/* Temporary name when node non-unique.  */
	char *sect_number = sect_num(head_level); /* Section number.  */
	int counters[MAX_H_LEVEL]; /* Temporary counters for add_node().  */

	/* Get the stored section title.  */
	while (link->next != NULL) {
	  if (strcmp(link->key, "HEADING") == 0)
	    heading = link->text;
	  link = link->next;
	}
	
	/* Get the method of node naming from the style sheet.  */
	titles = check_style("node-titles");

	if (strcmp(titles, "use-titles") == 0) {
	  /* Don't free this memory: goes into the tree.  */
	  node_name = galloc(strlen(heading) + 1);
	  strcpy(node_name, heading);
	}
	if (node_name != NULL) {
	  /* Substitute characters which don't work in node names.  */
	  escape_node_name(node_name);
	}
	else {
	  /* Use the section number as the node name.  */
	  if (head_level == 1)
	    strcpy(label, "chapter ");
	  else {
	    label[0] = '\0';
	    for (i = 2; i < head_level; i++)
	      strcat(label, "sub");
	    strcat(label, "section ");
	  }
	  strcat(label, sect_number);
	  node_name = galloc(strlen(label) + 1);
	  strcpy(node_name, label);
	}
	/* Change the node name if it's not unique.  */
	count = 1;		/* First number will be (2).  */
	temp_name = NULL;
	while (match_node(&info_tree, node_name) != NULL) {
	  count++;
	  if (count == 2) {
	    node_name = grealloc(node_name, strlen(node_name) + 10);
	    temp_name = galloc(strlen(node_name) + 1);
	    strcpy(temp_name, node_name);
	  }
	  sprintf(node_name, "%s (%d)", temp_name, count);
	}
	if (temp_name != NULL)
	  gfree(temp_name);

	/* Save the name of the node for cross referencing.  */
	if (strlen(node_name) + 1 > structure.node_size) {
	  structure.node_size = strlen(node_name) + 1;
	  structure.node = grealloc(structure.node, structure.node_size);
	}
	strcpy(structure.node, node_name);

	/* Create an actual cross reference target if needed.  */
	if (id != NULL && strcmp(id->type, "IMPLIED") != 0)
	  add_cross_ref(id->values, node_name, sect_number);
      
	/* Set up zeroed counters.  */
	for (i = 0; i < head_level; i++) {
	  counters[i] = structure.h_counters[i + 1] - 1;
	  if (i == 0 && structure.inappendix) 
	    counters[i] += structure.max_h;
	}
	displayed.note_counter = 0;
	figure.fig_counter = 0;
	/* Create the new node.  */
	add_node(node_name, heading, head_level, counters);
      }
      else {
	/* Create and print the nodes.  */
	/* Temporary array of counters for get_node().  */
	int counters[MAX_H_LEVEL];
	struct info_tree *tree_ptr; /* Pointer to the document tree.  */
	struct info_tree *this;	/* Pointer to the document tree, this node.  */
	struct branches *branch_ptr; /* Steps through the branches of a node */
	char *prev;		/* String with the previous node.  */
	char *next;		/* String with the next node.  */
	char *up;		/* String with the up node.  */

	/* Get the previous node.  */
	for (i = 0; i < head_level; i++) {
	  counters[i] = structure.h_counters[i + 1] - 1;
	  if (i == 0 && structure.inappendix) 
	    counters[i] += structure.max_h;
	}
	if (counters[head_level - 1] == 0)
	  tree_ptr = get_node(&info_tree, head_level - 1, counters);
	else {
	  counters[head_level - 1]--;
	  tree_ptr = get_node(&info_tree, head_level, counters);
	  counters[head_level - 1]++;
	}
	prev = tree_ptr->node;

	/* Get the current node.  */
	this = get_node(&info_tree, head_level, counters);
	/* Get the next node.  */
	counters[head_level - 1]++;
	tree_ptr = get_node(&info_tree, head_level, counters);
	counters[head_level - 1]--;
	if (tree_ptr == NULL)
	  next = "";
	else
	  next = tree_ptr->node;

	/* Get the up node.  */
	tree_ptr = get_node(&info_tree, head_level - 1, counters);
	up = tree_ptr->node;	/* tree_ptr used again below.  */

	/* Create a menu if this is a deeper level.  */
	if (counters[head_level - 1] == 0) {
	  output.need_wrap = 1;
	  gfputs("@menu");
	  output.need_wrap = 1;
	  /* Step through the branches of the parent node.  */
	  branch_ptr = &tree_ptr->branches;
	  while (branch_ptr->next != NULL) {
	    gfprintf("* %s::", branch_ptr->branch->node);
	    if (branch_ptr->branch->title != NULL) {
	      if (strcmp(branch_ptr->branch->title, 
			 branch_ptr->branch->node) != 0) {
		/* Print the full title if it's not the node name.  */
		gfprintf("     %s", branch_ptr->branch->title);
	      }
	    }
	    output.need_wrap = 1;
	    branch_ptr = branch_ptr->next;
	  }
	  gfputs("@end menu");
	  output.need_wrap = 1;
	}
      
	/* Create the node.  */
	displayed.note_counter = 0;
	figure.fig_counter = 0;
	output.need_wrap = 1;
	gfprintf("@node %s,%s,%s,%s", this->node, next, prev, up);
	output.need_wrap = 1;
	if (head_level == 1) {
	  if (structure.inappendix)
	    gfputs("@appendix ");
	  else if (num_depth < head_level)
	    gfputs("@unnumbered ");
	  else
	    gfputs("@chapter ");
	}
	else if (head_level == 2) {
	  if (num_depth < head_level)
	    gfputs("@unnumberedsec ");
	  else {
	    if (structure.inappendix)
	      gfputs("@appendixsec ");
	    else
	      gfputs("@section ");
	  }
	}
	else if (head_level == 3) {
	  if (num_depth < head_level)
	    gfputs("@unnumberedsubsec ");
	  else {
	    if (structure.inappendix)
	      gfputs("@appendixsubsec ");
	    else 
	      gfputs("@subsection ");
	  }
	}
	else if (head_level == 4) {
	  if (num_depth < head_level)
	    gfputs("@unnumberedsubsubsec ");
	  else {
	    if (structure.inappendix)
	      gfputs("@appendixsubsubsec ");
	    else
	      gfputs("@subsubsection ");
	  }
	}
	else {
	  gfputs("@unnumberedsubsubsec ");
	}
	gfputs(this->title);
	output.need_wrap = 1;
      }
    }
    /* Free the stored text, if not storing for some other reason.  */
    if (output.store_text == 0)
      free_storage();
  }
  text.new_par = 1;
}

void start_appendix(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\appendix");
    output.need_wrap = 1;
  }
  structure.inappendix = 1;
  structure.max_h = structure.h_counters[1];
  /* Reset the top level section counter.  */
  structure.h_counters[1] = 0;
}
