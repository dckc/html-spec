/* Header for cross references.  */

struct xlink {
  /* A linked list of cross-reference pointers */
  struct cross_ref {
    char *label;		/* May be set up during the first pass */
    char *node;			/* of the document, and used during the */
    char *value;		/* second. */
    struct cross_ref *next;
  } cross_ref;
};

extern struct xlink xlink;

extern struct cross_ref *find_cross_ref(char *label);
extern void add_cross_ref(char *label, char *node, char *value);
extern void start_reference(struct stack *stack, int depth);
extern void start_long_reference(struct stack *stack, int depth, int page);
