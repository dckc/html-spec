/* Header for text phrases.  */

#define MAX_HP_LEVEL 3

struct text {
  int par_pending;              /* Controls paragraph separation code.  */
  int aline_pending;            /* Controls the separation of lines.  */
  int new_par;                  /* Controls whether to trim leading blanks.  */

  /* A linked list with flags describing the current element text --
   * whether spaces and line breaks are significant, and whether a
   * typewriter font should be used.  A new link is added to the list
   * whenever an element with non-standard contents is processed
   * (standard == that used in normal text, set up at the initialization
   * stage).  When the element ends, the link is removed.
   */
  struct contents {
    int tt;			/* 1 if typewriter font is used.  */
    int math;			/* 1 if mathematics content.  */
    int respect_spaces;		/* 1 if multiple spaces are preserved.  */
    int preserve_breaks;	/* 1 if linebreaks should be preserved.  */
    struct contents *prev;	/* Pointer to the previous link.  */
  } *contents;
};

extern struct text text;

extern void init_text(void);
extern void set_text_mode(int tt, int math, int respect_spaces,
			  int preserve_breaks);
extern void restore_text_mode(void);
extern void default_text_mode(void);
extern void start_paragraph(struct stack *stack, int depth);
extern void end_paragraph(struct stack *stack, int depth);

extern void start_shortquote(struct stack *stack, int depth);
extern void end_shortquote(struct stack *stack, int depth);

extern void start_phrase(struct stack *stack, int depth);
extern void end_phrase(struct stack *stack, int depth);

extern void start_emphasize(struct stack *stack, int depth);
extern void end_emphasize(struct stack *stack, int depth);
extern void start_bold(struct stack *stack, int depth);
extern void end_bold(struct stack *stack, int depth);
extern void start_italic(struct stack *stack, int depth);
extern void end_italic(struct stack *stack, int depth);
extern void start_underline(struct stack *stack, int depth);
extern void end_underline(struct stack *stack, int depth);

extern void start_code_inline(struct stack *stack, int depth);
extern void end_code_inline(struct stack *stack, int depth);
