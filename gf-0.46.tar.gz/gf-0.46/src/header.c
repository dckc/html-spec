/* Elements in the header of a document. 
 * Copyright (C) 1993, 1994, Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "header.h"
#include "text.h"

struct header header;

/* Initialize header data structures.  */
void init_header(void)
{
  header.need_titlepage = 0;
  header.need_toc = 0;
}

/* A single header line.  */
void start_aline(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    if (text.aline_pending) {
      gfputs("\\\\");
      output.need_wrap = 1;
    }
  }
  else {
    char *header_line = stack[-1].element; /* Element outside the line.  */

    start_storage(header_line);
  }
  text.new_par = 1;		/* Delete leading space.  */
}

void end_aline(struct stack *stack, int depth)
{
  /* text.aline_pending should be set to 0 by any other end element.  */
  text.aline_pending = 1;
  if (c_line.family != FAM_TEX)
    end_storage();
}

void start_copyrite(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX)
    gfputs("\\copyrite{");
  else 
    start_storage("COPYRITE");    
  text.new_par = 1;		/* Delete leading space.  */
}

/* <noprint> element, embedded within <copyrite>.  */
void start_copy_noprint(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    /* Text not to be printed gets commented out.  */
    gfputs("%");
    /* Append a % to subsequent lines.  */
    push_lead_text("%");
  }
  else if (c_line.setter == TEXINFO) {
    output.need_wrap = 1;
    gfputs("@ignore");
    output.need_wrap = 1;
  }
  /* ASCII and RTF just write the <noprint> element normally.  */
}

void end_copy_noprint(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    /* Reset the lead text.  */
    pop_lead_text();
    output.need_wrap = 1;
  }
  else {
    if (c_line.setter == TEXINFO) {
      output.need_wrap = 1;
      gfputs("@end ignore");
      output.need_wrap = 1;
    }
  }
}

/* Table of contents.  */
void start_toc(struct stack *stack, int depth) 
{
  if (c_line.family == FAM_TEX) {
    char *toc_page = check_style("toc-page");

    if (strcmp(toc_page, "toc-omit") != 0
	&& strcmp(toc_page, "toc-always") != 0) {
      /* In case of toc-always, gftoc is written elsewhere.  */
      gfputs("\\gftoc");
      output.need_wrap = 1;
    }
  }
  else if (c_line.setter == TEXINFO)
    header.need_toc = 1;
}

/* List of figures.  */
void start_lof(struct stack *stack, int depth) 
{
  if (c_line.family == FAM_TEX) {
    char *lof_page = check_style("lof-page");

    if (strcmp(lof_page, "lof-omit") != 0
	&& strcmp(lof_page, "lof-always") != 0) {
      /* In case of lof-always, gflof is written elsewhere.  */
      gfputs("\\gflof");
      output.need_wrap = 1;
    }
  }
}
