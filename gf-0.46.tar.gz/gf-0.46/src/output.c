/* Low level output functions.  These should be the only functions which
 * write to the output stream directly.
 * Copyright (C) 1993, 1994, 1995 Gary Houston
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "gf.h"

static char *o_buffer = NULL;	/* Fixed width text to be printed.  */
static int o_buffer_size;	/* Size of the buffer.  */
static int o_buffer_length;	/* String length.  */

/* Print the contents of the fixed output buffer, followed by the current
 * newline string.  Then set the buffer to the current lead_text string.
 * The physical line breaking here
 * need not correspond to an actual line break in the text.  E.g., might
 * want TeX output restricted to 80 cols, but do not want these breaks
 * to appear after TeX processes the document.
 * If fixed width output is used, the output.alignment flag controls
 * whether to left-align or centre the text.
 * After flushing, if the newline parameter is non-zero, prints the 
 * current newline character.
 */

static void o_flush(int newline)
{
  if (output.store_text) {
    if (newline) {
      /* '\n' will be mapped to the output.new_line string when the stored
       * text gets printed.
       */
      store_text("\n");
    }
  }
  else if (output.line_width == 0) {
    /* Not using output buffer.  */
    if (newline) {
      fputs(output.new_line, output.stream);
      if (output.lead_text->text[0] != '\0')
	fputs(output.lead_text->text, output.stream);
    }
  }
  else if (o_buffer_length > 0) {
    if (output.alignment == CENTRE) {
      /* Print whitespace to centre the line of text.  */
      int pad = (output.line_width - o_buffer_length) / 2 - 1;
      int i;

      for (i = 0; i < pad; i++)
	putc(' ', output.stream);
    }
    fputs(o_buffer, output.stream);
    o_buffer_length = 0;
    o_buffer[0] = '\0';
    if (newline) {
      fputs(output.new_line, output.stream);
      strcpy(o_buffer, output.lead_text->text);
      o_buffer_length = strlen(output.lead_text->text);
    }
  }
}

/* Start a new line in the physical document (i.e., will not necessarily
 * appear in final output).
 */
static void output_wrap(void) {
  output.need_gap = 0;
  output.need_par = 0;
  output.need_line = 0;
  output.need_wrap = 0;

  if (output.line_width == 0 || o_buffer_length != 0 || output.store_text) {
    o_flush(1);
  }
}

/* Start a new paragraph.  */
static void output_par(void)
{ 
  output.need_gap = 0;
  output.need_par = 0;
  output.need_line = 0;
  output.need_wrap = 0;

  /* \n below will automatically be remapped to the newline string.  */
  if (c_line.family == FAM_TEX) {
    gfputs("\\par");
    output_wrap();
  }
  else if (c_line.family == FAM_PLAIN) {
    output_wrap();
    gfputs("\n");
  }
  else if (c_line.setter == RTF) {
    /* Never call gfprintf iteratively: it uses a static buffer.  */
    gfputs("}\\par\n");
    gfputs(output.new_par);
  }
  else if (c_line.setter == TEXINFO) {
    output_wrap();
    gfputs("\n");
  }
}

/* Produce some vspace in the "logical" document, e.g.,
 * for separating paragraphs or the begining of a list
 */
static void output_gap(void) 
{
  int need_par = output.need_par; /* Avoid recursion problems.  */

  output.need_gap = 0;
  output.need_line = 0;
  output.need_par = 0;
  output.need_wrap = 0;

  if (c_line.family == FAM_TEX) {
    /* Will often be done automatically in LaTeX by \begin{...} etc.
     * should not really use \par
     */
    gfputs("\\par");
    if (need_par == 0)
      gfputs("\\noindent");
    output_wrap();
  }
  else if (c_line.setter == TEXINFO) {
    output_par();
    if (need_par == 0) {
      gfputs("@noindent");
      output_wrap();
    }
  }
  else if (c_line.family == FAM_PLAIN || c_line.setter == RTF
	   || c_line.setter == TEXINFO) {
    output_par();
  }
}

/* Start a new line in the logical document (i.e., will appear 
 * in final output).
 */
static void output_line(void)
{
  output.need_gap = 0;
  output.need_par = 0;
  output.need_line = 0;
  output.need_wrap = 0;

  if (c_line.family == FAM_TEX) {
    gfputs("\\newline");
    output_wrap();
  }
  else if (c_line.family == FAM_PLAIN) {
    output_wrap();
  }
  else if (c_line.setter == RTF) {
    gfputs("\\line");
    output_wrap();
  }
  else if (c_line.setter == TEXINFO) {
    gfputs("@*");
    output_wrap();
  }
}

/* Write a piece of text, which is a printf-style format string with
 * optional args.  In one case the text can be printed directly, otherwise
 * it is printed into a buffer and passed to gfputs().
 */

/* Beware: the length of the string is not checked dynamically at
 * present.
 */
#define MAX_LENGTH 5000

void gfprintf(char *text, ...)
{
  va_list args;

  if (output.line_width == 0 && output.store_text == 0) {
    /* Can print the text immediately to the output stream.  */

    /* Take care of any pent-up need for a gap, paragraph, etc. */
    if (output.need_gap)
      output_gap();
    else if (output.need_par)
      output_par();
    else if (output.need_line)
      output_line();
    else if (output.need_wrap)
      output_wrap();

    va_start(args, text);
    vfprintf(output.stream, text, args);
    va_end(args);
  }
  else {
    static char *in = NULL;	/* Buffer for the formatted string.  */ 
    static int in_size;		/* Size of the buffer.  */

    /* Initialise the input buffer if needed.  */
    if (in == NULL) {
      in_size = MAX_LENGTH;
      in = galloc(MAX_LENGTH);
    }

    /* Print the string into the buffer.  */
    va_start(args, text);
    vsprintf(in, text, args);
    va_end(args);
    
    gfputs(in);
  }
}

/* Write a text string.  The output stream and control and status indicators
 * are obtained from the global structure "output".  When printing
 * to a fixed width, an internal buffer is maintained which holds
 * text not yet printed.  Alternatively, the text may be stored in a
 * linked list rather than printed.
 */
void gfputs(char *text)
{
  /* Take care of any pent-up need for a gap, paragraph, etc., unless
   * the current string is just white space.
   */
  if (output.need_gap) {
    char *tptr = text;

    for (; *tptr != '\0'; tptr++) {
      if (*tptr != ' ') {
	output_gap();
	break;
      }
    }
  }
  else if (output.need_par) {
    char *tptr = text;

    for (; *tptr != '\0'; tptr++) {
      if (*tptr != ' ') {
	output_par();
	break;
      }
    }
  }
  else if (output.need_line) {
    char *tptr = text;

    for (; *tptr != '\0'; tptr++) {
      if (*tptr != ' ') {
	output_line();
	break;
      }
    }
  }
  else if (output.need_wrap) {
    char *tptr = text;

    for (; *tptr != '\0'; tptr++) {
      if (*tptr != ' ') {
	output_wrap();
	break;
      }
    }
  }
  /* Hack for TeX: if a double opening quote has just been printed, need to
   * insert a thinspace if the next character is a single opening quote.
   */
  else if (output.done_open_quote && *text == '`') {
    if (c_line.family == FAM_TEX)
      gfputs("\\thinspace");	/* Always followed by `.  */
    else if (c_line.setter == TEXINFO) {
      gfputs("@iftex");
      output.need_wrap = 1;
      gfputs("@thinspace");
      output.need_wrap = 1;
      gfputs("@end iftex");
      output.need_wrap = 1;
      output_flush();		/* Flush the buffer.  */
    }
  }

  if (output.done_open_quote)
    output.done_open_quote = 0;

  if (output.line_width == 0 && output.store_text == 0) {
    /* Can print the text immediately to the output stream, but replace
     * embedded newlines with the current newline character.
     */
    char *ptr = text;		/* Steps through the string.  */

    while (*ptr != '\0') {
      if (*ptr == '\n') {
	fputs(output.new_line, output.stream);
	if (output.lead_text->text[0] != '\0')
	  fputs(output.lead_text->text, output.stream);
      }
      else
	putc(*ptr, output.stream);
      ptr++;
    }
    /* TeX hack: if the last character is an apostrophe, record 
     * that in case a closing double quote is encountered next.
     */
    if (c_line.family == FAM_TEX || c_line.setter == TEXINFO) {
      if (ptr != text && *(ptr - 1) == '\'')
	output.done_apost = 1;
      else
	output.done_apost = 0;
    }
  }
  else  if (output.store_text == 0) {
    /* If not storing text, copy the string to the current buffer,
     * checking for possible line breaks.
     */
    char *ptr;			/* Steps through the input string.  */

    /* Initial allocation of the fixed text buffer.  */
    if (o_buffer == NULL) {
      o_buffer_size = output.line_width + 1;
      o_buffer = galloc(o_buffer_size);
      strcpy(o_buffer, output.lead_text->text);
      o_buffer_length = strlen(output.lead_text->text);
    }
    
    /* Expand the fixed text buffer, if for some reason the line
     * width has increased.
     */
    if (output.line_width + 1 > o_buffer_size) {
      o_buffer_size = output.line_width + 1;
      o_buffer = grealloc(o_buffer, o_buffer_size);
    }
    /* Copy the text to the output buffer, creating a new line whenever
     * needed.
     */
    ptr = text;
    while (*ptr != '\0') {
      char *start = ptr;	/* Marks the start of a word.  */
      int word_length;
      
      /* Read a word, including leading blanks.  */
      while (*ptr == ' ')
	ptr++;
      while (*ptr != ' ' && *ptr != '\0' && *ptr != '\n') 
	ptr++;
      if (*ptr == '\n') {
	/* Explicit line break.  */
	word_length = ptr - start;
	if (o_buffer_length + word_length + 1 > output.line_width) {
	  /* The current word overflows the buffer, so a second line
	   * break is probably needed.
	   */
	  if (o_buffer_length > 0)
	    o_flush(1);
	}
	else {
	  /* Just clear out the buffer.  */
	  o_flush(0);
	}
	/* Print the current word.  It won't get centred though.  */
	while (start < ptr)
	  fputc(*start++, output.stream);
	/* Do the line break.  */
	fputs(output.new_line, output.stream);
	if (output.lead_text->text[0] != '\0') {
	  strcpy(o_buffer, output.lead_text->text);
	  o_buffer_length = strlen(output.lead_text->text);
	}
	ptr++;
      }
      else {
	word_length = ptr - start;
	if (o_buffer_length + word_length + 1 > output.line_width) {
	  /* The current word overflows the output buffer: linebreak.  */
	  
	  /* If the buffer is empty, print the (presumably) long word.  */
	  if (o_buffer_length <= strlen(output.lead_text->text)) {
	    fputs(o_buffer, output.stream);
	    while (start < ptr)
	      fputc(*start++, output.stream);
	    fputs(output.new_line, output.stream);
	    strcpy(o_buffer, output.lead_text->text);
	    o_buffer_length = strlen(output.lead_text->text);
	  }
	  else if (*start == ' ') {
	    /* If the new word begins with a space, can break here.  */
	    o_flush(1);
	    /* retry the current word, after removing space */
	    ptr = start;
	    while (*ptr == ' ' && *ptr != '\0')
	      ptr++;
	  }
	  else {
	    char *o_ptr; /* Gets set to the break point.  */
	    
	    /* New word does not begin with a space: search back for 
	     * the first space to break.
	     */
	    o_ptr = o_buffer + o_buffer_length - 1;
	    while (*o_ptr != ' ' && o_ptr !=
		   o_buffer + strlen(output.lead_text->text)) {
	      o_ptr--;
	    }
	    if (o_ptr == o_buffer + strlen(output.lead_text->text)) {
	      /* The whole line is a single word. */
	      /* Print the buffer contents without a newline. */
	      o_flush(0);
	      /* Try the current word again.  */
	      ptr = start;
	    }
	    else { /* Found a line break.  */
	      char *temp_ptr = o_buffer; /* Steps through the o_buffer.  */
	      
	      /* Print the buffer up to the break point, and print a 
	       * newline.
	       */
	      while (temp_ptr < o_ptr)
		fputc(*temp_ptr++, output.stream);
	      fputs(output.new_line, output.stream);
	      
	      strcpy(o_buffer, output.lead_text->text);
	      o_buffer_length = strlen(output.lead_text->text);

	      /* Move the text after the break point to the start 
	       * of the buffer, after deleting spaces.
	       */
	      while (*o_ptr == ' ' && *o_ptr != '\0')
		o_ptr++;
	      temp_ptr = o_buffer + o_buffer_length;
	      while (*o_ptr != '\0')
		*temp_ptr++ = *o_ptr++;
	      *temp_ptr = '\0';
	      o_buffer_length = temp_ptr - o_buffer;
	      /* Go back and try the current word again.  */
	      ptr = start;
	    }
	  }
	}
	else { /* Current word fits in output buffer.  */
	  while (start < ptr)
	    o_buffer[o_buffer_length++] = *start++;
	  o_buffer[o_buffer_length] = '\0';
	}
      }
    }
    /* TeX hack: if the last character is an apostrophe, record 
     * that in case a closing double quote is encountered next.
     */
    if (c_line.family == FAM_TEX || c_line.setter == TEXINFO) {
      if (ptr != text && *(ptr - 1) == '\'')
	output.done_apost = 1;
      else
	output.done_apost = 0;
    }
  }
  else {
    /* Store the text in the stored_text structure.  */
    store_text(text);
  }
}

/* Terminate the document: flush output buffer if needed and write newline.  */
void output_close()
{
  if (output.line_width == 0 || o_buffer_length != 0) {
    o_flush(1);
  }
}

/* Execute any pending line/paragraph/etc. breaks.  */
void output_flush(void)
{
  if (output.need_gap)
    output_gap();
  else if (output.need_par)
    output_par();
  else if (output.need_line)
    output_line();
  else if (output.need_wrap)
    output_wrap();
}

/* Functions which store text, rather than printing immediately.  */

/* Initialise storage for a given key.  This sets up a link in the list
 * where any text sent for printing will be stored.  If storage is already
 * in progress, push information onto a stack so that is can be recovered
 * later.
 */
void start_storage(char *key)
{
  struct stored_text *link = &stored_text;	/* Steps through the list.  */
  struct pointers *temp_ptr;			/* Temporary pointer.  */
  
  /* Take care of any pent-up needs.  */
  /* This may not be ideal, since the text following the start of the
   * storage may have its own line wrap etc., so two would be produced.
   * However, if this is not done here, garbage may be introduced to
   * the beginning of the stored text, e.g., \n\n@noindent\n.
   */
  if (output.need_gap)
    output_gap();
  else if (output.need_par)
    output_par();
  else if (output.need_line)
    output_line();
  else if (output.need_wrap)
    output_wrap();
  else {
    /* Clear out any current buffer contents.  */
    o_flush(0);
  }

  /* Find the end of the linked list and create a new link.  */
  while (link->next != NULL)
    link = link->next;

  link->next = galloc(sizeof(struct stored_text));
  link->key = galloc(strlen(key) + 1);
  strcpy(link->key, key);
  link->text = galloc(1);
  link->text[0] = '\0';
  link->next->next = NULL;

  /* Create a pointer to the place where text is to be stored.  */
  temp_ptr = galloc(sizeof(struct pointers));
  temp_ptr->prev = output.pointers;
  temp_ptr->store_ptr = link;
  output.pointers = temp_ptr;

  /* Flag that the text is being stored.  */
  output.store_text = 1;
}

/* Remove the most recent storage process from the list (but don't
 * free the stored text).  Returns a pointer to the stored text.
 */
struct stored_text *end_storage(void)
{
  struct pointers *temp_ptr = output.pointers; /* Save the old link.  */
  struct stored_text *text_ptr = temp_ptr->store_ptr; /* Point to the text.  */
 
  if (output.need_gap)
    output_gap();
  else if (output.need_par)
    output_par();
  else if (output.need_line)
    output_line();
  else if (output.need_wrap)
    output_wrap();
 
  output.pointers = output.pointers->prev;
  gfree(temp_ptr);
  if (output.pointers == NULL)
    output.store_text = 0;
  return(text_ptr);
}

/* Search for a key in the stored text list.  Return a pointer to the
 * link.  The "next" member will be NULL if the lookup failed.
 */
struct stored_text *get_stored_text(char *key)
{
  struct stored_text *ptr = &stored_text;	/* Steps through the list.  */
  
  while (ptr->next != NULL && strcmp(ptr->key, key) != 0)
    ptr = ptr->next;

  return(ptr);
}

/* Add text to the current link.  */
void store_text (char *text)
{
  /* Get the link for the text.  */
  struct stored_text *link = output.pointers->store_ptr;

  link->text = grealloc(link->text, strlen(link->text) + strlen(text) + 1);

  strcat(link->text, text);
  /* TeX hack: if the last character is an apostrophe, record 
   * that in case a closing double quote is encountered next.
   */
  if (c_line.family == FAM_TEX || c_line.setter == TEXINFO) {
    if (*text != '\0' && text[strlen(text) - 1] == '\'')
      output.done_apost = 1;
    else
      output.done_apost = 0;
  }
}

/* Used by free_storage: recursively free the linked list.  */
static void free_link(struct stored_text *link)
{
  if (link->next == NULL)
    return;

  free_link(link->next);	/* Free the next link in the list first.  */
  
  gfree(link->key);		/* Free the key string.  */
  gfree(link->text);		/* Free the text string.  */
  gfree(link->next);		/* Free the next structure.  */
  link->next = NULL;
}

/* Free the memory used by the stored_text linked list.  */
void free_storage(void)
{
  struct stored_text *link = &stored_text;

  free_link(link);
}

/* Add some text to the current lead_text string while saving the current
 * value.
 */
void push_lead_text(char *text)
{
  /* Save the address of the current value.  */
  struct lead_text *old = output.lead_text;

  /* Allocate and link a new structure.  */
  output.lead_text = galloc(sizeof(struct lead_text));
  output.lead_text->prev = old;

  /* Create the new lead_text string.  */
  output.lead_text->text = galloc(strlen(old->text) + strlen(text) + 1);
  strcpy(output.lead_text->text, old->text);
  strcat(output.lead_text->text, text);
}

/* Add a given number of blank spaces to the current lead_text.  */
void push_lead_blanks(int num)
{
  /* Save the address of the current value.  */
  struct lead_text *old = output.lead_text;
  int old_len = strlen(old->text);

  /* Allocate and link a new structure.  */
  output.lead_text = galloc(sizeof(struct lead_text));
  output.lead_text->prev = old;

  /* Create the new lead_text string.  */
  output.lead_text->text = galloc(old_len + num + 1);
  strcpy(output.lead_text->text, old->text);
  memset(output.lead_text->text + old_len, ' ', num);
  output.lead_text->text[old_len + num] = '\0';
}

/* Undo the last addition to lead_text.  */
void pop_lead_text(void)
{
  struct lead_text *new = output.lead_text;

  gfree(new->text);
  output.lead_text = new->prev;
  gfree(new);
}
