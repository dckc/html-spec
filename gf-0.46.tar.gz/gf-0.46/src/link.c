/* Cross references.
 * Copyright (C) 1993, 1994, 1996 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "link.h"

struct xlink xlink;

/* Search for a label in the cross reference list, returning a pointer
 * to a link.  If the "next" member of the link is NULL, the lookup failed.
 */
struct cross_ref *find_cross_ref(char *label)
{
  struct cross_ref *ptr = &xlink.cross_ref;

  while (ptr->next != NULL) {
    if (strcmp(ptr->label, label) == 0)
      return(ptr);
    ptr = ptr->next;
  }
  return(ptr);
}

/* Add a possible cross reference target to a linked list: done
 * during the first pass for some formatters.  label is the ID
 * string, node is the name of the Texinfo node (if needed, otherwise
 * it can be NULL), value is the section number or whatever.
 */
void add_cross_ref(char *label, char *node, char *value)
{
  struct cross_ref *ptr = find_cross_ref(label);

  if (ptr->next != NULL)
    error(EXIT, 0, "duplicated cross reference: %s", label);
  ptr->label = galloc(strlen(label) + 1);
  strcpy(ptr->label, label);
  if (node != NULL) {
    ptr->node = galloc(strlen(node) + 1);
    strcpy(ptr->node, node);
  }
  ptr->value = galloc(strlen(value) + 1);
  strcpy(ptr->value, value);
  ptr->next = galloc(sizeof(struct cross_ref));
  ptr->next->next = NULL;
}

/* General purpose cross-reference.  */
void start_reference(struct stack *stack, int depth)
{
  struct attr *ref;
  char *type = check_attribute(stack, "TYPE")->values;
  
  ref = query_attribute(stack, "REFID");
  /* Don't do anything with explicit references.  */
  if (strcmp(ref->type, "IMPLIED") != 0) {
    if (c_line.family == FAM_TEX) {
      if (strcmp(type, "PAGE") == 0)
	gfprintf("\\pageref{%s}", ref->values);
      else 
	gfprintf("\\ref{%s}", ref->values);
    }
    else if (c_line.family == FAM_PLAIN) {
      struct cross_ref *ref_ptr = find_cross_ref(ref->values);
      
      if (strcmp(type, "PAGE") != 0 && ref_ptr->next != NULL)
	gfputs(ref_ptr->value);
      else
	gfputs("???");
    }
    else if (c_line.setter == RTF) {
      struct cross_ref *ref_ptr = find_cross_ref(ref->values);
      
      if (strcmp(type, "PAGE") != 0 && ref_ptr->next != NULL)
	gfputs(ref_ptr->value);
      else
	gfputs("???");
    }
    else if (c_line.setter == TEXINFO) {
      struct cross_ref *ref_ptr = find_cross_ref(ref->values);
      
      if (ref_ptr->next != NULL)
	gfprintf("@ref{%s}", ref_ptr->node);
      else
	gfputs("???");
    }
  }
}

/* Long form cross-references, e.g., HDREF.  The page parameter
 * is non-zero if the page number should be printed.
 */
void start_long_reference(struct stack *stack, int depth, int page)
{
  char *element = stack->element;  
  struct attr *ref;

  ref = query_attribute(stack, "REFID");
  /* Don't do anthing with explicit cross references.  */
  if (strcmp(ref->type, "IMPLIED") != 0) {
    if (c_line.family == FAM_TEX) {
      if (page)
	gfprintf("\\%sp{%s}", element, ref->values);
      else 
	gfprintf("\\%s{%s}", element, ref->values);
    }
    else if (c_line.family == FAM_PLAIN) {
      struct cross_ref *ref_ptr = find_cross_ref(ref->values);
      char *label = "";		/* String to print.  */

      /* Ignore the page parameter.  */
      if (strcmp(element, "HDREF") == 0)
	label = "Section ";
      else if (strcmp(element, "FIGREF") == 0)
	label = "Figure ";
      else if (strcmp(element, "FNREF") == 0)
	label = "Note ";
      else if (strcmp(element, "LIREF") == 0)
	label = "Item ";
      if (ref_ptr->next != NULL)
	gfprintf("%s%s", label, ref_ptr->value);
      else
	gfprintf("%s ???", label);
    }
    else if (c_line.setter == RTF) {
      struct cross_ref *ref_ptr = find_cross_ref(ref->values);
      char *label = "";		/* String to print.  */
      
      /* Ignore the page parameter.  */
      if (strcmp(element, "HDREF") == 0)
	label = "Section ";
      else if (strcmp(element, "FIGREF") == 0)
	label = "Figure ";
      else if (strcmp(element, "FNREF") == 0)
	label = "Note ";
      else if (strcmp(element, "LIREF") == 0)
	label = "Item ";
      if (ref_ptr->next != NULL)
	gfprintf("%s%s", label, ref_ptr->value);
      else
	gfprintf("%s ???", label);
    }
    else if (c_line.setter == TEXINFO) {
      struct cross_ref *ref_ptr = find_cross_ref(ref->values);
      char *label = "";		/* String to print.  */

      /* Ignore the page parameter.  */
      if (strcmp(element, "HDREF") == 0) {
	if (ref_ptr->next != NULL)
	  gfprintf("@ref{%s}", ref_ptr->node);
	else
	  gfputs("Section ???");
      }
      else {
	if (strcmp(element, "FIGREF") == 0)
	  label = "Figure ";
	else if (strcmp(element, "FNREF") == 0)
	  label = "Note ";
	else if (strcmp(element, "LIREF") == 0)
	  label = "Item ";

	if (ref_ptr->next != NULL)
	  gfprintf("%s%s in @ref{%s}", label, ref_ptr->value, ref_ptr->node);
	else
	  gfprintf("%s???", label);
      }
    }
  }
}
