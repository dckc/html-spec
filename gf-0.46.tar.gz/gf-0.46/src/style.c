/* Functions for reading style sheets.
 * Copyright (C) 1993, 1994, 1995, Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

/* Need popen() from POSIX 1003.2.  */
#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 2

/* for the putenv prototype in glibc.  */
#define _SVID_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "lineout.h"

/* Search for a given style string in the linked list, returning link ptr.  */
static struct style *find_style_ptr(char *key)
{
  struct style *ptr = &style;

  while (ptr->next != NULL && strcmp(ptr->key, key) != 0)
    ptr = ptr->next;

  return(ptr);
}

/* Add a style value to the linked list. Memory is not allocated 
 * for strings.
 */
static void add_style(char *key, char *value)
{
  struct style *ptr = find_style_ptr(key);

  unescape_data(value); /* Convert SGMLS escapes.  */
  if (ptr->next != NULL) {
    /* Replace existing element.  */
    gfree(ptr->value);
    ptr->value = value;
  }
  else {
    /* Add a new link.  */
    ptr->key = key;
    ptr->value = value;
    ptr->next = galloc(sizeof(struct style));
    ptr = ptr->next->next = NULL;
  }
}

/* Parse a single style sheet.  */
void parse_style_file(char *file_name, enum families family)
{ 
  char *command;
  FILE *stream;
  char *string;
  int last_char;
  int ready_to_add = 0;
  char *key;
  char *value;
  int got_setter = 0;
  int conforming = 0;		/* Set to 1 if the style file is valid.  */

  command = galloc(strlen(PARSER) + 1 + strlen(file_name) + 1);
  sprintf(command, "%s %s", PARSER, file_name);

  /* Print the command to stderr if verbose flag was set.  */
  if (c_line.verbose)
    fprintf(stderr, "Executing: %s\n", command);

  /* Start the SGML parser, with the style file as input.  */
  if ((stream = popen(command, "r")) == NULL)
    error(EXIT, 0, "unable to start %s", PARSER);

  /* Copy the information for the appropriate typesetter family into a 
   * linked list.
   */
  while (string = read_string(stream, "\n", &last_char), last_char != EOF) {
    if (string[0] == conformingCode)
      conforming = 1;
    if (got_setter == 0) {
      if (string[0] == startElementCode && 
	  ci_strcmp(string + 1, family_names[family]) == 0)
	got_setter = 1;
    }
    else { /* got_setter */
      /* Check for end of setter.  */
      if (string[0] == endElementCode &&
	  ci_strcmp(string + 1, family_names[family]) == 0) 
	got_setter = 0;
      else {
	/* Copy tokens or attributes into the linked list, overwriting
	 * any existing value.
	 */
	if (ready_to_add) {
	  /* Last line was (ELEMENT.  */
	  ready_to_add = 0;
	  if (string[0] == '-') {
	    value = galloc(strlen(string));
	    strcpy(value, string + 1);
	    add_style(key, value);
	    /* Don't free key or value, they are swallowed up.  */
	  }
	  else			/* Empty element.  */
	    gfree(key);
	}
	if (string[0] == startElementCode) {
	  ready_to_add = 1;
	  key = galloc(strlen(string));
	  strcpy(key, string + 1);
	}
	else if (string[0] == attributeCode) {
	  char *temp = strtok(string + 1, " ");

	  key = galloc(strlen(temp) + 1);
	  strcpy(key, temp);
	  temp = strtok((char *) NULL, " "); /* Discard type.  */
	  if (temp != NULL)
	    temp = strtok((char *) NULL, "");
	  if (temp == NULL) {
	    value = galloc(1);
	    value[0] = '\0';
	  }
	  else {
	    value = galloc(strlen(temp) + 1);
	    strcpy(value, temp);
	  }
	  add_style(key, value);
	}
      }
    }
  }
  pclose(stream);

  if (!conforming)
    error(EXIT, 0, "failed to parse `%s'", file_name);

  gfree(command);
}

/* Parse the style file specified on the command line, or up
 * to three style files in the order: 1/ system 2/ user 3/ document. 
 */
void get_style(char *style_file, enum families family, enum dtds dtd,
	       char **sgml_file, int num_files, char **base_name)
{
  char *temp;
  char *env_string = galloc (strlen (libdir)
			     + strlen ("SGML_CATALOG_FILES=/cat_style") + 1);

  /* let the parser search for the style DTDs in the right place.  */
  sprintf (env_string, "SGML_CATALOG_FILES=%s/cat_style", libdir);
  verbose_putenv (env_string);
  if (putenv (env_string) != 0)	/* don't free env_string.  */
    {
      error(EXIT, 0, "failed to add `SGML_SEARCH_PATH' to environment");
      }
  if (style_file != NULL) {
    temp = galloc(strlen(style_file) + 1);
    strcpy(temp, style_file);
    if (exists(temp)) {
      verbose(temp, OK, READ);
      parse_style_file(temp, family);
    }
    else {
      verbose(temp, FAIL, READ);
      /* Try with the standard extension.  */
      temp = grealloc(temp, strlen(style_file) +
		      strlen(STYLE_EXT) + 1);
      sprintf(temp, "%s%s", style_file, STYLE_EXT);
      if (exists(temp)) {
	verbose(temp, OK, READ);
	parse_style_file(temp, family);
      }
      else {
	verbose(temp, FAIL, READ);
	error(EXIT, 0, "unable to open style file `%s'", style_file);
      }
    }
    gfree(temp);
  }
  else {  /* Not specified on command line.  */
    int i;
    char *file_name;

    file_name = galloc(strlen(dtd_names[dtd]) + 
		     strlen(STYLE_EXT) + 1);
    sprintf(file_name, "%s%s", dtd_names[dtd], STYLE_EXT);
    if ((temp = exists_system_dir(file_name)) == NULL)
      error(EXIT, 0, "unable to load system style file `%s'", file_name);
    parse_style_file(temp, family);
    gfree(temp);

    if ((temp = exists_user_dir(file_name)) != NULL) {
      parse_style_file(temp, family);
      gfree(temp);
    }

    /* Add the style extension to the input file name(s).  */
    if (strcmp(sgml_file[0], "-") != 0) {
      for (i = 0; i < num_files; i++) {
	temp = galloc(strlen(base_name[i]) + strlen(STYLE_EXT) + 1);
	sprintf(temp, "%s%s", base_name[i], STYLE_EXT);
	if (exists(temp)) {
	  verbose(temp, OK, READ);
	  parse_style_file(temp, family);
	}
	else
	  verbose(temp, FAIL, READ);
	gfree(temp);
      }
    }
    gfree(file_name);
  }
} 

/* Search for a given style string in the linked list.  */
char *find_style(char *key)
{
  struct style *ptr = &style;
  while (ptr->next != NULL) {
    if (strcmp(ptr->key, key) == 0)
      return(ptr->value);
    ptr = ptr->next;
  }
  return(NULL);
}

/* Search for a given style and give error if not found.  */
char *check_style(char *key)
{
  char *value;
  if ((value = find_style(key)) == NULL)
    error(EXIT, 0, "missing style data for %s", key);
  return(value);
}

/* Search for a given style option in the documentation linked list,
 * returning link ptr.
 */
static struct style_doc *find_style_doc_ptr(char *key)
{
  struct style_doc *ptr = &style_doc;

  while (ptr->next != NULL && strcmp(ptr->key, key) != 0)
    ptr = ptr->next;

  return(ptr);
}

/* Add documentation for an option to the linked list. Memory is not allocated 
 * for strings.
 */
static void add_style_doc(char *key, char *type, char *values, char *text)
{
  struct style_doc *ptr = find_style_doc_ptr(key);

  unescape_data(key);		/* Convert SGMLS escapes.  */

  if (ptr->next != NULL)
    error(EXIT, 0, "duplicated documentation for option %s", key);

  unescape_data(type);
  unescape_data(values);
  unescape_data(text);

  /* Add a new link.  */
  ptr->key = key;
  ptr->type = type;
  ptr->values = values;
  ptr->text = text;
  ptr->next = galloc(sizeof(struct style_doc));
  ptr = ptr->next->next = NULL;
}

/* Parse the style sheet documentation.  */
static void parse_style_doc(enum dtds dtd)
{
  char *filename =
    galloc(strlen(libdir) + 1 + strlen(style_doc_files[dtd]) + 1);
  char *command;
  FILE *stream;
  char *string;			/* Strings from the parser.  */
  int last_char;		/* Last character from the parser.  */
  int conforming = 0;		/* Flags whether the document is valid.  */
  char *name = NULL;		/* Four strings which store the useful */
  char *type = NULL;		/* output from the parser temporarily.  */
  char *values = NULL;
  char *text = NULL;


  /* Get the name of the file.  */
  sprintf(filename, "%s/%s", libdir, style_doc_files[dtd]);

  /* Start parsing the file.  */
  command = galloc(strlen(PARSER) + 1 + strlen(filename) + 1);
  sprintf(command, "%s %s", PARSER, filename);

  /* Print the command to stderr if verbose flag was set.  */
  if (c_line.verbose)
    fprintf(stderr, "Executing: %s\n", command);

  if ((stream = popen(command, "r")) == NULL)
    error(EXIT, 0, "unable to start %s", PARSER);

  /* Copy the documentation into a linked list.  */
  while (string = read_string(stream, "\n", &last_char), last_char != EOF) {
    if (string[0] == conformingCode)
      conforming = 1;
    else if (string[0] == attributeCode) {
      char *temp = strtok(string + 1, " ");
      char **ptr = NULL;

      /* Find out which attribute this is.  */
      if (strcmp(temp, "name") == 0)
	ptr = &name;
      else if (strcmp(temp, "type") == 0)
	ptr = &type;
      else if (strcmp(temp, "values") == 0)
	ptr = &values;
      else 
	error(EXIT, 0, "%s: unrecognised attribute", temp);

      /* Copy the value of the attribute to a string.  */
      temp = strtok((char *) NULL, " "); /* Discard type.  */
      if (temp != NULL)
	temp = strtok((char *) NULL, "");
      if (temp == NULL) {
	*ptr = galloc(1);
	*ptr[0] = '\0';
      }
      else {
	*ptr = galloc(strlen(temp) + 1);
	strcpy(*ptr, temp);
      }
    }
    else if (string[0] == dataCode) {
      /* Read the documentation.  */
      text = galloc(strlen(string) + 1); /* Add 1 in case it's zero.  */
      strcpy(text, string + 1);

      if (name == NULL || name[0] == '\0')
	error(EXIT, 0, "item in %s is missing name", filename);
      if (type == NULL || type[0] == '\0')
	error(EXIT, 0, "item %s is missing type", name);
      if (values == NULL)
	error(EXIT, 0, "item %s is missing type", name);
      /* Add the entry to the linked list.  */
      add_style_doc(name, type, values, text);
      /* Must not free name, type, values, text: added to style_doc.  */
    }
  }

  pclose(stream);
  
  if (!conforming)
    error(EXIT, 0, "failed to parse `%s'", filename);

  gfree(filename);
  gfree(command);
}

/* Print the style documentation to stdout and exit, to implement the
 * --style-help command line option. 
 */
void print_style_doc(enum dtds dtd)
{
  struct style_doc *ptr;	/* Steps through the linked list.  */

  /* Read the style documentation for the current DTD.  */
  parse_style_doc(dtd);

  ptr = &style_doc;

  while (ptr->next != NULL) {
    /* Get the current value of the style.  Will be NULL if the style is
     * not appropriate to this formatter.
     */
    char *current = find_style(ptr->key);

    if (current != NULL) {
      printf("%s, %s, `%s'", ptr->key, ptr->type, current);

      if (ptr->values[0] != '\0')
	printf(" [%s]", ptr->values);
      printf("\n");
      printf("%s\n\n", ptr->text);
    }
    ptr = ptr->next;
  }

  exit(0);
}
