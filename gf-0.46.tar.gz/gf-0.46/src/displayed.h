/* Header for displayed text components.  */

struct displayed {
  int use_note_counter;		/* Whether notes need to be numbered.  */
  int note_counter;		/* Counts notes.  */
};

extern struct displayed displayed;

extern void init_display(void);
extern void start_longquote(struct stack *stack, int depth);
extern void end_longquote(struct stack *stack, int depth);
extern void start_note(struct stack *stack, int depth, int store);
extern void end_note(struct stack *stack, int depth);

extern void start_code_lines(struct stack *stack, int depth);
extern void end_code_lines(struct stack *stack, int depth);
