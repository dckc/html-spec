/* Header for index elements.  */ 

struct ix {
  int need_index;		/* Whether an index is needed.  */
};

extern struct ix ix;

extern void start_index(struct stack *stack, int depth, int store);
extern void start_index_entry(struct stack *stack, int depth);
extern void end_index_entry(struct stack *stack, int depth);
