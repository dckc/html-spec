/* Definitions of global data structures.
 * Copyright (C) 1994, 1996 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stddef.h>
#include "gf.h"

char *version = 
#include "version.h"
;

char *dtd_names[] = {"smemo", "spaper", "sletter", "html", "general"};
char *style_doc_files[] = {"snafusty.sgml", "snafusty.sgml", "snafusty.sgml",
			     "htmlsty.sgml", "generalsty.sgml"};
char *setter_names[] = {"latex2e", "ab", "as", "l1b", "l1s",
			  "rtf", "texinfo"};
char *family_names[] = {"tex", "plain", "rtf", "texinfo"};

/* Specify which family each format belongs to.  */
enum families family[] = {FAM_TEX, FAM_PLAIN, FAM_PLAIN, FAM_PLAIN,
			  FAM_PLAIN, FAM_RTF, FAM_TEXINFO};

struct c_line c_line;
struct style style = {NULL, NULL, NULL};
struct style_doc style_doc = {NULL, NULL, NULL, NULL, NULL};
struct output output;
struct stored_text stored_text;

char *libdir;
char *userdir;
