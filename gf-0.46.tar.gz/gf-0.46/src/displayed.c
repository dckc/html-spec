/* Displayed text: notes, program code, long quotations etc.
 * Copyright (C) 1993, 1994, Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "displayed.h"
#include "text.h"
#include "structure.h"
#include "link.h"

struct displayed displayed;

/* Initialize the display data structures.  */
void init_display(void) {
  static int first = 1;

  if (first) {
    displayed.use_note_counter = 0;
    first = 0;
  }
  displayed.note_counter = 0;
}

/* Long quotation.  */
void start_longquote(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\begin{quotation}");
    output.need_wrap = 1;
  }
  else if (c_line.family == FAM_PLAIN) {
    char *long_quote_indent = check_style("long-quote-indent");
    char *long_quote_shrink = check_style("long-quote-shrink");
    int shrink;			/* Number of characters shrinkage.  */
    char *ptr;			/* Dummy pointer.  */

    output_flush();		/* Flush pending text.  */
    output.need_gap = 1;
    /* Reduce the width of the text on each margin.  */
    push_lead_text(long_quote_indent);
    shrink = strtol(long_quote_shrink, &ptr, 10);
    output.line_width -= shrink;
  }
  else if (c_line.setter == RTF) {
    char *font = check_style("flongquote");
    char *style =  check_style("slongquote");
  
    output.need_gap = 1;
    gfprintf("}{\\pard\\plain\\f%s\\s%s", font, style);
  }
  else if (c_line.setter == TEXINFO) {
    output.need_gap = 1;
    output.need_par = 1;	/* Suppresses the noindent.  */
    gfputs("@quotation");
    output.need_wrap = 1;
  }
}

void end_longquote(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\end{quotation}");
    output.need_wrap = 1;
  }
  else if (c_line.family == FAM_PLAIN) {
    char *long_quote_shrink = check_style("long-quote-shrink");
    int shrink;			/* Number of characters shrinkage.  */
    char *ptr;			/* Dummy pointer.  */

    /* Reset the margins.  */
    pop_lead_text();
    output.need_gap = 1;
    output_flush();		/* Flush pending text.  */
    shrink = strtol(long_quote_shrink, &ptr, 10);
    output.line_width += shrink;
  }
  else if (c_line.setter == RTF)
    output.need_gap = 1;
  else if (c_line.setter == TEXINFO) {
    output.need_wrap = 1;
    gfputs("@end quotation");
    output.need_gap = 1;
  }

  text.new_par = 1;
}

static int was_in_heading;	/* Records whether a note occured in a
				 * section heading.
				 */

/* Notes, perhaps using an architectural form.
 * The store argument is 1 if the document struture is to be stored, or 0
 * if printed output is to be produced.
 */
void start_note(struct stack *stack, int depth, int store)
{
  char *element = stack->element; /* Name of the element.  */

  if (c_line.family == FAM_TEX) {
    /* <annotate> has an extra "resp" attribute.  */
    if (strcmp(element, "ANNOTATE") == 0) {
      struct attr *resp = query_attribute(stack, "RESP");
      struct attr *id = query_attribute(stack, "ID");

      if (resp == NULL || strcmp(resp->type, "IMPLIED") == 0)
	gfputs("\\annotate{}{");
      else
	gfprintf("\\annotate{%s}{", resp->values);
      if (id != NULL && strcmp(id->type, "IMPLIED") != 0)
	gfprintf("\\label{%s}", id->values);
    }
    else {
      struct attr *id = query_attribute(stack, "ID");

      gfprintf("\\note{%s}{", element);
      if (id != NULL && strcmp(id->type, "IMPLIED") != 0)
	gfprintf("\\label{%s}", id->values);
    }
  }
  else if (c_line.family == FAM_PLAIN) {
    /* ASCII notes are numbered if necessary (if any note has
     * an id attribute).
     */
    struct attr *id = query_attribute(stack, "ID");
    char new_text[10];

    /* Increment and format the current note number.  */
    displayed.note_counter++;
    sprintf(new_text, "%d", displayed.note_counter);

    if (store) {
      if (id != NULL && strcmp(id->type, "IMPLIED") != 0) {
	/* Will only number notes if at least one has an id attribute.  */
	displayed.use_note_counter = 1;
	add_cross_ref(id->values, NULL, new_text);
      }
    }
    else {
      char *note_delimiter_l = check_style("note-delimiter-l");
      char *note_text_style = check_style("note-text-style");
      char *note_text = check_style("note-text");
      char *annotate_text = check_style("annotate-text");
      char *fn_text = check_style("fn-text");
      char *note_tag = check_style("note-tag");
      struct attr *resp = query_attribute(stack, "RESP");

      gfputs(note_delimiter_l);
      if (strcmp(note_text_style, "note") == 0)
	gfputs(note_text);
      else {
	if (strcmp(element, "NOTE") == 0)
	  gfputs(note_text);
	else if (strcmp(element, "ANNOTATE") == 0)
	  gfputs(annotate_text);
	else if (strcmp(element, "FN") == 0)
	  gfputs(fn_text);
	else {
	  /* User defined note elements.  */
	  char *element_lc;

	  element_lc = galloc(strlen(element) + 1);
	  strcpy(element_lc, element);
	  lower_case(element_lc);
	  gfputs(element_lc);
	  gfputs(" ");
	  gfree(element_lc);
	}
      }
      if (displayed.use_note_counter) {
	gfprintf("%s", new_text);
	if (resp != NULL && strcmp(resp->type, "IMPLIED") != 0)
	  gfprintf(" (%s)", resp->values);
      }
      gfputs(note_tag);
    }
  }
  else if (c_line.setter == RTF) {
    /* Cross references to RTF don't work, since notes are not numbered.  */
    if (store == 0) {
      char *font = check_style("ffn");
      char *style = check_style("sfn");
      struct attr *resp = query_attribute(stack, "RESP");
  
      gfprintf("\\chftn{\\footnote\\pard\\plain\\f%s\\s%s{\\up6\\chftn}", 
	       font, style);
      if (resp != NULL && strcmp(resp->type, "IMPLIED") != 0)
	gfprintf("%s: ", resp->values);
    }
  }
  else if (c_line.setter == TEXINFO) {
    if (store) {
      struct attr *id = query_attribute(stack, "ID");
      char new_text[10];

      /* Count notes within each node, for cross refs.  */
      displayed.note_counter++;
      sprintf(new_text, "%d", displayed.note_counter);
      if (id != NULL && strcmp(id->type, "IMPLIED") != 0)
	add_cross_ref(id->values, structure.node, new_text);
    }
    else {
      struct attr *resp = query_attribute(stack, "RESP");

      /* Format all notes as footnotes, but omit notes in section titles
       * (since Texinfo can't process them.)
       */
      if (structure.inheading) 
	gfputs("(Note omitted)");
      else {
	gfputs("@footnote{");
	if (resp != NULL && strcmp(resp->type, "IMPLIED") != 0)
	  gfprintf("%s: ", resp->values);
      }
    }
  }
  text.new_par = 1;
  /* Revert to default text while formatting the note.  */
  if (structure.inheading) {
    was_in_heading = 1;
    structure.inheading = 0;
  }
  else 
    was_in_heading = 0;

  default_text_mode();
}

void end_note(struct stack *stack, int depth)
{
  if (was_in_heading)
    structure.inheading = 1;
  restore_text_mode();

  if (c_line.family == FAM_TEX)
    gfputs("}");
  else if (c_line.family == FAM_PLAIN) {
    char *note_delimiter_r = check_style("note-delimiter-r");
    
    gfputs(note_delimiter_r);
  }
  else if (c_line.setter == RTF)
    gfputs("}");
  else if (c_line.setter == TEXINFO) {
    if (!structure.inheading)
      gfputs("}");
  }
}

/* Program listings, perhaps an architectural form.  */
void start_code_lines(struct stack *stack, int depth)
{
  char *element = stack->element; /* Name of the element.  */

  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfprintf("\\begin{listing}{%s}", element);
    output.need_wrap = 1;
  }
  else if (c_line.family == FAM_PLAIN) {
    output.need_gap = 1;
  }
  else if (c_line.setter == RTF) {
    char *font = check_style("fcode");
    char *style = check_style("scode");
  
    output.need_gap = 1;
    gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
  }
  else if (c_line.setter == TEXINFO) {
    output.need_gap = 1;
    output.need_par = 1;	/* Suppresses the noindent.  */
    gfputs("@example");
    output.need_wrap = 1;
  }
  /* Reset the number of characters per line.  */
  if (c_line.setter != RTF && c_line.setter != TEXINFO) {
    char *ptr;			/* Dummy pointer.  */
    char *width = check_style("code-width");

    output_flush();		/* Flush pending text.  */
    output.line_width = strtol(width, &ptr, 10);
  }  

  /* Set the text contents mode: typewriter font, respect spaces and
   * line breaks.
   */
  set_text_mode(1, 0, 1, 1);
}

void end_code_lines(struct stack *stack, int depth)
{
  restore_text_mode();

  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    gfputs("\\end{listing}");
    output.need_wrap = 1;
  }
  else if (c_line.family == FAM_PLAIN) {
    output.need_gap = 1;
  }
  else if (c_line.setter == RTF) {
    output_flush();		/* Flush pending text.  */
    output.need_gap = 1;
  }
  else if (c_line.setter == TEXINFO) {
    output.need_wrap = 1;
    gfputs("@end example");
    output.need_gap = 1;
  }
  /* Reset the number of characters per line.  */
  if (c_line.setter != RTF && c_line.setter != TEXINFO) {
    char *ptr;			/* Dummy pointer.  */
    char *width = check_style("line-width");

    output_flush();		/* Flush pending text.  */
    output.line_width = strtol(width, &ptr, 10);
  }
  text.par_pending = 0;
  text.new_par = 1;
}

