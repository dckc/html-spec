/* Index elements.
 * Copyright (C) 1993, 1994, Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "index.h"
#include "structure.h"
#include "text.h"

struct ix ix;

/* The store argument is 1 if the document structure is to be stored, or 0
 * if printed output is to be produced.
 */
void start_index(struct stack *stack, int depth, int store) 
{
  if (store) {
    if (c_line.setter == TEXINFO) {
      int counters[1];
      char *node_name;		/* Name of the node.  */
      char *heading;		/* Section title.  */
      int count;		/* Number for duplicated node names.  */
      char *temp_name;		/* New node name, if duplicated.  */

      /* Get the heading of the index.  */
      heading = check_style("index-name");
      /* Don't free this memory: goes into the tree.  */
      node_name = galloc(strlen(heading) + 1);
      strcpy(node_name, heading);

      /* Substitute characters which don't work in node names.  */
      escape_node_name(node_name);

      /* Change the node name if it's not unique.  */
      count = 1;		/* First number will be (2).  */
      temp_name = NULL;
      while (match_node(&info_tree, node_name) != NULL) {
	count++;
	if (count == 2) {
	  node_name = grealloc(node_name, strlen(node_name) + 10);
	  temp_name = galloc(strlen(node_name) + 1);
	  strcpy(temp_name, node_name);
	}
	sprintf(node_name, "%s (%d)", temp_name, count);
      }
      if (temp_name != NULL)
	gfree(temp_name);

      /* Add a node for the index at the top section level.  */
      counters[0] = ++structure.h_counters[1] - 1;
      if (structure.inappendix) 
	counters[0] += structure.max_h;
      
      /* Create the new node.  */
      add_node(node_name, heading, 1, counters);
    }
  }
  else {
    if (c_line.family == FAM_TEX) {
      output.need_wrap = 1;
      gfputs("\\printindex");
      output.need_wrap = 1;
    }
    else if (c_line.setter == TEXINFO) {
      int counters[1];
      struct info_tree *tree_ptr; /* Pointer to the document tree.  */
      struct info_tree *this;     /* Pointer to the document tree, this node.*/
      char *prev;	 	  /* String with the previous node.  */
      char *next;		  /* String with the next node.  */
      char *up;			  /* String with the up node.  */
      
      /* Get the previous node.  */
      counters[0] = ++structure.h_counters[1] - 1;
      if (structure.inappendix) 
	counters[0] += structure.max_h;
      if (counters[0] == 0)
	tree_ptr = &info_tree;	/* Top node.  */
      else {
	counters[0]--;
	tree_ptr = get_node(&info_tree, 1, counters);
	counters[0]++;
      }
      prev = tree_ptr->node;
      
      /* Get the current node.  */
      this = get_node(&info_tree, 1, counters);
      /* No next node.  */
      next = "";
      
      /* Get the up node, = Top.  */
      tree_ptr = &info_tree;
      up = tree_ptr->node;	/* tree_ptr used again below.  */
      
      /* Create the node.  */
      output.need_wrap = 1;
      gfprintf("@node %s,%s,%s,%s", this->node, next, prev, up);
      output.need_wrap = 1;
      gfputs("@unnumbered Index");
      output.need_wrap = 1;
      gfputs("@printindex cp");
      output.need_wrap = 1;
    }
  }
}

void start_index_entry(struct stack *stack, int depth) 
{
  /* Store the text: work out what to do with it in end_index_entry().  */
  start_storage("IX");
}

void end_index_entry(struct stack *stack, int depth) 
{
  struct attr *print = query_attribute(stack, "PRINT");
  struct stored_text *index_ptr = end_storage();
  
  /* Print the version of the text to be printed normally.  */
  if (print != NULL) {
    if (strcmp(print->type, "IMPLIED") == 0) {
      /* Print attribute was not supplied: use index text.  */
      gfputs(index_ptr->text);
    }
    /* print->values will be NULL if the supplied value was "".  */
    else if (print->values != NULL) {
      /* Use print attribute.  This can't just be printed using gfputs,
       * since character entities etc., must be processed.
       */
      (dtd_chars[c_line.dtd])(stack, depth, print->values);
    }
  }
  /* Print the real index entry.  */
  if (c_line.family == FAM_TEX) {
    gfprintf("\\index{%s}", index_ptr->text);
  }
  else if (c_line.setter == TEXINFO) {
    output.need_wrap = 1;
    gfprintf("@cindex %s", index_ptr->text);
    output.need_wrap = 1;
    text.new_par = 1;		/* Delete leading space.  */
  }

  if (output.store_text == 0) 
    free_storage();		/* Free the stored text, if not storing for */
  else				/* some other reason.  */
    strcpy(index_ptr->key, ""); /* Otherwise, just hide the index link.  */
}
