/* lineout.h */

/* Output codes used by nsgmls. */

static const char dataCode = '-';
static const char piCode = '?';
static const char conformingCode = 'C';
static const char appinfoCode = '#';
static const char startElementCode = '(';
static const char endElementCode = ')';
static const char referenceEntityCode = '&';
static const char attributeCode = 'A';
static const char dataAttributeCode = 'D';
static const char linkAttributeCode = 'a';
static const char defineNotationCode = 'N';
static const char defineExternalEntityCode = 'E';
static const char defineInternalEntityCode = 'I';
static const char defineSubdocEntityCode = 'S';
static const char defineExternalTextEntityCode = 'T';
static const char pubidCode = 'p';
static const char sysidCode = 's';
static const char startSubdocCode = '{';
static const char endSubdocCode = '}';
static const char fileCode = 'f';
static const char locationCode = 'L';
static const char includedElementCode = 'i';
