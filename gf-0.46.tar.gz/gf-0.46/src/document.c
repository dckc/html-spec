/* Controls the SGML parser and executes the subroutines for the
 * appropriate DTD.
 * Copyright (C) 1993-1996 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

/* Need popen() from POSIX 1003.2.  */
#define _POSIX_SOURCE
#define _POSIX_C_SOURCE 2

/* for the putenv prototype in glibc.  */
#define _SVID_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "lineout.h"

/* From detect.l.  */
extern FILE *yyin;
extern int detect_got_SGML;
extern int detect_got_DTD;
extern char *detect_name;

/* Temporary structure containing information from the parser which
 * has not yet been stored on the stack or linked lists.
 */
struct stored {
  char **attr;			/* Array of attribute strings.  */
  int num_attrs;		/* Number of attribute strings.  */
  char *pub_id;			/* Public identifier.  */
  char *sys_id;			/* System identifier.  */
};

static struct notation_info notation_info;
static struct entity_info entity_info;

/* Find the entity information for a given external entity name.  */
struct entity_info *query_entity(char *name)
{
  struct entity_info *ptr = &entity_info; /* Steps through the list.  */
  
  while (ptr->next != NULL) {
    if (strcmp(ptr->name, name) == 0)
      return(ptr);
    ptr = ptr->next;
  }
  return(NULL);			/* Not found.  */
}

/* Add a new element to the stack.  */
static void element_start(struct stored *stored, struct stack *stack,
			  char *element, int depth)
{
  int i;
  struct attr *attr_ptr = &stack[depth].attr;

  stack[depth].element = galloc(strlen(element) + 1);
  strcpy(stack[depth].element, element);
  attr_ptr->next = NULL;
  for (i = 0; i < stored->num_attrs; i++) {
    /* The string gets broken up and reassigned, but not deallocated.  */
    attr_ptr->name = strtok(stored->attr[i], " ");
    attr_ptr->type = strtok((char *) NULL, " ");
    attr_ptr->values = strtok((char *) NULL, "");
    attr_ptr->next = (struct attr *) galloc(sizeof(struct attr));
    attr_ptr = attr_ptr->next;
    attr_ptr->next = NULL;
  }
}

/* Recursively free the linked lists.  */
static void free_attr_element(struct attr *ptr) 
{
  if (ptr->next == NULL)
    return;
  free_attr_element(ptr->next);
  gfree((void *) ptr->next);
  /* Note that this was originally for stored.attr,
   * then split into tokens.  Only needs one deallocation.
   */
  gfree((void *) ptr->name);
}

/* Free the last element from the stack.  */
static void element_end(struct stack *stack)
{
  free_attr_element(&stack->attr);
}

/* Used in dynamic memory allocation.  */
#define BLOCK 100

/* Main parsing loop.  Lines are read from the parser.  Attributes, external
 * entity names and external entity filenames are stored in a temporary
 * structure as they are read.  When a line represents an element start an
 * extra level will be pushed onto a stack, together with the temporary
 * information.  The local start function for the DTD will then be called.
 * When a line represents an element end the local end function will be
 * called and a level will be deleted from the stack.  A line representing
 * character data will cause the local character function to be called.
 */
void parse_document(void)
{
  char *command;		/* Command which starts the parser.  */
  int command_len;		/* Length of the command.  */
  FILE *in_stream;		/* Input from the parser.  */
  FILE *out_stream;		/* Output from the formatter.  */
  struct stack *stack;		/* Data for open elements.  */
  int stack_depth = 0;		/* Number of nested open elements.  */
  int stack_size = 10;		/* Size of the stack array (extendible).  */
  struct stored stored =	/* Temporary storage of attributes.  */
    {NULL, 0};
  struct entity_info		/* Pointer to the last link in the */
    *entity_ptr;		/* entity_info list.  */
  struct notation_info		/* Pointer to the last link in the */
    *notation_ptr;		/* notation_info list.  */
  int attr_length = 10;		/* Size of the array for stored attributes.  */
  int conforming = 0;		/* Whether the document is valid.  */
  int done = 0;			/* Controls multiple passes by the parser.  */
  int first_pass = 1;		/* Flag for first time through.  */
  int detect_rc;		/* Return code from auto_detect().  */
  char *extra_file = NULL;	/* Name of extra prologue file if needed.  */
  char *catalog;		/* string to put in the environment.  */
  char *gf_cat = getenv ("GF_CATALOG_FILES"); /* possible overriding string. */
  int i;

  /* Initialize the stack, which is an array of structures.  */
  stack = galloc(stack_size * sizeof(struct stack));

  /* Allocate arrays of pointers for strings waiting to be processed.  */
  stored.attr = galloc(attr_length * sizeof(char *));

  /* Initialize local notation and entity linked lists.  */
  notation_info.notation = NULL;
  notation_info.pub_id = NULL;
  notation_info.sys_id = NULL;
  notation_ptr = &notation_info;

  entity_info.next = NULL;
  entity_info.name = NULL;
  entity_info.notation = NULL;
  entity_info.pub_id = NULL;
  entity_info.sys_id = NULL;
  entity_info.filename = NULL;
  entity_ptr = &entity_info;

  command_len = strlen(PARSER) + 1;

  /* Reading from standard input is broken.
   *   if (strcmp(c_line.sgml_file, "-") != 0) {
   */

  /* Parse the start of the first document to get the name of the top
   * level element.  In the case of HTML, a DOCTYPE declaration
   * can be imputed.
   */
  yyin = fopen(c_line.sgml_file[0], "r");
  if (yyin == NULL)
    error(EXIT, 0, "failed to open %s", c_line.sgml_file[0]);
  detect_rc = auto_detect();
  if (fclose(yyin) != 0)
    error(WARN, 0, "failed to close %s", c_line.sgml_file[0]);
  if (detect_rc == 0 || detect_rc == -1)
    error(EXIT, 0, "auto_detect: unable to parse the document prologue.\n");

  lower_case(detect_name);
  if (gf_cat)
    {
      catalog = galloc (strlen ("SGML_CATALOG_FILES=") + strlen (gf_cat)
			+ 1);
      sprintf (catalog, "SGML_CATALOG_FILES=%s", gf_cat);
    }
  else
    {
      catalog = galloc (strlen (libdir)
			+ strlen ("SGML_CATALOG_FILES=/cat_")
			+ strlen (detect_name) + 1);
      sprintf (catalog, "SGML_CATALOG_FILES=%s/cat_%s", libdir, detect_name);
    }
  if (strcmp(detect_name, "html") == 0 && detect_got_DTD == 0)
    {
      extra_file = galloc(strlen(libdir) + strlen("/html.default") + 1);
      sprintf(extra_file, "%s/html.default", libdir);
      error(WARN, 0,
	    "imputing <!DOCTYPE HTML PUBLIC  \"-//IETF//DTD HTML 2.0//EN\">");
    }
  if (extra_file != NULL)
    command_len += strlen(extra_file) + 1;

  for (i = 0; i < c_line.num_files; i++)
    command_len += strlen(c_line.sgml_file[i]) + 1;

  if (c_line.popts != NULL)
    command_len += strlen(c_line.popts) + 1;
  
  command = galloc(command_len);

  strcpy(command, PARSER);
  if (c_line.popts != NULL) {
    strcat(command, " ");
    strcat(command, c_line.popts);
  }

  if (extra_file != NULL) {
    strcat(command, " ");
    strcat(command, extra_file);
  }

  /* if (strcmp(c_line.sgml_file[0], "-") != 0) { */
  for (i = 0; i < c_line.num_files; i++) {
    strcat(command, " ");
    strcat(command, c_line.sgml_file[i]);
  }

  /* Open the output file, or print to stdout.  */
  if (c_line.out_file == NULL)
    out_stream = stdout;
  else {
    /* Check that the output file is not one of the input files.  */
    /*  if (strcmp(c_line.sgml_file[0], "-") != 0) { */
    for (i = 0; i < c_line.num_files; i++) {
      if (strcmp(c_line.sgml_file[i], c_line.out_file) == 0) {
	error(EXIT, 0, "%s is both input and output file",
	      c_line.sgml_file[i]);
      }
    }
    if ((out_stream = fopen(c_line.out_file, "w")) == NULL) {
      verbose(c_line.out_file, FAIL, WRITE);
      error(EXIT, 0, "unable to open %s for output", c_line.out_file);
    }
    verbose(c_line.out_file, OK, WRITE);
  }
  /* Set up defaults for the output routine.  */
  output.stream = out_stream;
  output.store_text = 0;
  output.discard_text = 0;
  output.pointers = NULL;
  output.line_width = 0;
  output.alignment = LEFT;	/* Left align fixed width text.  */
  /* Setup default text to be output after linebreaks.  */
  output.new_line = galloc(10);
  strcpy(output.new_line, "\n");
  /* Setup default leading text (empty).  */
  output.lead_text = galloc(sizeof(struct lead_text));
  output.lead_text->text = galloc(1);
  output.lead_text->text[0] = '\0';
  output.lead_text->prev = NULL;
  output.need_wrap = 0;
  output.need_line = 0;
  output.need_par = 0;
  output.need_gap = 0;
  output.done_open_quote = 0;
  output.done_apost = 0;

  stored_text.next = NULL;

  /* It may be necessary to make several passes through the
   * document, depending on the DTD and formatter.
   * The loop ends when the appropriate dtd_end function returns non-zero.
   */
  while (done == 0) {
    verbose_putenv (catalog);
    /* this could be changed by style sheet parsing etc., so do it every time.
     */
    if (putenv (catalog) != 0)
      {
	error(EXIT, 0, "failed to add `SGML_CATALOG_FILES' to environment");
      }
    verbose_command(command);
    if ((in_stream = popen(command, "r")) == NULL)
      error(EXIT, 0, "unable to start %s", PARSER);
    
    if (c_line.parse_only) {
      /* Just display the output from the parser without formatting.  */
      int temp;

      while ((temp = fgetc(in_stream)) != EOF)
	fputc(temp, out_stream);
    }
    else {
      int last_char;		/* Terminating character.  */
      char *string;		/* A line of (multibyte?) chars
				 * read from the parser.
				 */

      while (string = read_string(in_stream, "\n", &last_char), 
	     last_char != EOF) {
	/* Identify the type of record, using nsgmls codes.  */
	if (string[0] == dataCode) {
	  /* Character data.  */
	  unescape_data(string); /* Remove sgmls escapes.  */
	  /* Call the char function corresponding to the DTD.  */
	  (*dtd_chars[c_line.dtd])(&stack[stack_depth - 1], stack_depth, 
				   string + 1);
	}
	else if (string[0] == startElementCode) {
	  /* Element start.  */
	  char *ptr;

	  /* Allocate more space for the stack if needed.  */
	  if (stack_depth == stack_size) {
	    stack_size += 10;
	    stack = grealloc(stack, stack_size * sizeof(struct stack));
	  }
	  /* Add the element to the stack.  */
	  element_start(&stored, stack, string + 1, stack_depth);
	  stack_depth++;
	  stored.num_attrs = 0;

	  /* If this is the first element, do some more initializing.  */
	  if (c_line.dtd == NO_DTD) {
	    for (i = 0; i < NUM_DTDS; i++) {
	      if (ci_strcmp(string + 1, dtd_names[i]) == 0)
		c_line.dtd = i;
	    }
	    if (c_line.dtd == NO_DTD)
	      error(EXIT, 0, "unsupported DTD: %s", string + 1);
	    
	    /* Save the string, since get_style may use the buffer.
	     * This memory never gets freed, a minor inelegance
	     */
	    ptr = galloc(strlen(string) + 1);
	    strcpy(ptr, string);
	    get_style(c_line.style_file, c_line.family,
		      c_line.dtd, c_line.sgml_file, c_line.num_files,
		      c_line.base_name);

	    /* If the --style-help option was supplied, just print the
	     * style information instead of processing the document.
	     * The print_style_doc function does not return.
	     */
	    if (c_line.style_doc) {
	      pclose(in_stream);
	      print_style_doc(c_line.dtd);
	    }
	  }
	  /* Call the element start function corresponding to the DTD.  */
	  (*dtd_element_start[c_line.dtd])(&stack[stack_depth - 1], 
					   stack_depth);
	}
	else if (string[0] == endElementCode) {
	  /* Element end.  */
	  /* Call the element end function corresponding to the DTD.  */
	  (*dtd_element_end[c_line.dtd])(&stack[stack_depth - 1], 
					 stack_depth);
	  /* Free the last element of the stack.  */
	  stack_depth--;
	  element_end(&stack[stack_depth]);
	}
	else if (string[0] == attributeCode) {
	  unescape_data(string); /* Remove sgmls escapes.  */
	  /* Attribute - store up for the next element.  */
	  if (stored.num_attrs == attr_length) {
	    attr_length += 10;
	    stored.attr = grealloc(stored.attr, attr_length * sizeof(char *));
	  }
	  stored.attr[stored.num_attrs] = galloc(strlen(string));
	  strcpy(stored.attr[stored.num_attrs], string + 1);
	  stored.num_attrs++;
	  /* If this was a notation attribute,  may need to create a new
	   * link in the list of notation data.
	   */
	  if (first_pass) {
	    if (entity_ptr->notation != NULL) {
	      /* Will only do this the first time this element type is 
	       * found.  Don't need to store the attribute or element name,
	       * since the notation will be reported every time.  Doesn't
	       * provide a mechanism for recovering the public identifier
	       * at present.
	       */
	      entity_ptr->next = galloc(sizeof(struct entity_info));
	      entity_ptr = entity_ptr->next;
	      entity_ptr->next = NULL;
	      entity_ptr->name = NULL;
	      entity_ptr->notation = NULL;
	      entity_ptr->pub_id = NULL;
	      entity_ptr->sys_id = NULL;
	      entity_ptr->filename = NULL;
	    }
	  }
	}
	else if (string[0] == pubidCode) {
	  /* Public identifier of an external entity: store, since
	   * don't know yet whether it's for a notation or entity.
	   */
	  if (first_pass) {
	    if (stored.pub_id != NULL)
	      error(EXIT, 0, "second public identifier: %s", string + 1);
	    stored.pub_id = galloc(strlen(string));
	    strcpy(stored.pub_id, string + 1);
	  }
	}
	else if (string[0] == sysidCode) {
	  /* System identifier of an external entity: store, since
	   * don't know yet whether it's for a notation or entity.
	   */
	  if (first_pass) {
	    if (stored.sys_id != NULL)
	      error(EXIT, 0, "second system identifier: %s", string + 1);
	    stored.sys_id = galloc(strlen(string));
	    strcpy(stored.sys_id, string + 1);
	  }
	}
	else if (string[0] == fileCode) {
	  /* File name of external entity: add to current link in entity
	   * list.
	   */
	  if (first_pass) {
	    if (entity_ptr->filename != NULL) {
	      error(EXIT, 0, "second file name for a single entity: %s",
		    string + 1);
	    }
	    entity_ptr->filename = galloc(strlen(string));
	    strcpy(entity_ptr->filename, string + 1);
	  }
	}
	else if (string[0] == defineExternalEntityCode) {
	  /* External entity -- store name and add new link to list.  */
	  if (first_pass) {
	    char *token;		/* Temporary pointer.  */

	    if (entity_ptr->name != NULL)
	      error(EXIT, 0, "second entity name: %s", string + 1);
	    /* Extract the entity name and notation from the string.  */
	    token = strtok(string + 1, " ");
	    entity_ptr->name = galloc(strlen(token) + 1);
	    strcpy(entity_ptr->name, token);
	    token = strtok(NULL, " ");
	    if (token == NULL || strcmp(token, "NDATA") != 0)
	      error(EXIT, 0, "missing NDATA in entity %s", entity_ptr->name);
	    token = strtok(NULL, " ");
	    if (token == NULL)
	      error(EXIT, 0, "missing NDATA in entity %s", entity_ptr->name);
	    entity_ptr->notation = galloc(strlen(token) + 1);
	    strcpy(entity_ptr->notation, token);
	    if (stored.pub_id != NULL) {
	      entity_ptr->pub_id = stored.pub_id;
	      stored.pub_id = NULL;
	    }
	    if (stored.sys_id != NULL) {
	      entity_ptr->sys_id = stored.sys_id;
	      stored.sys_id = NULL;
	    }
	    entity_ptr->next = galloc(sizeof(struct entity_info));
	    entity_ptr = entity_ptr->next;
	    entity_ptr->next = NULL;
	    entity_ptr->name = NULL;
	    entity_ptr->notation = NULL;
	    entity_ptr->pub_id = NULL;
	    entity_ptr->sys_id = NULL;
	    entity_ptr->filename = NULL;
	  }
	}
	else if (string[0] == referenceEntityCode) {
	  /* External entity reference: call the x_entity function for 
	   * the current DTD.  
	   */
	  struct entity_info *temp_ptr = query_entity(string + 1);
	  
	  if (temp_ptr == NULL)
	    error(EXIT, 0, "entity reference undefined: %s", string + 1);
	  if (temp_ptr->notation == NULL)
	    error(EXIT, 0, "entity has undefined notation: %s", string + 1);

	  (*dtd_x_ent[c_line.dtd])(&stack[stack_depth - 1], stack_depth,
				   temp_ptr);
	}
	else if (string[0] == defineNotationCode) {
	  /* Notation declaration: store in linked list.  */
	  if (first_pass) {
	    if (stored.pub_id != NULL) {
	      notation_ptr->pub_id = stored.pub_id;
	      stored.pub_id = NULL;
	    }
	    if (stored.sys_id != NULL) {
	      notation_ptr->sys_id = stored.sys_id;
	      stored.sys_id = NULL;
	    }
	    notation_ptr->notation = galloc(strlen(string));
	    strcpy(notation_ptr->notation, string + 1);
	    notation_ptr->next = galloc(sizeof(struct notation_info));
	    notation_ptr = notation_ptr->next;
	    notation_ptr->next = NULL;
	    notation_ptr->notation = NULL;
	    notation_ptr->pub_id = NULL;
	    notation_ptr->sys_id = NULL;
	  }
	}
	else if (string[0] == conformingCode) {
	  conforming = 1;
	}
	else if (string[0] == piCode)
	  /* just ignore PI's.  */;
	else if (string[0] == dataAttributeCode)
	  error(WARN, 0, "data attributes not supported");
	else if (string[0] == linkAttributeCode)
	  error(WARN, 0, "link attributes not supported");
	else if (string[0] == defineInternalEntityCode)
	  error(WARN, 0, "internal data entities not supported");
	else if (string[0] == defineSubdocEntityCode)
	  error(WARN, 0, "subdocuments not supported");
	else if (string[0] == startSubdocCode)
	  error(WARN, 0, "subdocument entities not supported (start)");
	else if (string[0] == endSubdocCode)
	  error(WARN, 0, "subdocument entities not supported (end)");
	else if (string[0] == locationCode)
	  error(WARN, 0, "line numbers not supported");
	else if (string[0] == appinfoCode)
	  /* just ignore APPINFO.  */;
	else if (string[0] == defineExternalTextEntityCode)
	  error(WARN, 0, "external text entities not supported");
	else if (string[0] == includedElementCode)
	  error(WARN, 0, "included elements not supported");
	else {
	  error(WARN, 0, "sgmls token in line `%s' not recognized", string);
	}
      }
    }
    pclose(in_stream);

    if (c_line.parse_only || c_line.dtd == NO_DTD)
      done = 1;
    else {
      /* Call the end function for the DTD.  Returns non-zero if finished.  */
      done = (*dtd_end[c_line.dtd])();

      /*      if (done == 0) && strcmp(c_line.sgml_file[0], "-") == 0)
       *        error(EXIT, 0, "cannot make multiple passes from stdin");
       */
    }

    first_pass = 0;

  } /* End of pass through the document.  */

  if (c_line.out_file != NULL && fclose(out_stream) != 0)
    error(WARN, 0, "failed to close %s", c_line.out_file);
    
  if (!conforming && c_line.parse_only == 0)
    error(EXIT, 0, "failed to parse document");

  gfree(command);
}

/* Query the stack to find out if a given element is currently open.  */
int is_open(struct stack *stack, int depth, char *element)
{
  int i;

  for (i = 0; i < depth; i++) {
    if (strcmp(stack[-i].element, element) == 0)
      return(1);
  }
  return(0);
}

/* Query an element of the stack for a given attribute.  */
struct attr *query_attribute(struct stack *stack, char *attribute)
{
  struct attr *ptr = &stack->attr;
  while (ptr->next != NULL) {
    if (strcmp(ptr->name, attribute) == 0)
      return(ptr);
    ptr = ptr->next;
  }
  return(NULL);
}

/* Like query_attribute(), but gives error if attribute not found
 * or if its value is NULL.  Intended for attributes where the DTD
 * is supposed to make this impossible.
 */
struct attr *check_attribute(struct stack *stack, char *attribute)
{
  struct attr *ptr = query_attribute(stack, attribute);
  if (ptr == NULL || ptr->values == NULL)
    error(EXIT, 0, "value for attribute %s not found", attribute);
  return(ptr);
}
