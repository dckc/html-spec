/* Figures.
 * Copyright (C) 1993, 1994, 1996 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "figure.h"
#include "text.h"
#include "structure.h"
#include "link.h"

#ifndef STDC_HEADERS
extern double strtod();
#endif

struct figure figure;

/* Initialize figure data structures.  */
void init_figure(void)
{
  static first = 1;		/* Whether this is the first time here.  */

  figure.fig_counter = 0;
  if (first) {
    figure.got_PostScript = 0;
    first = 0;
  }
}

/* General DTD figures.  */
/* Only supports LaTeX.  */
/* Figure container.  */
void start_gen_fig(struct stack *stack, int depth)
{
  figure.got_fig_caption = 0;
  if (c_line.family == FAM_TEX) {
    struct attr *frame = query_attribute(stack, "FRAME");
    struct attr *place = query_attribute(stack, "PLACE");
    struct attr *lines = query_attribute(stack, "LINES");

    if (place == NULL || place->values == NULL)
      gfputs("\\figurehere");
    else {
      if (strcmp(place->values, "TOP") == 0)
	gfputs("\\figuretop");
      else if (strcmp(place->values, "FIXED") == 0)
	gfputs("\\figurehere");
      else if (strcmp(place->values, "BOTTOM") == 0)
	gfputs("\\figurebottom");
    }
    output.need_wrap = 1;
    gfputs("\\begin{figure}");
    output.need_wrap = 1;
    if (lines != NULL && lines->values != NULL
	&& strcmp(lines->values, "LINES") == 0)
      set_text_mode(0, 0, 1, 1);
    if (frame != NULL && frame->values != NULL) {
      if (strcmp(frame->values, "BOX") == 0)
	gfputs("\\boxit{");
      else if (strcmp(frame->values, "RULE") == 0)
	gfputs("\\ruleit{");
    }
    /* The id attribute for LaTeX is handled by end_gen_fig.  */
  }
  else
    error(EXIT, 0, "general figure only supports LaTeX");
}

void end_gen_fig(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    struct attr *id = query_attribute(stack, "ID");

    if (figure.got_fig_caption == 1) {
      /* Close the caption/description.  */
      gfputs("}");
      output.need_wrap = 1;
    }
    output.need_wrap = 1;
    /* It seems that the \label needs to go after the caption.  */

    if (id != NULL && strcmp(id->type, "IMPLIED") != 0) {
      gfprintf("\\label{%s}", id->values);
      output.need_wrap = 1;
    }
    gfputs("\\end{figure}");
    output.need_wrap = 1;
  }
}

/* Figure contents.  */
void end_gen_figbody(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    struct attr *lines = query_attribute(&stack[-1], "LINES");

    /* Reset the previous code status.  */
    if (lines != NULL && lines->values != NULL
	&& strcmp(lines->values, "LINES") == 0)
      restore_text_mode();
  }
}

void start_gen_artwork(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    /*    struct attr *align = query_attribute(&stack[-1], "ALIGN"); */
    struct attr *sizex = query_attribute(stack, "SIZEX");
    struct attr *sizey = query_attribute(stack, "SIZEY");

    gfputs("\\emptybox{");
    if (sizex != NULL && strcmp(sizex->type, "TOKEN") == 0
	&& sizex->values != NULL) {
      if (strcmp(sizex->values, "TEXTSIZE") == 0)
	gfputs("\\hsize}{");
      else
	gfprintf("%s}{", sizex->values);
    }
    else
      gfputs("\\hsize}{");	/* Should not happen.  */
    if (sizey != NULL && strcmp(sizey->type, "TOKEN") == 0
	&& sizey->values != NULL)
      gfprintf("%s}", sizey->values);
    else
      gfprintf("100pt}");	/* Should not happen.  */
  }
}

void start_gen_figcap(struct stack *stack, int depth)
{
  figure.got_fig_caption = 1;
  if (c_line.family == FAM_TEX) {
    struct attr *frame = query_attribute(&stack[-1], "FRAME");

    /* Close the \boxit or \ruleit macro.  */
    if (frame != NULL && frame->values != NULL) {
      if (strcmp(frame->values, "BOX") == 0
	  || strcmp(frame->values, "RULE") == 0)
	gfputs("}");
    }
    gfputs("\\caption{");
  }
}

/* Snafu figures.  */
/* Figure container.
 * The store argument is 1 if the document struture is to be stored, or 0
 * if printed output is to be produced.
 */

void start_fig(struct stack *stack, int depth, int store)
{
  if (c_line.family == FAM_TEX) {
    struct attr *fig_float = query_attribute(stack, "FLOAT");

    if (fig_float == NULL || fig_float->values == NULL
	|| strcmp(fig_float->values, "INLINE") != 0) {
      if (fig_float == NULL || fig_float->values == NULL) 
	gfputs("\\figurefloat");
      else {
	/* This changes the stored attribute, but no problem.  */
	lower_case(fig_float->values);
	gfprintf("\\figure%s", fig_float->values);
	output.need_wrap = 1;
      }
      gfputs("\\begin{figure}");
      output.need_wrap = 1;
    }
    /* The id attribute for LaTeX is handled by end_fig.  */
  }
  else if (c_line.family == FAM_PLAIN || c_line.setter == RTF) {
    struct attr *id = query_attribute(stack, "ID");
    char new_text[10];

    /* Increment and format the current figure number.  */
    figure.fig_counter++;
    sprintf(new_text, "%d", figure.fig_counter);
    if (store) {
      if (id != NULL && strcmp(id->type, "IMPLIED") != 0)
	add_cross_ref(id->values, NULL, new_text);
    }
    else
      gfprintf(" (figure %s omitted", new_text);
  }
  else if (c_line.setter == TEXINFO) {
    /* Count figures within each node.  */
    struct attr *id = query_attribute(stack, "ID");
    char new_text[10];
    
    /* Increment and format the current figure number.  */
    figure.fig_counter++;
    sprintf(new_text, "%d", figure.fig_counter);
    if (store) {
      if (id != NULL && strcmp(id->type, "IMPLIED") != 0)
	add_cross_ref(id->values, structure.node, new_text);
    }
    else
      gfprintf(" (figure %s omitted", new_text);
  }
}

void end_fig(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    struct attr *fig_float = query_attribute(stack, "FLOAT");

    if (fig_float == NULL || fig_float->values == NULL
	|| strcmp(fig_float->values, "INLINE") != 0) {
      /* It seems that the \label needs to go after the caption.  */
      struct attr *id = query_attribute(stack, "ID");

      if (id != NULL && strcmp(id->type, "IMPLIED") != 0) {
	gfprintf("\\label{%s}", id->values);
	output.need_wrap = 1;
      }
      gfputs("\\end{figure}");
      output.need_wrap = 1;
    }
  }
  else if (c_line.family == FAM_PLAIN || c_line.setter == RTF
	   || c_line.setter == TEXINFO)
    gfputs(") ");
}

/* Figure contents.
 * "store" argument is 1 if only looking for PostScript figures.
 */
void start_figbody(struct stack *stack, int depth, int store)
{
  if (c_line.family == FAM_TEX) {
    struct attr *file_attr;	/* Pointer to the file attribute info.  */
    struct attr *space_attr;	/* Pointer to the space attribute info.  */
    
    if ((file_attr = query_attribute(stack, "FILE")) != NULL
	&& strcmp(file_attr->type, "ENTITY") == 0) {
      /* External PostScript.  */
      char *fig_name = file_attr->values;
      char *fig_x_string, *fig_y_string;
      char *fig_rot_string;
      char *fig_pos;
      struct entity_info *fig_entity;
      char *fig_file;
      double fig_x_scale, fig_y_scale, fig_rotation;
      char *fig_float = check_attribute(&stack[-1], "FLOAT")->values;
      char *ptr;
      
      if (fig_name[0] == '\0') 
	error(EXIT, 0, "missing figure name");
      fig_entity = query_entity(fig_name);
      if (fig_entity == NULL)
	error(EXIT, 0, "missing external entity for %s", fig_name);
      if (fig_entity->notation == NULL
	  || strcmp(fig_entity->notation, "EPSF") != 0)
	error(EXIT, 0, "figure notation should be EPSF");
      figure.got_PostScript = 1;
      if (store == 0) {
	fig_file = fig_entity->filename;
	/* discard the GI prefixed by nsgmls.  */
	while (fig_file[0] != '>')
	  fig_file++;
	fig_file++;
	if (fig_file == NULL || fig_file[0] == '\0')
	  error(EXIT, 0, "missing file name for %s", fig_name);
	fig_x_string = check_attribute(stack, "X-SCALE")->values;
	fig_y_string = check_attribute(stack, "Y-SCALE")->values;
	fig_x_scale = strtod(fig_x_string, &ptr);
	fig_y_scale = strtod(fig_y_string, &ptr);
	fig_rot_string = check_attribute(stack, "ROTATION")->values;
	fig_rotation = strtod(fig_rot_string, &ptr);
	fig_pos = check_attribute(stack, "POSITION")->values;
	if (c_line.setter == LATEX2E) {
	  if (strcmp(fig_float, "INLINE") != 0) {
	    /* Always use \\makebox, otherwise the figure will not necessarily
	     * be centred.
	     */
	    gfputs("\\makebox[\\hsize]");
	    if (strcmp(fig_pos, "RIGHT") == 0)
	      gfputs("[r]");
	    else if (strcmp(fig_pos, "LEFT") == 0)
	      gfputs("[l]");
	    gfputs("{");
	  }
	  if (fig_rotation != 0)
	    gfprintf("\\rotatebox{%g}{", fig_rotation);
	  if (fig_x_scale != 1 || fig_y_scale != 1)
	    gfprintf("\\scalebox{%g}[%g]{", fig_x_scale, fig_y_scale);
	  gfprintf("\\includegraphics{%s}", fig_file);
	  if (fig_x_scale != 1 || fig_y_scale != 1)
	    gfputs("}");
	  if (fig_rotation != 0)
	    gfputs("}");
	  if (strcmp(fig_float, "INLINE") != 0)
	    gfputs("}");
	}
	output.need_wrap = 1;
      }
    }
    /* Insert vertical space if required.  */
    if (store == 0) {
      space_attr = query_attribute(stack, "SPACE");
      if (space_attr != NULL && strcmp(space_attr->type, "TOKEN") == 0
	  && space_attr->values != NULL) {
	gfprintf("\\vspace{%s}", space_attr->values);
	output.need_wrap = 1;
      }
    }
  }
}

void start_figcap(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    char *fig_float = check_attribute(&stack[-1], "FLOAT")->values;

    /* Ignore the caption if figure is inline.  */
    if (fig_float == NULL || strcmp(fig_float, "INLINE") == 0)
      gfputs("\\if0");
    gfputs("\\caption{");
  }
  else if (c_line.family == FAM_PLAIN || c_line.setter == RTF 
	   || c_line.setter == TEXINFO)
    gfputs(": ");
}

void end_figcap(struct stack *stack, int depth)
{
  if (c_line.family == FAM_TEX) {
    char *fig_float = check_attribute(&stack[-1], "FLOAT")->values;

    gfputs("}");
    output.need_wrap = 1;
    if (fig_float == NULL || strcmp(fig_float, "INLINE") == 0) {
      gfputs("\\fi{}");
      output.need_wrap = 1;
    }
  }
}
