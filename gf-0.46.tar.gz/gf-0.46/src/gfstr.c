/* String manipulation functions.  
 * Copyright (C) 1994, Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
/* For isdigit().  */
#include <ctype.h>
#include <string.h>

#include "gf.h"

/* Convert sgmls special characters to their raw form.  SDATA delimiters
 * are replaced with SDATA_TEMP. The operation is performed on the
 * string in-place.
 */
void unescape_data(char *text)
{
  char *ptr1 = text;		/* Input pointer.  */
  char *ptr2 = text;		/* Output pointer.  */

  while (*ptr1 != '\0') {
    if (*ptr1 == '\\') {
      ptr1++;
      if (*ptr1 == '\0')
	error(EXIT, 0, "unexpected \\ at end of string: `%s'", text);
      if (*ptr1 == 'n') 
	*ptr2 = '\n';
      else if (*ptr1 == '\\')
	*ptr2 = '\\';
      else if (isdigit(*ptr1)) {
	char digits[4];
	char *last;
	long temp;

	strncpy(digits, ptr1, 3);
	digits[3] = '\0';
	temp = strtol(digits, &last, 8);
	if (temp > 255)
	  error(EXIT, 0, "invalid octal escape in `%s'", text);
	*ptr2 = temp;
	ptr1 += 2;
      }
      else if (*ptr1 == '|')
	*ptr2 = SDATA_TEMP;
      else
	error(EXIT, 0, "unrecognized escape from parser: \\%c", *ptr1);
    }
    else /* Not an sgmls special.  */
      *ptr2 = *ptr1;
    ptr1++;
    ptr2++;
  }
  *ptr2 = '\0';
}

/* Convert a text string to canonical form, i.e., replace newlines and tabs
 * with spaces and then replace consecutive spaces with a single
 * space.  Works on the string in-place.  Blanks within SDATA entities are
 * not replaced.  If respect_spaces == 1, blanks are not touched.  Likewise
 * if preserve_breaks == 1 then newlines are not touched.
 */
void tidy_string(char *text, int respect_spaces, int preserve_breaks)
{
  char *ptr1 = text, *ptr2 = text;
  int in_sdata = 0;

  while (*ptr1 != '\0') {
    if (*ptr1 == SDATA_TEMP)
      in_sdata = !in_sdata;
    *ptr2 = *ptr1++;
    if ((*ptr2 == '\n' && !preserve_breaks)
	|| (*ptr2 == '\t' && !respect_spaces))
      *ptr2 = ' ';
    if (*ptr2 != ' ' || ptr2 == text || *(ptr2 - 1) != ' ' || in_sdata
	|| respect_spaces)
      ptr2++;
  }
  *ptr2 = '\0';
}

/* Remove leading blanks from a string.  */
void strip_leading_blanks(char *text)
{
  char *ptr1 = text, *ptr2 = text;

  while (*ptr1 == ' ') ptr1++;
  while (*ptr1 != '\0')
    *ptr2++ = *ptr1++;
  *ptr2 = '\0';
}

/* Remove leading and trailing blanks from a string.  */
void strip_blanks(char *text)
{
  char *ptr1 = text, *ptr2 = text;

  while (*ptr1 == ' ') ptr1++;
  while (*ptr1 != '\0')
    *ptr2++ = *ptr1++;
  while (ptr2 > text && *(ptr2 - 1) == ' ') 
    ptr2--;
  *ptr2 = '\0';
}
