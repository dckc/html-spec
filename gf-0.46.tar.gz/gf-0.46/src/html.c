/* Routines for the HTML formatters.
 * Copyright (C) 1993, 1994, 1995, 1996 Gary Houston.
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 *
 * Public functions: html_element_start,
 * html_element_end, html_x_ent, html_chars, html_end.
 */

/* for the putenv prototype in glibc.  */
#define _SVID_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef HAVE_UNISTD_H
# include <unistd.h>
#endif
#include <errno.h>
#include "gf.h"
#include "text.h"
#include "structure.h"
#include "displayed.h"
#include "figure.h"
#include "list.h"

/* Translations for mapping non-ASCII characters to SDATA.  */
static struct sdata_table lat1_chars;

/* Translations for mapping SDATA to output.  */
static struct sdata_table sdata;

/* Type of URI: used when saving URIs for a reference list.  */
enum uri_type {URI_URL, URI_URN};

/* Image types and names which can be used in the links file.  */
enum image_type {IMG_JPEG = 0, IMG_GIF, IMG_EPS};
static char *image_names[] = {"jpeg", "gif", "eps"};
int num_image_types = 3;

/* Local data for this DTD.  */
static struct {
  int pass;			/* Pass number through the document.  */
  int in_address;		/* Whether currently processing <address>.  */

  struct uri_list {		/* Linked list of URIs for a reference list. */
    enum uri_type type;
    char *text;
    struct uri_list *next;
  } uri_list;
  struct uri_list *list_end;	/* Pointer to the end of the uri_list.  */
  int ref_count;		/* Counts the references.  */

  /* Information from the .links file: URIs and converted EPS names.  */
  struct image_links {
    char *uri;			/* Name of the link from the HTML file.  */
    enum image_type type;	/* Graphics format.  */
    char *original;		/* Local file name of native file.  */
    char *converted;		/* Local file name of converted EPS file.  */
    struct image_links *next;
  } image_links;
} dtd;

/* Extension for URI link files.  */
#define LINKS_EXT ".links"

/* table information accumulates here.  the first link is not used.
   tables may be nested.  */
struct html_tables {
  int done;			/* 1 when preprocessing complete. */
  int column;
  int max_columns;
  char *caption;
  enum {TOP, BOTTOM} caption_align;
  enum {NONE, IMPLIED, PIXELS, PERCENT} border_type;
  double border;
  enum {ALIGN_LEFT, ALIGN_CENTER, ALIGN_RIGHT} align;
  struct html_tables *next;
  struct html_tables *prev;
} html_tables;
static struct html_tables *current_table;

static int nesting = 0;		/* counts nesting in final pass.  */

/* Initialise data structures (once).  */
static void dtd_init(struct stack *stack, int depth)
{
  char *ptr;			/* Dummy pointer.  */
  char *ext;			/* Extension for SDATA files.  */

  /* Set up the input latin1 character translation table.  */
  get_sdata_translations("lat1.2sdata", &lat1_chars);

  dtd.pass = 1;			/* 1st pass through document.  */

  output.discard_text = 1;	/* Don't print text on first pass.  */

  dtd.in_address = 0;
  dtd.uri_list.next = NULL;
  dtd.list_end = &dtd.uri_list;
  dtd.ref_count = 0;

  html_tables.next = NULL;
  html_tables.prev = NULL;
  current_table = &html_tables;

  /* Initialize data structures.  These also get called at the beginning
   * of the second pass if there is one.
   */
  init_text();
  init_structure();
  init_display();
  init_list();
  init_figure();

  structure.infrontm = 0;	/* Don't want this. HTML has no real frontm. */

  if (c_line.family == FAM_TEX) {
    char *temp = check_style("line-width");
    char *link_file;		/* Names of candidate link files.  */
    int max_len = 0;
    /* Pointer to the end of the list.  */
    struct image_links *images_ptr = &dtd.image_links;
    int i;

    output.line_width = strtol(temp, &ptr, 10); /* Auto line breaking.  */

    /* Initialise the image_links structure from the foo.links file.  */

    /* Calculate the maximum length of the links file.  */
    for (i = 0; i < c_line.num_files; i++) {
      int len = strlen(c_line.base_name[i]);

      if (len > max_len)
	max_len = len;
    }
    max_len += strlen(LINKS_EXT);
    link_file = galloc(max_len + 1);

    /* Initialise the structure.  */
    dtd.image_links.next = NULL;

    /* Look for link files and read them.  */
    for (i = 0; i < c_line.num_files; i++) {
      sprintf(link_file, "%s%s", c_line.base_name[i], LINKS_EXT);

      if (exists(link_file)) {
	int done = 0;
	FILE *link_stream;
	int line_num = 0;	/* Counts the lines in the file.  */

	verbose(link_file, OK, READ);
	link_stream = fopen(link_file, "r");
	if (link_stream == NULL)
	  error(EXIT, 0, "Unable to open %s", link_file);

	while (done == 0) {
	  int last_char;	/* Terminating chars from links file. */
	  char *string;		/* Pointer to strings read from links file.  */
	  char *final_slash;	/* Pointer to the last slash in a name.  */
	  char *ext_ptr;	/* Pointer to the extension.  */

	  line_num++;
	  /* Read the URI name.  */
	  skip_chars(link_stream, " \t\n");
	  string = read_string(link_stream, " \t\n", &last_char);
	  if (last_char == EOF && string[0] == '\0')
	    done = 1;
	  else {
	    int type;		/* Steps through image types.  */

	    if (last_char != ' ' && last_char != '\t') {
	      error(EXIT, 0, "Error reading %s at line %d",
		    link_file, line_num);
	    }
	    images_ptr->uri = galloc(strlen(string) + 1);
	    strcpy(images_ptr->uri, string);
	    
	    /* Read the type of image.  */
	    skip_chars(link_stream, " \t");
	    string = read_string(link_stream, " \t\n", &last_char);
	    if (last_char != ' ' && last_char != '\t') {
	      error(EXIT, 0, "Error reading %s at line %d",
		    link_file, line_num);
	    }
	    lower_case(string);
	    for (type = 0; type <= num_image_types; type++) {
	      if (type == num_image_types) {
		error(EXIT, 0, "Unknown image type `%s' in %s", string,
		      link_file);
	      }
	      if (strcmp(string, image_names[type]) == 0) {
		images_ptr->type = type;
		break;
	      }
	    }
	    
	    /* Read the source file name.  */
	    skip_chars(link_stream, " \t");
	    string = read_string(link_stream, " \t\n", &last_char);
	    if (last_char == '\t' || last_char == ' ')
	      last_char = skip_chars(link_stream, " \t");
	    if (last_char == EOF)
	      done = 1;
	    else if (last_char != '\n') {
	      error(EXIT, 0, "Error reading %s at line %d",
		    link_file, line_num);
	    }
	    /* If the original name is relative to the current working
	     * directory, add the path.
	     */
	    if (string[0] == '/') {
	      images_ptr->original = galloc(strlen(string) + 1);
	      strcpy(images_ptr->original, string);
	    }
	    else {
	      /* Original image filename is relative.  Use the directory
	       * of this (links) file.
	       */
	      images_ptr->original =
		galloc(strlen(c_line.dir_name[i]) + 1
		       + strlen(string) + 1);

	      if (c_line.dir_name[i][0] == '\0')
		strcpy(images_ptr->original, string);
	      else {
		sprintf(images_ptr->original, "%s/%s", c_line.dir_name[i],
			string);
	      }
	    }
	    /* Check that the native image file exists.  */
	    if (!exists(images_ptr->original)) {
	      error(EXIT, 0, "Image file `%s' can not be read",
		    images_ptr->original);
	    }

	    /* Derive the name of the converted file to be used
	     *  by LaTeX.
	     */
	    if (images_ptr->type == IMG_EPS) {
	      /* Never need to convert EPS images.  */
	      images_ptr->converted = images_ptr->original;
	    }

	    images_ptr->converted =
	      galloc(strlen(images_ptr->original) + strlen(EPS_EXT) + 1);
	    strcpy(images_ptr->converted, images_ptr->original);
	    /* Replace any extension on the original file with the
	     * new extension.
	     */
	    final_slash = strrchr(images_ptr->converted, '/');
	    ext_ptr = strrchr(images_ptr->converted, '.');
	    if (ext_ptr == NULL
		|| (final_slash != NULL && ext_ptr < final_slash)) {
	      /* No extension was found.  */
	      ext_ptr = images_ptr->converted + strlen(images_ptr->converted);
	    }
	    strcpy(ext_ptr, EPS_EXT);

	    images_ptr->next = galloc(sizeof(struct image_links));
	    images_ptr->next->next = NULL;
	    images_ptr = images_ptr->next;
	  }
	}

	/* Check each of the converted image files and generate if
	 * necessary.
	 */
	images_ptr = &dtd.image_links;
	while (images_ptr->next != NULL) {
	  if (!exists(images_ptr->converted)
	      || diff_filetime(images_ptr->original,
			       images_ptr->converted) > 0) {
	    char *prog;
	    char *env_buffer;

	    if (images_ptr->type == IMG_JPEG)
	      prog = check_style("jpeg-to-eps");
	    else if (images_ptr->type == IMG_GIF)
	      prog = check_style("gif-to-eps");

	    env_buffer =
	      galloc(strlen("infile") + 1 + strlen(images_ptr->original) + 1);
	    sprintf(env_buffer, "infile=%s", images_ptr->original);
	    verbose_putenv(env_buffer);
	    if (putenv(env_buffer) != 0)
	      error(EXIT, 0, "failed to add `$infile' to environment");
	    /* Don't free env_buffer, it's still in the environment. */
	    env_buffer =
	      galloc(strlen("outfile") + 1 + strlen(images_ptr->converted)
		     + 1);
	    sprintf(env_buffer, "outfile=%s", images_ptr->converted);
	    verbose_putenv(env_buffer);
	    if (putenv(env_buffer) != 0)
	      error(EXIT, 0, "failed to add `$outfile' to environment");
	    verbose_command(prog);
	    if (system(prog) != 0)
	      error(WARN, 0, "command failed: `%s'", prog);
	  }
	  images_ptr = images_ptr->next;
	}
      }
      else
	verbose(link_file, FAIL, READ);
    }

    ext = ".2tex";
  }
  else if (c_line.family == FAM_PLAIN) {
    char *temp = check_style("line-width");

    output.line_width = strtol(temp, &ptr, 10); /* Auto line breaking.  */

    if (c_line.setter == AB)
      ext = ".2ab";
    else if (c_line.setter == AS)
      ext = ".2as";
    else if (c_line.setter == L1B)
      ext = ".2l1b";
    else if (c_line.setter == L1S)
      ext = ".2l1s";
  }
  else if (c_line.setter == RTF) {
    char *font_link = check_style("fpar");    /* Paragraph font link.  */
    char *style_link = check_style("spar");   /* Paragraph style link.  */

    output.line_width = 50000;	/* An output line can be this long.
				 * If a line was longer, a blank would be lost
				 */

    /* Set up the text for new paragraphs.  */
    output.new_par = galloc(strlen("{\\pard\\plain\\f\\s ") +
			    strlen(font_link) + strlen(style_link) + 1);
    sprintf(output.new_par, "{\\pard\\plain\\f%s\\s%s ", font_link,
	    style_link);

    ext = ".2rtf";
  }
  else {
    error(EXIT, 0, "formatter `%s' is not supported for %s",
	  setter_names[c_line.setter], dtd_names[c_line.dtd]);
  }
  /* Read SDATA translation tables.  */
  {
    char file[20];		/* File names.  */

    sdata.next = NULL;

    sprintf(file, "ISOlat1%s", ext);
    get_sdata_translations(file, &sdata);
    /* Many of the characters in this table can not be used in HTML.
     * Others can only be used by direct input of Latin 1 characters.
     */
    sprintf(file, "ISOnum%s", ext);
    get_sdata_translations(file, &sdata);
    /* Only &Dot; is used from this table.  */
    sprintf(file, "ISOtech%s", ext);
    get_sdata_translations(file, &sdata);
  }
}

/* Print a single WWW URL as received from sgmls.  */
static void print_raw_url(struct stack *stack, int depth, char *url)
{
  if (c_line.family == FAM_TEX) {
    gfputs("\\url{");
    set_text_mode(1, 0, 0, 0);
    html_chars(stack, depth, url);
    restore_text_mode();
    gfputs("}");
  }
  else if (c_line.family == FAM_PLAIN) {
    char *url_delim_l = check_style("url-delimiter-l");
    char *url_delim_r = check_style("url-delimiter-r");

    gfputs(url_delim_l);
    set_text_mode(1, 0, 0, 0);
    html_chars(stack, depth, url);
    restore_text_mode();
    gfputs(url_delim_r);
  }
  else if (c_line.setter == RTF) {
    char *font = check_style("fcode");
    char *style = check_style("scode");
    char *url_delim_l = check_style("url-delimiter-l");
    char *url_delim_r = check_style("url-delimiter-r");

    gfprintf("}{\\pard\\plain\\f%s\\s%s %s", font, style, url_delim_l);
    set_text_mode(1, 0, 0, 0);
    html_chars(stack, depth, url);
    restore_text_mode();
    gfprintf("%s%s}%s", url, url_delim_r, output.new_par);
  }
}

/* Likewise for URNs.  */
static void print_raw_urn(struct stack *stack, int depth, char *urn)
{
  if (c_line.family == FAM_TEX) {
    gfputs("\\urn{");
    /* Typewriter font, but do not respect spaces or line breaks.  */
    set_text_mode(1, 0, 0, 0);
    html_chars(stack, depth, urn);
    restore_text_mode();
    gfputs("}");
  }
  else if (c_line.family == FAM_PLAIN) {
    char *urn_delim_l = check_style("urn-delimiter-l");
    char *urn_delim_r = check_style("urn-delimiter-r");

    gfputs(urn_delim_l);
    set_text_mode(1, 0, 0, 0);
    html_chars(stack, depth, urn);
    restore_text_mode();
    gfputs(urn_delim_r);
  }
  else if (c_line.setter == RTF) {
    char *font = check_style("fcode");
    char *style = check_style("scode");
    char *urn_delim_l = check_style("urn-delimiter-l");
    char *urn_delim_r = check_style("urn-delimiter-r");

    gfprintf("}{\\pard\\plain\\f%s\\s%s %s", font, style, urn_delim_l);
    set_text_mode(1, 0, 1, 0);
    html_chars(stack, depth, urn);
    restore_text_mode();
    gfprintf("%s}%s", urn_delim_r, output.new_par);
  }
}

/* Add a URI to a data structure, to be formatted later as a list
 * of references and print the citation.
 */
static void add_ref(char *uri, enum uri_type type)
{
  dtd.list_end->type = type;
  dtd.list_end->text = galloc(strlen(uri) + 1);
  strcpy(dtd.list_end->text, uri);
  dtd.list_end->next = galloc(sizeof(struct uri_list));
  dtd.list_end = dtd.list_end->next;
  dtd.list_end->next = NULL;
  dtd.ref_count++;

  if (c_line.family == FAM_TEX) {
    /* \cite fails in a section heading.  */
    if (structure.inheading)
      gfprintf("\\hcite{%d}", dtd.ref_count);
    else
      gfprintf("\\cite{%d}", dtd.ref_count);
  }
  else if (c_line.family == FAM_PLAIN || c_line.family == FAM_RTF) {
    char *ref_delim_l = check_style("ref-delimiter-l");
    char *ref_delim_r = check_style("ref-delimiter-r");

    gfprintf("%s%d%s", ref_delim_l, dtd.ref_count, ref_delim_r);
  }
}

/* Process an image or produce replacement text.  */
static void process_image(struct stack *stack, int depth) {
  struct attr *url = query_attribute(stack, "SRC");
  struct attr *alt = query_attribute(stack, "ALT");
  struct attr *align = query_attribute(stack, "ALIGN");
  char *uri_status = check_style("uri-status");
  char *inline_uri_status = check_style("inline-uri-status");
  int url_include = 0;	/* Flag for including URL.  */
  int url_atend = 0;	/* Flag for URL at end.  */
  /* Pointer to the end of the image list.  */
  struct image_links *images_ptr = &dtd.image_links;
  int found = 0;		/* Whether there is an EPS file.  */
  
  /* The image is included in the TeX output if an EPS
   * version is listed in the .links file and actually exists.
   * Otherwise, the ALT text is used if available.
   */
  
  if (c_line.family == FAM_TEX) {
    /* Check the saved link data for this URL.  */
    while (images_ptr->next != NULL) {
      if (strcmp(images_ptr->uri, url->values) == 0) {
	if (exists(images_ptr->converted)) {
	  found = 1;
	  break;
	}
      }
      images_ptr = images_ptr->next;
    }
	
    if (found) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\img{");
	if (align != NULL && align->values != NULL) {
	  if (strcmp(align->values, "BOTTOM") == 0)
	    gfputs("b");
	  else if (strcmp(align->values, "TOP") == 0)
	    gfputs("t");
	  else if (strcmp(align->values, "MIDDLE") == 0)
	    gfputs("c");
	}
	else
	  gfputs("c");
	gfprintf("}{%s}",  images_ptr->converted);
      }
    }
  }
  
  if (found == 0) {
    /* The image file wasn't found, so print some replacement text.
     * Find from the style sheet whether URIs should be included,
     * moved to the end or omitted.
     */
    if (url != NULL && url->values != NULL
	&& strcmp(inline_uri_status, "inline-uri-default") == 0) {
      if (strcmp(uri_status, "uri-atend") == 0)
	url_atend = 1;
      else if (strcmp(uri_status, "uri-include") == 0)
	url_include = 1;
    }

    /* Start the image replacement text.  */
    if (c_line.family == FAM_TEX) {
      gfputs("\\altimg{");
      if (alt != NULL && alt->values != NULL) {
	html_chars(stack, depth, alt->values);
	if (url_include)
	  gfputs(" ");
      }
    }
    else if (c_line.family == FAM_PLAIN || c_line.family == FAM_RTF) {
      char *img_replace_l = check_style("img-replace-l");

      gfputs(img_replace_l);
      if (alt != NULL && alt->values != NULL) {
	gfputs(": ");
	html_chars(stack, depth, alt->values);
	if (url_include)
	  gfputs(" ");
      }
      else if (url_include)
	gfputs(": ");
    }

    /* Print the URI or the citation.  */
    if (url_include)
      print_raw_url(stack, depth, url->values);
    else if (url_atend)
      add_ref(url->values, URI_URL);
    
    /* Finish the image replacement text.  */
    if (c_line.family == FAM_TEX)
      gfputs("}");
    else if (c_line.family == FAM_PLAIN || c_line.family == FAM_RTF) {
      char *img_replace_r = check_style("img-replace-r");

      gfputs(img_replace_r);
    }
  }
}

/* Align part of a document, LEFT, CENTER or RIGHT.  */     
/* fixme: non-LaTeX alignment doesn't nest.  */
void start_alignment (char *where) {
  if (strcmp (where, "LEFT") == 0) {
    if (c_line.family == FAM_TEX) {
      output.need_wrap = 1;
      gfputs ("\\begin{flushleft}");
      output.need_wrap = 1;
    }
    else {
      output.need_par = 1;
      output_flush();
      output.alignment = ALIGN_LEFT;
    }
  }
  else if (strcmp (where, "CENTER") == 0) {
    if (c_line.family == FAM_TEX) {
      output.need_wrap = 1;
      gfputs ("\\begin{center}");
      output.need_wrap = 1;
    }
    else {
      output.need_par = 1;
      output_flush();
      output.alignment = CENTRE;
    }
  }
  else if (strcmp (where, "RIGHT") == 0) {
    if (c_line.family == FAM_TEX) {
      output.need_wrap = 1;
      gfputs ("\\begin{flushright}");
      output.need_wrap = 1;
    }
    else {
      output.need_par = 1;
      output_flush();
      output.alignment = CENTRE; /* as close as we can get.  */
    }
  }
}

void end_alignment (char *where) {
  if (c_line.family == FAM_TEX) {
    output.need_wrap = 1;
    if (strcmp (where, "LEFT") == 0)
      gfputs ("\\end{flushleft}");
    else if (strcmp (where, "CENTER") == 0)
      gfputs ("\\end{center}");
    else if (strcmp (where, "RIGHT") == 0)
      gfputs ("\\end{flushright}");
    output.need_wrap = 1;
  }
  else {
    output.need_par = 1;
    output_flush();
    output.alignment = ALIGN_LEFT; /* should restore state.  */
  }
}

/* Rough normal line width.  */
#define NOMINAL_LINE_WIDTH 80

void html_element_start(struct stack *stack, int depth)
{
  char *element = stack->element;
  static int first = 1;

  if (first) {
    dtd_init(stack, depth);
    first = 0;
  }
  if (dtd.pass == 1) {
    /* the first pass gets table and image information, no output is
       produced.  */
    if (strcmp(element, "TABLE") == 0) {
      struct attr *border = query_attribute (stack, "BORDER");
      struct attr *align = query_attribute (stack, "ALIGN");
	  
      while (current_table->next != NULL) /* in case of nested tables.  */
	current_table = current_table->next;
      current_table->next = galloc (sizeof (struct html_tables));
      current_table->next->prev = current_table;
      current_table = current_table->next;
      current_table->next = NULL;
      current_table->caption = NULL;
      if (border == NULL)
	current_table->border_type = NONE;
      else if (border->values == NULL) {
	struct attr *dummy = query_attribute (stack, "DUMMY");

	if (dummy->values == NULL)
	  current_table->border_type = NONE;
	else
	  current_table->border_type = IMPLIED;
      }
      else {
	char *ptr;

	current_table->border = strtod (border->values, &ptr);
	current_table->border_type = PIXELS;
	if (*ptr == '%')
	  current_table->border_type = PERCENT;
	else if (*ptr != '\0')
	  error (WARN, 0, "bad BORDER attribute `%s'", border->values);
	if (current_table->border == 0)
	  current_table->border_type = NONE;
      }
      if (align == NULL || align->values == NULL)
	current_table->align = ALIGN_CENTER;
      else if (strcmp (align->values, "ALIGN_LEFT") == 0)
	current_table->align = ALIGN_LEFT;
      else if (strcmp (align->values, "ALIGN_RIGHT") == 0)
	current_table->align = ALIGN_RIGHT;
      current_table->done = 0;
      current_table->column = 0;
      current_table->max_columns = 0;
    }       
    else if (strcmp (element, "CAPTION") == 0) {
      struct attr *align = query_attribute (stack, "ALIGN");

      if (align != NULL && align->values != NULL
	  && strcmp (align->values, "TOP") == 0)
	current_table->caption_align = TOP;
      else
	current_table->caption_align = BOTTOM;
      output.discard_text = 0;
      start_storage ("CAPTION");
    }
    else if (strcmp(element, "TD") == 0 || strcmp (element, "TH") == 0) {
      struct attr *colspan = check_attribute (stack, "COLSPAN");
      char *ptr;
      long cols = strtol (colspan->values, &ptr, 10);
      struct attr *rowspan = check_attribute (stack, "ROWSPAN");
      long rows = strtol (rowspan->values, &ptr, 10);
      static int row_warned = 0;

      if (cols > 1)
	current_table->column += cols;
      else
	current_table->column++;
      if (c_line.family == FAM_TEX && rows > 1 && row_warned == 0) {
	error (WARN, 0, "ROWSPAN attribute not supported: may get bad table");
	row_warned = 1;
      }
    }
    else if (c_line.family == FAM_TEX) {
      struct attr *url;
      int found = 0;

      if (strcmp(element, "IMG") == 0) {
	url = query_attribute(stack, "SRC");
	found = 1;
      }
      /* Images can also appear within <form>.  */
      else if (strcmp(element, "INPUT") == 0) {
	struct attr *type = check_attribute(stack, "TYPE");

	if (strcmp(type->values, "IMAGE") == 0) {
	  url = query_attribute(stack, "SRC");
	  found = 1;
	}
      }
      if (found) {
	if (url != NULL && url->values != NULL) {
	  /* Pointer to the end of the list.  */
	  struct image_links *images_ptr = &dtd.image_links;

	  /* Check the saved link data for this URL.  */
	  while (images_ptr->next != NULL) {
	    if (strcmp(images_ptr->uri, url->values) == 0) {
	      if (exists(images_ptr->converted))
		figure.got_PostScript = 1;
	    }
	    images_ptr = images_ptr->next;
	  }
	}
      }
    }
  }
  else {			/* pass == 2 */
    if (strcmp(element, "P") != 0)
      text.par_pending = 0;
    text.new_par = 0;

    if (strcmp(element, "HTML") == 0) {
      /* Reinitialize data structures.  */
      init_text();
      init_structure();
      init_display();
      init_list();
      init_figure();
      output.discard_text = 0;

      while (current_table->next != NULL) {
	current_table = current_table->next;
	/* reused to track nested tables.  */
	current_table->done = 0;
	current_table->column = 0;
      }
      current_table = &html_tables;

      start_document(stack, depth);
      if (c_line.family == FAM_TEX) {
	gfputs("\\begin{document}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "P") == 0) {
      struct attr *align = query_attribute(stack, "ALIGN"); /* HTML 3.2.  */

      if (align != NULL && align->values != NULL)
	start_alignment (align->values);
      if (dtd.in_address) {
	/* Use linebreaks for paragraphs in <address>.  */
	if (text.par_pending)
	  output.need_line = 1;
	text.new_par = 1;
      }
      else
	start_paragraph(stack, depth);
    }
    else if (strcmp(element, "BR") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\br");
	output.need_wrap = 1;
      }
      else
	output.need_line = 1;
      /* text.new_par gets set in </BR>.  */
    }
    else if (strcmp(element, "HR") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\hr");
	output.need_wrap = 1;
      }
      else if (c_line.family == FAM_PLAIN || c_line.family == FAM_RTF) {
	char bbuffer[NOMINAL_LINE_WIDTH + 1];
	int line_length = output.line_width;
      
	if (output.line_width > NOMINAL_LINE_WIDTH || output.line_width == 0)
	  line_length = NOMINAL_LINE_WIDTH;
	line_length = line_length - strlen(output.lead_text->text);
	if (line_length < 0)
	  line_length = 0;
      
	memset(bbuffer, '-', line_length);
	bbuffer[line_length] = '\0';
	output.need_line = 1;
	gfputs(bbuffer);
	output.need_line = 1;
      }
    }
    else if (strcmp(element, "EM") == 0)
      start_emphasize(stack, depth);
    else if (strcmp(element, "STRONG") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\strong{");
      else if (c_line.family == FAM_PLAIN) {
	char *delim = check_style("strong-delimiter");

	gfputs(delim);
      }
      else if (c_line.setter == RTF) {
	char *font;
	char *style;

	font = check_style("fstrong");
	style = check_style("sstrong");

	gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
      }
    }
    else if (strcmp(element, "CITE") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\citehere{");
      else if (c_line.family == FAM_PLAIN) {
	char *delim = check_style("cite-delimiter-l");

	gfputs(delim);
      }
      else if (c_line.family == FAM_RTF) {
	char *font = check_style("fcite");
	char *style = check_style("scite");

	gfprintf("}{\\pard\\plain\\f%s\\s%s ", font, style);
      }
    }
    else if (strcmp(element, "B") == 0)
      start_bold(stack, depth);
    else if (strcmp(element, "I") == 0)
      start_italic(stack, depth);
    else if (strcmp(element, "U") == 0)
      start_underline(stack, depth);
    else if (strcmp(element, "TT") == 0)
      start_code_inline(stack, depth);
    else if (strcmp (element, "BIG") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs ("\\large{");
    }
    else if (strcmp (element, "SMALL") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs ("\\small{");
    }
    else if (strcmp (element, "SUP") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs ("${}^{");
      else
	gfputs ("^(");
    }
    else if (strcmp (element, "SUB") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs ("${}_{");
      else
	gfputs ("_(");
    }
    else if (strcmp(element, "A") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\anchor{");
    }
    else if (element[0] == 'H' && element[2] == '\0') {
      int head_level = element[1] - '0';

      start_heading(stack, depth, head_level, 0);
    }
    else if (strcmp(element, "IMG") == 0)
      process_image(stack, depth);
    else if (strcmp(element, "BLOCKQUOTE") == 0)
      start_longquote(stack, depth);
    else if (strcmp(element, "PRE") == 0 || strcmp(element, "XMP") == 0
	     || strcmp(element, "LISTING") == 0 ||
	     strcmp(element, "PLAINTEXT") == 0) {
      start_code_lines(stack, depth);
    }
    else if (strcmp(element, "CODE") == 0 || strcmp(element, "SAMP") == 0
	     || strcmp(element, "KBD") == 0 || strcmp(element, "KEY") == 0
	     || strcmp(element, "VAR") == 0 || strcmp(element, "DFN") == 0) {
      start_code_inline(stack, depth);
    }
    else if (strcmp(element, "OL") == 0) {
      struct attr *compact = query_attribute(stack, "COMPACT");

      if (compact->values != NULL && strcmp(compact->values, "COMPACT") == 0)
	start_ordered_list(stack, depth, 0, 1);
      else
	start_ordered_list(stack, depth, 0, 0);
    }
    else if (strcmp(element, "UL") == 0 || strcmp(element, "DIR") == 0
	     || strcmp(element, "MENU") == 0) {
      struct attr *compact = query_attribute(stack, "COMPACT");

      if (compact->values != NULL && strcmp(compact->values, "COMPACT") == 0)
	start_unordered_list(stack, depth, 1);
      else
	start_unordered_list(stack, depth, 0);
    }
    else if (strcmp(element, "DL") == 0) {
      struct attr *compact = query_attribute(stack, "COMPACT");

      if (compact->values != NULL && strcmp(compact->values, "COMPACT") == 0)
	start_uns_def_list(stack, depth, 1);
      else
	start_uns_def_list(stack, depth, 0);
    }
    else if (strcmp(element, "TABLE") == 0) {
      current_table = current_table->next;
      /* in case of nested tables.  */
      while (current_table->done == 1)
	current_table = current_table->next;
      nesting++;
      if (c_line.family == FAM_TEX) {
	int i;

	if (nesting == 1) {
	  output.need_par = 1;
	  if (current_table->caption != NULL
	      && current_table->caption_align == TOP) {
	    gfputs ("\\tablecaption{");
	    if (current_table->align == ALIGN_LEFT)
	      gfputs ("l");
	    else if (current_table->align == ALIGN_RIGHT)
	      gfputs ("r");
	    else
	      gfputs ("c");
	    gfprintf ("}{%s}", current_table->caption);
	    output.need_par = 1;
	  }
	  gfputs ("\\makebox[\\textwidth][");
	  if (current_table->align == ALIGN_LEFT)
	    gfputs ("l");
	  else if (current_table->align == ALIGN_RIGHT)
	    gfputs ("r");
	  else
	    gfputs ("c");
	  gfputs ("]{");
	}
	output.need_wrap = 1;
	gfputs("\\begin{tabular}{");
	if (current_table->border_type != NONE) {
	  gfputs ("|");
	  for (i = 0; i < current_table->max_columns; i++)
	    gfputs ("c|");
	}
	else {
	  for (i = 0; i < current_table->max_columns; i++)
	    gfputs ("c");
	}
	gfputs("}"); 
	output.need_wrap = 1;
	if (current_table->border_type != NONE) {
	  gfputs("\\hline");
	  output.need_wrap = 1;
	}
      }
      else {			/* not FAM_TEX.  */
	char *ALIGN_LEFT = check_style("table-replace-l");
	char *ALIGN_RIGHT = check_style("table-replace-r");

	output.need_line = 1;
	gfputs (ALIGN_LEFT);
	if (current_table->caption != NULL && nesting == 1)
	  gfprintf (": %s", current_table->caption);
	gfputs (ALIGN_RIGHT);
	output.need_line = 1;
	start_storage ("TABLE");
      }
    }
    else if (strcmp (element, "CAPTION") == 0)
      start_storage ("CAPTION");
    else if (strcmp(element, "TD") == 0 || strcmp (element, "TH") == 0) {
      if (c_line.family == FAM_TEX) {
	struct attr *colspan = check_attribute (stack, "COLSPAN");
	char *ptr;
	long span = strtol (colspan->values, &ptr, 10);

	if (*ptr != '\0')
	  error (WARN, 0, "bad COLSPAN attribute `%s'", colspan->values);

	if (current_table->column > 0)
	  gfputs (" & ");

	if (span > 1) {
	  gfprintf ("\\multicolumn{%d}{", span);
	  if (current_table->border_type != NONE) {
	    if (current_table->column == 0)
	      gfputs ("|c|}{");
	    else
	      gfputs ("c|}{");
	  }
	  else
	    gfputs ("c}{");
	  current_table->column += span;
	}
	else 
	  current_table->column++;
	if (strcmp (element, "TH") == 0)
	  gfputs ("\\tablehead{");
      }
    }
    else if (strcmp(element, "LI") == 0) {
      start_list_item(stack, depth, 0);
    }
    else if (strcmp(element, "DT") == 0) {
      start_uns_def_tag(stack, depth);
    }
    else if (strcmp(element, "DD") == 0) {
      start_uns_def_data(stack, depth);
    }
    else if (strcmp(element, "FORM") == 0) {
      char *uri_status = check_style("uri-status");
      struct attr *url = query_attribute(stack, "ACTION");

      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\begin{htmlform}");
	if (strcmp(uri_status, "uri-omit") != 0) {
	  gfputs("[");
	  if (strcmp(uri_status, "uri-atend") == 0)
	    add_ref(url->values, URI_URL);
	  else
	    print_raw_url(stack, depth, url->values);
	  gfputs("]");
	}
	output.need_wrap = 1;
      }
      else { /* Not TeX.  */
	char *form_begin_l = check_style("form-begin-l");
	char *form_begin_r = check_style("form-begin-r");

	output.need_gap = 1;
	gfputs(form_begin_l);
	if (strcmp(uri_status, "uri-omit") != 0) {
	  if (strcmp(uri_status, "uri-atend") == 0)
	    add_ref(url->values, URI_URL);
	  else
	    print_raw_url(stack, depth, url->values);
	  gfputs(form_begin_r);
	}
	output.need_gap = 1;
      }
    }
    else if (strcmp(element, "INPUT") == 0) {
      struct attr *type = check_attribute(stack, "TYPE");
      
      if (strcmp(type->values, "IMAGE") == 0)
	process_image(stack, depth);
    }
    else if (strcmp(element, "TITLE") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\title{");
      else if (c_line.family == FAM_PLAIN) {
	output.alignment = CENTRE; /* Centre the title.  */
      }
      else if (c_line.setter == RTF) {
	char *font = check_style("ftitle");
	char *style = check_style("stitle");
	gfprintf("}{\\pard\\plain\\f%s\\s%s\\qc ", font, style);
      }
    }
    else if (strcmp(element, "ADDRESS") == 0) {
      output.need_par = 1;
      if (c_line.family == FAM_TEX)
	gfputs("\\address{");
      dtd.in_address = 1;
    }
    else if (strcmp (element, "DIV") == 0) {
      struct attr *align = check_attribute(stack, "ALIGN");

      start_alignment (align->values);
    }
    else if (strcmp (element, "CENTER") == 0)
      start_alignment ("CENTER");
    else if (strcmp(element, "BASE") == 0) {
      struct attr *href = query_attribute(stack, "HREF");

      if (href != NULL && href->values != NULL) {
	/* HREF can not be omitted if the document is conforming.  */
	if (c_line.family == FAM_TEX)
	  gfputs("\\base{");
	else {
	  char *base_delim = check_style("base-delimiter-l");

	  gfputs(base_delim);
	}
	print_raw_url(stack, depth, href->values);
	if (c_line.family == FAM_TEX) {
	  gfputs("}");
	  output.need_wrap = 1;
	}
	else
	  output.need_gap = 1;
      }
    }
    /* not producing any output for these.  */
    else if (strcmp (element, "SCRIPT") == 0 || strcmp (element, "STYLE") == 0)
      start_storage (element);
    /* not doing anything with <LINK> or <META> or <APPLET>.  */
  }
}

void html_element_end(struct stack *stack, int depth)
{
  char *element = stack->element;

  if (dtd.pass == 1) {
    if (strcmp (element, "TABLE") == 0) {
      current_table->done = 1;
      /* in case of nested tables, get back to parent. */
      while (current_table->prev != NULL) {
	current_table = current_table->prev;
	if (current_table->done == 0)
	  break;
      }
      if (current_table->done == 1) {
	while (current_table->next != NULL)
	  current_table = current_table->next;
      }
    }
    else if (strcmp (element, "CAPTION") == 0) {
      struct stored_text *text_ptr = end_storage();

      output.discard_text = 1;
      current_table->caption = galloc (strlen (text_ptr->text) + 1);
      strcpy (current_table->caption, text_ptr->text);
      if (output.store_text == 0)
	free_storage();	
    }
    else if (strcmp (element, "TR") == 0) {
      if (current_table->column > current_table->max_columns)
	current_table->max_columns = current_table->column;
      current_table->column = 0;
    }
  }
  else {			/* pass == 2  */
    text.new_par = 0;
    if (strcmp(element, "P") == 0) {
      struct attr *align = query_attribute(stack, "ALIGN"); /* HTML 3.2.  */

      end_paragraph(stack, depth);
      if (align != NULL && align->values != NULL)
	end_alignment (align->values);
    }
    else if (strcmp(element, "BR") == 0)
      text.new_par = 1;
    else if (strcmp(element, "HR") == 0) {
      text.new_par = 1;
    }
    else if (strcmp(element, "EM") == 0)
      end_emphasize(stack, depth);
    else if (strcmp(element, "STRONG") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("}");
      else if (c_line.family == FAM_PLAIN) {
	char *delim = check_style("strong-delimiter");

	gfputs(delim);
      }
      else if (c_line.family == FAM_RTF) {
	gfprintf("}%s ", output.new_par);
      }
    }
    else if (strcmp(element, "CITE") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("}");
      else if (c_line.family == FAM_PLAIN) {
	char *delim = check_style("cite-delimiter-r");

	gfputs(delim);
      }
      else if (c_line.family == FAM_RTF) {
	gfprintf("}%s ", output.new_par);
      }
    }
    else if (strcmp(element, "B") == 0)
      end_bold(stack, depth);
    else if (strcmp(element, "I") == 0)
      end_italic(stack, depth);
    else if (strcmp(element, "U") == 0)
      end_underline(stack, depth);
    else if (strcmp(element, "TT") == 0)
      end_code_inline(stack, depth);
    else if (strcmp (element, "BIG") == 0 || strcmp (element, "SMALL") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs ("}");
    }
    else if (strcmp (element, "SUP") == 0 || strcmp (element, "SUB") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs ("}$");
      else
	gfputs (")");
    }
    else if (strcmp(element, "A") == 0) {
      struct attr *url = query_attribute(stack, "HREF");
      struct attr *urn = query_attribute(stack, "URN");
      struct attr *name = query_attribute(stack, "NAME");
      char *uri_status = check_style("uri-status");
      int url_include = 0;	/* Flag for including URL.  */
      int url_atend = 0;		/* Flag for URL at end.  */
      int urn_include = 0;	/* Flag for including URN.  */
      int urn_atend = 0;		/* Flag for URN at end.  */

      if (name != NULL && name->values != NULL) {
	/* This anchor can be used as a destination.  */
	if (c_line.family == FAM_TEX) {
	  gfputs("\\label{");
	  html_chars(stack, depth, name->values);
	  gfputs("}");
	}
      }

      /* Find from the style sheet whether URIs should be included,
       * moved to the end or omitted.
       */
      if (strcmp(uri_status, "uri-atend") == 0) {
	if (url != NULL && url->values != NULL)
	  url_atend = 1;
	if (urn != NULL && urn->values != NULL)	
	  urn_atend = 1;
      }
      else if (strcmp(uri_status, "uri-include") == 0) {
	if (url != NULL && url->values != NULL)
	  url_include = 1;
	if (urn != NULL && urn->values != NULL)	
	  urn_include = 1;
      }

      if (url != NULL && url->values != NULL
	  && c_line.family == FAM_TEX && url->values[0] == '#') {
	/* If the first character is #, produce an xref instead of a
	 * URL reference.
	 */
	gfputs(" \\xref{");
	html_chars(stack, depth, url->values + 1);
	gfputs("}");
	url_include = 0;
	url_atend = 0;
      }

      /* Print the URI(s) or the pointers to the reference list.  */
      /* First the URL.  */
      if (url_include) {
	gfputs(" ");
	print_raw_url(stack, depth, url->values);
      }
      else if (url_atend)
	add_ref(url->values, URI_URL);

      /* Then the URN.  */
      if (urn_include) {
	gfputs(" ");
	print_raw_urn(stack, depth, urn->values);
      }
      else if (urn_atend)
	add_ref(urn->values, URI_URN);

      if (c_line.family == FAM_TEX) {
	/* Close the \anchor macro.  */
	gfputs("}");
      }
    }
    else if (element[0] == 'H' && element[2] == '\0') {
      int head_level = element[1] - '0';

      end_heading(stack, depth, head_level, 0);
      text.new_par = 1;
    }
    else if (strcmp(element, "BLOCKQUOTE") == 0)
      end_longquote(stack, depth);
    else if (strcmp(element, "PRE") == 0 || strcmp(element, "XMP") == 0
	     || strcmp(element, "LISTING") == 0
	     || strcmp(element, "PLAINTEXT") == 0) {
      end_code_lines(stack, depth);
      text.new_par = 1;
    }
    else if (strcmp(element, "CODE") == 0 || strcmp(element, "SAMP") == 0
	     || strcmp(element, "KBD") == 0 || strcmp(element, "KEY") == 0
	     || strcmp(element, "VAR") == 0 || strcmp(element, "DFN") == 0) {
      end_code_inline(stack, depth);
    }
    else if (strcmp(element, "TABLE") == 0) {
      current_table->done = 1;
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\end{tabular}");
	output.need_wrap = 1;
	if (nesting == 1) {
	  gfputs ("}");
	  output.need_par = 1;
	  if (current_table->caption != NULL
	      && current_table->caption_align == BOTTOM) {
	    gfputs ("\\tablecaption{");
	    if (current_table->align == ALIGN_LEFT)
	      gfputs ("l");
	    else if (current_table->align == ALIGN_RIGHT)
	      gfputs ("r");
	    else
	      gfputs ("c");
	    gfprintf ("}{%s}", current_table->caption);
	    output.need_par = 1;
	  }
	}
      }
      else {			/* not FAM_TEX.  */
	end_storage();
	if (output.store_text == 0)
	  free_storage();
      }
      /* in case of nested tables, get back to parent. */
      while (current_table->prev != NULL) {
	current_table = current_table->prev;
	if (current_table->done == 0)
	  break;
      }
      while (current_table->done == 1)
	current_table = current_table->next;
      nesting--;
    }
    else if (strcmp (element, "CAPTION") == 0) {
      end_storage();
      if (output.store_text == 0)
	free_storage();	
    }
    else if (strcmp (element, "TD") == 0 || strcmp (element, "TH") == 0) {
      if (c_line.family == FAM_TEX) {
	struct attr *colspan = check_attribute (stack, "COLSPAN");
	char *ptr;
	long span = strtol (colspan->values, &ptr, 10);

	/* close the \tablehead argument.  */
	if (strcmp (element, "TH") == 0)
	  gfputs ("}");
	/* close the \multicolumn argument.  */
	if (span > 1)
	  gfputs ("}");
      }
    }
    else if (strcmp (element, "TR") == 0) {
      if (c_line.family == FAM_TEX) {
	while (current_table->column < current_table->max_columns) {
	  gfputs (" &");
	  current_table->column++;
	}
	gfputs("\\\\");
	output.need_wrap = 1;
	if (current_table->border_type != NONE) {
	  gfputs ("\\hline");
	  output.need_wrap = 1;
	}
      }
      current_table->column = 0;
    }
    else if (strcmp(element, "OL") == 0)
      end_ordered_list(stack, depth, 0);
    else if (strcmp(element, "UL") == 0 || strcmp(element, "DIR") == 0
	     || strcmp(element, "MENU") == 0)
      end_unordered_list(stack, depth);
    else if (strcmp(element, "LI") == 0)
      end_list_item(stack, depth);
    else if (strcmp(element, "DL") == 0)
      end_uns_def_list(stack, depth);
    else if (strcmp(element, "DT") == 0)
      end_uns_def_tag(stack, depth);
    else if (strcmp(element, "DD") == 0)
      end_uns_def_data(stack, depth);
    else if (strcmp(element, "FORM") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\end{htmlform}");
      }
      else { /* Not TeX.  */
	char *form_end = check_style("form-end");
      
	output.need_gap = 1;
	gfputs(form_end);
	output.need_gap = 1;
      }
    }
    else if (strcmp(element, "HTML") == 0) {
      /* Create the list of references if required.  */
      char *uri_status = check_style("uri-status");
      int ref_num = 0;		/* Used for the labels.  */

      dtd.list_end = &dtd.uri_list; /* Steps through the list.  */
      if (strcmp(uri_status, "uri-atend") == 0
	  && dtd.uri_list.next != NULL) {
	if (c_line.family == FAM_TEX) {
	  output.need_wrap = 1;
	  gfputs("\\begin{thebibliography}{1}");
	  output.need_wrap = 1;
	}
	else if (c_line.family == FAM_PLAIN || c_line.family == FAM_RTF) {
	  char *ref_list_header = check_style("ref-list-header");
	
	  output.need_gap = 1;
	  gfputs(ref_list_header);
	  output.need_gap = 1;
	}
	
	while (dtd.list_end->next != NULL) {
	  ref_num++;
	  if (c_line.family == FAM_TEX) {
	    gfprintf("\\bibitem{%d}", ref_num);
	  }
	  else {
	    char *ref_delim_l = check_style("ref-delimiter-l");
	    char *ref_delim_r = check_style("ref-delimiter-r");

	    gfprintf("%s%d%s ", ref_delim_l, ref_num, ref_delim_r);
	  }
	  if (dtd.list_end->type == URI_URL)
	    print_raw_url(stack, depth, dtd.list_end->text);
	  else
	    print_raw_urn(stack, depth, dtd.list_end->text);

	  if (c_line.family == FAM_TEX)
	    output.need_wrap = 1;
	  else
	    output.need_line = 1;

	  dtd.list_end = dtd.list_end->next;
	}
	if (c_line.family == FAM_TEX) {
	  gfputs("\\end{thebibliography}");
	  output.need_wrap = 1;
	}
      }
      end_document(stack, depth);
    }
    else if (strcmp(element, "TITLE") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("}");
	output.need_wrap = 1;
	gfputs("\\maketitle");
	output.need_wrap = 1;
      }
      else if (c_line.family == FAM_PLAIN) {
	output.need_line = 1;
	output_flush();	      /* Flush any pending text with old alignment. */
	output.alignment = ALIGN_LEFT;  /* Restore default text alignment.  */
	output.need_gap = 1;
      }
      else if (c_line.setter == RTF)
	output.need_gap = 1;
    }
    else if (strcmp(element, "ADDRESS") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("}");
      output.need_par = 1;
      text.new_par = 1;
      dtd.in_address = 0;
    }
    else if (strcmp (element, "DIV") == 0) {
      struct attr *align = check_attribute(stack, "ALIGN");

      end_alignment (align->values);
    }
    else if (strcmp (element, "CENTER") == 0)
      end_alignment ("CENTER");
    else if (strcmp (element, "SCRIPT") == 0 || strcmp (element, "STYLE") == 0)
      {
	end_storage();
	if (output.store_text == 0)
	  free_storage();	
      }
  }
}

/* Amount of memory to grab at once when reading files.  */
#define BLOCK 1000

/* Process an external entity reference.  */
void html_x_ent(struct stack *stack, int depth,
		struct entity_info *entity_ptr)
{
  error(EXIT, 0, "html: external entities not supported");
}

void html_chars(struct stack *stack, int depth, char *string)
{
  if (output.discard_text) {
    /* Don't call print_escaped while discarding text: it can introduce
     * wraps etc.
     */
    return;
  }
  /* This kludge allows a paragraph boundary to be detected between
   * free text in the body (currently permitted by the DTD) and
   * text in a paragraph.
   */
  if (depth == 2 && strcmp(string, "\n") != 0)
    text.par_pending = 1;

  string = map_non_ASCII(string, &lat1_chars); /* Map latin1 characters.  */

  if (!(text.contents->respect_spaces && text.contents->preserve_breaks)) {
    tidy_string(string, text.contents->respect_spaces,
		text.contents->preserve_breaks);
    if (!text.contents->respect_spaces && text.new_par)
      strip_leading_blanks(string);
  }
  string = replace_sdata(string, &sdata, text.contents->tt,
			 text.contents->math);

  print_escaped(string, 1, text.contents->tt, text.contents->math);
}

int html_end()
{
  dtd.pass++;

  if (dtd.pass > 2)
    return(1);			/* Finished.  */
  else
    return(0);			/* Do another pass.  */
}
