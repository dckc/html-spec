/* Tables.
 * Copyright (C) 1993 Gary Houston
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gf.h"
#include "table.h"

struct gen_tbl_foot *gen_tbl_foot;
struct table table;

/* Initialize table data structures. Call this before each pass through
 * the document. 
 */
void init_table(void)
{
  table.tbl_cols = NULL;
  gen_tbl_foot = NULL;
}

/* Tables, as used in the general DTD.  */
/* Only supported for LaTeX.  */
void start_gen_table(struct stack *stack, int depth)
{
  char *cols = check_attribute(stack, "COLS")->values;
  char *last;			/* Pointer for strtol.  */
  /* Pointer to current column data.  */
  struct tbl_cols *old_cols = table.tbl_cols;
  /* Pointer to current footer data.  */
  struct gen_tbl_foot *old_footer = gen_tbl_foot;

  /* Store the number of columns of the table.  */
  table.tbl_cols = galloc(sizeof(struct tbl_cols));
  table.tbl_cols->cols = strtol(cols, &last, 10);
  if (*last != '\0')
    error(EXIT, 0, "Unable to interpret COLS attribute of TBL");
  table.tbl_cols->prev = old_cols;

  /* Create a new link in the footer structure.  */
  gen_tbl_foot = galloc(sizeof(struct gen_tbl_foot));
  gen_tbl_foot->prev = old_footer;
  gen_tbl_foot->tbl_foot_row.next = NULL;

  if (c_line.family == FAM_TEX) {
    gfprintf("\\begin{gentable}{%d}", table.tbl_cols->cols);
    output.need_wrap = 1;
    gfputs("\\rowrule");
    output.need_wrap = 1;
  }
  else
    error(EXIT, 0, "general table only supports LaTeX");
}

/* Free the footer structure, by recursively stepping through the list.  */
static void free_foot_link(struct tbl_foot_row *row_ptr)
{
  if (row_ptr->next == NULL)
    return;
  free_foot_link(row_ptr->next);
  gfree(row_ptr->next);
  gfree(row_ptr->tbl_foot);
  row_ptr->next = NULL;
}

void end_gen_table(struct stack *stack, int depth)
{
  /* Previous (parent) table column and foot information, or NULL.  */
  struct tbl_cols *old_cols = table.tbl_cols->prev;
  struct gen_tbl_foot *old_footer = gen_tbl_foot->prev;

  if (c_line.family == FAM_TEX) {
    /* Pointer to the footer rows.  */
    struct tbl_foot_row *row_ptr = &gen_tbl_foot->tbl_foot_row;

    /* Print any stored footer rows.  */
    while (row_ptr->next != NULL) {
      gfputs("\\rowrule");
      output.need_wrap = 1;
      gfputs(row_ptr->tbl_foot);
      gfputs("\\cr");
      output.need_wrap = 1;
      row_ptr = row_ptr->next;
    }
    gfputs("\\rowrule");
    output.need_wrap = 1;
    gfputs("\\end{gentable}");
    output.need_wrap = 1;
  }

  /* Restore the previous column count.  */
  gfree(table.tbl_cols);
  table.tbl_cols = old_cols;

  /* Free the current footer structure and restore the previous information. */
  free_foot_link(&gen_tbl_foot->tbl_foot_row);
  gfree(gen_tbl_foot);
  gen_tbl_foot = old_footer;
}

/* The footer line(s) occur at the beginning of the table.  Presumably they
 * should be put at the foot of each page, if more than one page is
 * needed.  Here the footer information is stored in a linked list and
 * printed at the end of the table.
 */
void start_gen_foot_row(struct stack *stack, int depth)
{
  start_storage("FOOT");
}

/* Add the stored text to the linked list.  */
void end_gen_foot_row(struct stack *stack, int depth)
{
  struct stored_text *text_ptr = end_storage();
  char *text = text_ptr->text;
  /* Pointer to the footer rows.  */
  struct tbl_foot_row *row_ptr = &gen_tbl_foot->tbl_foot_row;
  
  /* Find the end of the linked list.  */
  while (row_ptr->next != NULL)
    row_ptr = row_ptr->next;
  
  /* Add the new footer line.  */
  row_ptr->next = galloc(sizeof(struct tbl_foot_row));
  row_ptr->next->next = NULL;
  row_ptr->tbl_foot = galloc(strlen(text) + 1);
  strcpy(row_ptr->tbl_foot, text);
  /* Free the stored text, if not storing for some other reason.  */
  if (output.store_text == 0)
    free_storage();
  else {
    /* Just hide the stored line.  */
    strcpy(text_ptr->key, "");
  }
}
