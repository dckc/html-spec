enum dtds {SMEMO = 0, SPAPER, SLETTER, HTML, GENERAL, NO_DTD};
enum setters {LATEX2E = 0, AB, AS, L1B, L1S, RTF, TEXINFO};
/* Each formatter is classified to a "family".  */
enum families {FAM_TEX = 0, FAM_PLAIN, FAM_RTF, FAM_TEXINFO};

#define NUM_DTDS 5
#define NUM_SETTERS 7
#define NUM_FAMILIES 4
#define STYLE_EXT ".style"
#define ELEMENT_EXT ".el"
#define TEMPLATE_EXT ".template"
/* Extension for EPS files created by gf from other image formats.  */
#define EPS_EXT ".ps"
#define PARSER "nsgmls"
/* Name of user's directory to search.  */
#define USERDIR ".gf"

enum success {FAIL, OK};
enum io_mode {READ, WRITE};
enum align {LEFT, CENTRE};	/* Fixed width alignment of text.  */

#define SDATA_TEMP '\034'
#define EXIT 1
#define WARN 0

/* Command line options and input file information.  */
struct c_line {
  char *style_file;		/* Name of a style file.  */
  char *prog_name;		/* The name the program was invoked with.  */
  char **sgml_file;		/* Document(s) to be formatted.  */
  int num_files;		/* Number of documents to be formatted.  */
  enum dtds new_doc;		/* DTD, for -n option.  */
  char **base_name;		/* sgml_file(s) less any extension.  */
  char **dir_name;		/* Relative directories of the files.  */
  char *out_file;		/* Name of the formatted document.  */
  char *popts;			/* Options to be given to the parser.  */
  int parse_only;		/* 1 means don't format, just parse.  */
  enum setters setter;		/* Which formatter to use.  */
  enum families family;		/* What type of formatter it is.  */
  int verbose;			/* 1 means show file accesses and version.  */
  int style_doc;		/* 1 if style documentation required.  */
  enum dtds dtd;		/* DTD of the document.  */
			        /* OK, not really a command line option.  */
};


/* Style options from a style sheet.
 * This is a linked list with each element holding the name
 * and value for a single option.
 */
struct style {
  char *key;
  char *value;
  struct style *next;
};

/* Style information from SGML documentation of a style sheet.
 * This is a linked list with each element holding the documentation
 * for a single option.
 */
struct style_doc {
  char *key;			/* Name of the option.  */
  char *type;			/* Type: element, number, cdata etc.  */
  char *values;			/* Possible values, if type == "list".
				 * This should be a blank separated list.
				 */
  char *text;			/* Documentation string.  */
  struct style_doc *next;	/* Next link in the list.  */
};

/* The stack with element, attribute, notation and external entity information
 * for each active level.
 */
struct stack {
  char *element;		/* Element name.  */
  struct attr {			/* Attribute linked list.  */
    char *name;
    char *type;
    char *values;
    struct attr *next;
  } attr;
};

/* Sdata translation tables, a linked list.  */
struct sdata_table {
  char *key;
  char *value;
  struct sdata_table *next;
};

/* Text which has been stored in memory rather than printed directly.  */
struct stored_text {		/* Linked list of stored texts.  */
  char *key;			/* Name of the text.  */
  char *text;			/* The text itself.  */
  struct stored_text *next;	/* Next link in the list.  */
};

/* Control/status of the low level output routines.  */
struct output {
  FILE *stream;       /* The output stream.  */
  int store_text;     /* If non-zero, store text rather than print it.  */
  /* A linked list with pointers to the current and previous places to 
   * store text, if any.
   */
  struct pointers {
    struct stored_text *store_ptr; /* Where to put stored text.  */
    struct pointers *prev;	   /* Pointer to the last place.  */
  } *pointers;
  int discard_text;   /* Throw away all text if non-zero.  */
  int line_width;     /* Maximum characters on a line, or 0 for no breaking. */
  enum align alignment; /* How fixed width output is to be aligned.  */
  char *new_line;     /* Text to be output whenever a line is broken.  */
  /* Text to be put at the beginning of every line.  This acts as a stack,
   * since the usual case is for text to be temporarily added (e.g., while
   * indenting list items.)
   */
  struct lead_text {
    char *text;
    struct lead_text *prev;
  } *lead_text;
  char *new_par;      /* Maybe text to output for new paragraphs.  */
  int need_wrap;      /* Need to start following text on a new physical line */
  int need_line;      /* Need to start following text on a new logical line. */
  int need_par;       /* A paragraph is pending.  */
  int need_gap;       /* vspace is pending.  */
  int done_open_quote;/* Indicates a  TeX double quote has been printed.  */
  int done_apost;     /* Indicates a TeX apostrophe has been printed. */
};

struct notation_info {
  /* Linked list with notation information, reported by sgmls when
   * the notation is used for the first time.
   */
  char *notation;		/* Notation name.  */
  char *pub_id;			/* Public identifier.  */
  char *sys_id;			/* System identifier.  */
  struct notation_info *next;	/* Next link in the list.  */
};

/* Linked list with external entity information, reported by sgmls when
 * the entity is used for the first time.
 */
struct entity_info {
  char *name;			/* Entity name.  */
  char *notation;		/* Notation.  */
  char *pub_id;			/* Public identifier.  */
  char *sys_id;			/* System identifier.  */
  char *filename;		/* File name.  */
  struct entity_info *next;	/* Next link in the list.  */
};

extern char *dtd_names[];
extern char *style_doc_files[];
extern char *setter_names[];
extern char *family_names[];
extern enum families family[];
extern char *version;
extern char *libdir;
extern char *userdir;

/* Check whether the high bit of a char is set -- from GNU C library.  */
#define gf_isascii(c)    (((c) & (1 << 7)) == 0)

/* Typedefs for DTD specific functions.  */

typedef void (el_fun)(struct stack *stack, int depth);
typedef void (ent_fun)(struct stack *stack, int depth,
		       struct entity_info *entity_ptr);
typedef void (char_fun)(struct stack *stack, int depth, char *text);
typedef int (end_fun)(void);

extern el_fun *dtd_element_start[];
extern el_fun *dtd_element_end[];
extern ent_fun *dtd_x_ent[];
extern char_fun *dtd_chars[];
extern end_fun *dtd_end[];

extern struct c_line c_line;
extern struct sd_info sd_info;
extern struct style style;
extern struct style_doc style_doc;
extern struct output output;
extern struct stored_text stored_text;

/* c_line.c */
extern void parse_c_line(int argc, char *argv[]);
extern void new_doc(void);

/* misc.c */
extern int exists(char *file_name);
extern char *exists_user_dir(char *file_name);
extern char *exists_system_dir(char *file_name);
extern double diff_filetime(char *file1, char *file2);
extern void *galloc(size_t size);
extern void gfree(void *block);
extern void *grealloc(void *block, size_t size);
extern char *read_string(FILE *stream, char *sep_chars, int *last_char);
extern int skip_chars(FILE *stream, char *sep_chars);
extern void lower_case(char *string);
extern int ci_strcmp(char *s1, char *s2);
extern void verbose(char *file_name, enum success status, enum io_mode mode);
extern void verbose_command(char *command);
extern void verbose_putenv(char *str);
extern int gf_putenv(char *string);

/* style.c */
extern void parse_style_file(char *file_name, enum families family);
extern void get_style(char *style_file, enum families family, enum dtds dtd,
		      char **sgml_file, int num_files, char **base_name);
extern char *find_style(char *key);
extern char *check_style(char *key);

/* document.c */
extern struct entity_info *query_entity(char *name);
extern void parse_document(void);
extern int is_open(struct stack *stack, int depth, char *element);
extern struct attr *query_attribute(struct stack *stack, char *attribute);
extern struct attr *check_attribute(struct stack *stack, char *attribute);
extern char *query_attr_type(struct stack *stack, char *attribute);
extern void print_style_doc(enum dtds dtd);

/* error.c */
extern void error(int status, int errnum, char *message, ...);

/* gfstr.c */
extern void unescape_data(char *text);
extern void tidy_string(char *text, int respect_spaces, int preserve_breaks);
extern void strip_leading_blanks(char *text);
extern void strip_blanks(char *text);

/* gfchar.c */
extern void get_sdata_translations(char *file_name, struct sdata_table *table);
extern void get_sdata_local(char *extension, struct sdata_table *table);
extern char *query_sdata(struct sdata_table *sdata, char *key);
extern char *map_non_ASCII(char *text, struct sdata_table *sdata);
extern char *replace_sdata(char *text, struct sdata_table *sdata, int in_tt,
			   int in_tex);
extern void print_escaped(char *text, int sent_blanks, int in_tt, int in_tex);

/* output.c */
extern void gfprintf(char *text, ...);
extern void gfputs(char *text);
extern void output_close(void);
extern void output_flush(void);
extern void start_storage(char *key);
extern struct stored_text *end_storage(void);
extern struct stored_text *get_stored_text(char *key);
extern void store_text(char *text);
extern void free_storage(void);
extern void push_lead_text(char *text);
extern void push_lead_blanks(int num);
extern void pop_lead_text(void);

/* detect.l */
extern int auto_detect(void);

/* spaper.c */
extern el_fun spaper_element_start;
extern el_fun spaper_element_end;
extern ent_fun spaper_x_ent;
extern char_fun spaper_chars;
extern end_fun spaper_end;

/* smemo.c */
extern el_fun smemo_element_start;
extern el_fun smemo_element_end;
extern ent_fun smemo_x_ent;
extern char_fun smemo_chars;
extern end_fun smemo_end;

/* sletter.c */
extern el_fun sletter_element_start;
extern el_fun sletter_element_end;
extern ent_fun sletter_x_ent;
extern char_fun sletter_chars;
extern end_fun sletter_end;

/* html.c */
extern el_fun html_element_start;
extern el_fun html_element_end;
extern ent_fun html_x_ent;
extern char_fun html_chars;
extern end_fun html_end;

/* general.c */
extern el_fun general_element_start;
extern el_fun general_element_end;
extern ent_fun general_x_ent;
extern char_fun general_chars;
extern end_fun general_end;
