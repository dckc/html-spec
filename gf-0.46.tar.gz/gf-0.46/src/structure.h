/* Structure elements: start/end document, sections, appendix.  */

#define MAX_H_LEVEL 6

struct structure {
  int infrontm;			/* 1 when processing the header.  */
  int inbackm;			/* 1 when processing the back.  */
  int inheading;		/* 1 when processing a section heading.  */
  int h_counters[MAX_H_LEVEL + 1]; /* Section numbers.  */
  int max_h;			/* Maximum section number, before appendix.  */
  int inappendix;		/* Inside appendix.  */
  char *node;			/* Current node name for Texinfo.  */
  int node_size;		/* size of the node buffer.  */
};

extern struct structure structure;

/* Tree structure containing sectioning information for the Texinfo 
 * formatter.
 */
struct info_tree {
  char *node;			/* Name of this node.  */
  char *title;			/* Full section title.  */
  struct branches {		/* Linked list of branches.  */
    struct info_tree *branch;	/* Pointer to the sub-tree.  */
    struct branches *next;	/* Pointer to the next branch.  */
  } branches;
};

extern struct info_tree info_tree;

extern void init_structure(void);
extern void start_document(struct stack *stack, int depth);
extern void end_document(struct stack *stack, int depth);

extern struct info_tree *get_node(struct info_tree *tree, int num_steps,
				  int counters[]);
extern struct info_tree *match_node(struct info_tree *tree, char *node);
extern void add_node(char *node, char *title, int depth, int counters[]);
extern void escape_node_name(char *text);
extern void start_heading(struct stack *stack, int depth, int head_level, 
			  int store);
extern void end_heading(struct stack *stack, int depth, int head_level,
			int store);

extern void start_appendix(struct stack *stack, int depth);
