/* Routines for the ISO "general" formatters.
 * Copyright (C) 1993, 1994, 1996 Gary Houston
 * This program may be copied and modified under the terms of the 
 * GNU General Public License version 2.
 *
 * Public functions: general_element_start,
 * general_element_end, general_x_ent, general_chars, general_end.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include "gf.h"
#include "text.h"
#include "structure.h"
#include "header.h"
#include "displayed.h"
#include "link.h"
#include "list.h"
#include "table.h"
#include "figure.h"
#include "index.h"

/* Translations for mapping SDATA to output.  */
static struct sdata_table sdata;

/* Data local to this DTD.  */
static struct {
  int pass;			/* Pass number through the document. */
  int in_title_page;		/* Whether currently inside the title page.  */
} dtd;

/* Initialise data structures (once).  */
static void dtd_init(struct stack *stack, int depth)
{
  char *ptr;			/* Dummy pointer.  */
  char *ext;			/* Extension for SDATA files.  */

  dtd.pass = 1;			/* 1st pass through document.  */

  output.discard_text = 1;	/* Don't print text on first pass.  */

  xlink.cross_ref.next = NULL;	/* Linked list for cross-ref information.  */

  /* Initialize data structures.  These also get called at the beginning
   * of the second pass.
   */
  init_text();
  init_structure();
  init_display();
  init_figure();
  init_list();
  init_table();

  if (c_line.family == FAM_TEX) {
    char *width = check_style("line-width");

    output.line_width = strtol(width, &ptr, 10); /* Auto line breaking.  */
    ix.need_index = 0;

    ext = ".2tex";
  }
  else {
    error(EXIT, 0, "formatter `%s' is not supported for %s",
	  setter_names[c_line.setter], dtd_names[c_line.dtd]);
  }
  /* Read SDATA translation tables.  */
  {
    char file[20];		/* File names.  */

    sdata.next = NULL;
    get_sdata_local(ext, &sdata);

    sprintf(file, "ISOlat1%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOlat2%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOnum%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOpub%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOdia%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "ISOtech%s", ext);
    get_sdata_translations(file, &sdata);
    sprintf(file, "GFextra%s", ext);
    get_sdata_translations(file, &sdata);
  }
}

void general_element_start(struct stack *stack, int depth)
{
  char *element = stack->element;
  static int first = 1;

  if (first) {
    dtd_init(stack, depth);
    first = 0;
  }
  if (dtd.pass == 1) {
    /* On the first pass, search for index and measure widths of DL tags.  */
    if (c_line.family == FAM_TEX) {
      if (strcmp(element, "INDEX") == 0)
	ix.need_index = 1;
    }
    else {
      if (strcmp(element, "BACKM") == 0)
	structure.inbackm = 1;
      else if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
	int head_level = element[1] - '0';

	start_heading(stack, depth, head_level, 0);
      }
      else if (strcmp(element, "OL") == 0)
	start_ordered_list(stack, depth, 1, 0);
      else if (strcmp(element, "LI") == 0)
	start_list_item(stack, depth, 1);
      else if (strcmp(element, "FIG") == 0)
	start_gen_fig(stack, depth);
      else if (strcmp(element, "FN") == 0)
	start_note(stack, depth, 1);
      else if (strcmp(element, "APPENDIX") == 0)
	start_appendix(stack, depth);
      else if (strcmp(element, "INDEX") == 0)
	start_index(stack, depth, 1);
    }
  }
  else {
    if (strcmp(element, "P") != 0) {
      text.par_pending = 0;
    }
    text.new_par = 0;
    if (strcmp(element, "P") == 0)
      start_paragraph(stack, depth);
    else if (strcmp(element, "Q") == 0)
      start_shortquote(stack, depth);
    else if (strcmp(element, "LQ") == 0)
      start_longquote(stack, depth);
    else if (strcmp(element, "NOTE") == 0)
      start_note(stack, depth, 0);
    else if (strcmp(element, "GENERAL") == 0) {
      /* Reinitialize the data structures.  */
      init_text();
      init_structure();
      init_display();
      init_figure();
      init_list();
      init_table();
      output.discard_text = 0;
      start_document(stack, depth);
      if (c_line.family == FAM_TEX) {
	/* All title page elements are placed in the order that they appear
	 * in the source document, so can start immediately.
	 */
	if (ix.need_index) {
	  gfputs("\\makeindex");
	  output.need_wrap = 1;
	}
	gfputs("\\begin{document}");
	output.need_wrap = 1;
	gfputs("\\begin{titlepage}");
	output.need_wrap = 1;
	dtd.in_title_page = 1;
      }
    }
    else if (strcmp(element, "BODY") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\begin{body}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "BACKM") == 0)
      structure.inbackm = 1;
    else if (strcmp(element, "XMP") == 0) {
      struct attr *type = query_attribute(stack, "LINES");

      if (type != NULL && strcmp(type->type, "TOKEN") == 0
	    && strcmp(type->values, "LINES") == 0) {
	set_text_mode(1, 0, 1, 1);

	if (c_line.family == FAM_TEX) {
	  output.need_wrap = 1;
	  gfputs("\\begin{xmp}");
	  output.need_wrap = 1;
	}
	/* Reset the number of characters per line.  */
	if (c_line.setter != RTF && c_line.setter != TEXINFO) {
	  char *ptr;			/* Dummy pointer.  */
	  char *width = check_style("code-width");
	  
	  output_flush();	/* Flush pending text.  */
	  output.line_width = strtol(width, &ptr, 10);
	}
      }
      else			/* Flowed XMP.  */
	start_code_inline(stack, depth);
    }
    else if (strcmp(element, "ALINE") == 0 || strcmp(element, "TLINE") == 0)
      start_aline(stack, depth);
    else if (strcmp(element, "FIG") == 0)
      start_gen_fig(stack, depth);
    else if (strcmp(element, "ARTWORK") == 0)
      start_gen_artwork(stack, depth);
    else if (strcmp(element, "FIGCAP") == 0)
      start_gen_figcap(stack, depth);
    else if (strcmp(element, "FIGDESC") == 0) {
      /* Need a space between the caption and the description.  */
      gfputs(" ");
    }
    else if (strcmp(element, "FN") == 0)
      start_note(stack, depth, 0);
    else if (strcmp(element, "TBL") == 0)
      start_gen_table(stack, depth);
    else if (strcmp(element, "FR") == 0)
      start_gen_foot_row(stack, depth);
    else if (strcmp(element, "F") == 0 || strcmp(element, "H") == 0
	     || strcmp(element, "C") == 0) {
      gfputs("&");
      if (strcmp(element, "C") == 0) {
	struct attr *heading = query_attribute(stack, "HEADING");

	if (heading != NULL && strcmp(heading->type, "TOKEN") == 0
	    && strcmp(heading->values, "H") == 0)
	  gfputs("\\rowhead{");
      }
    }
    else if (strncmp(element, "TOP", 3) == 0 && element[4] == '\0') {
      int top_level = element[3] - '0';

      if (c_line.family == FAM_TEX) {
	if (top_level == 1)
	  gfputs("\\begin{topone}");
	else if (top_level == 2)
	  gfputs("\\begin{toptwo}");
	else if (top_level == 3)
	  gfputs("\\begin{topthree}");
	else if (top_level == 4)
	  gfputs("\\begin{topfour}");
	
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "TH") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\topheading{");
    }
    else if (strcmp(element, "OL") == 0) {
      struct attr *compact = query_attribute(stack, "COMPACT");

      if (compact->values != NULL && strcmp(compact->values, "COMPACT") == 0)
	start_ordered_list(stack, depth, 0, 1);
      else
	start_ordered_list(stack, depth, 1, 0);
    }
    else if (strcmp(element, "UL") == 0) {
      struct attr *compact = query_attribute(stack, "COMPACT");

      if (compact->values != NULL && strcmp(compact->values, "COMPACT") == 0)
	start_unordered_list(stack, depth, 1);
      else
	start_unordered_list(stack, depth, 0);
    }
    else if (strcmp(element, "SL") == 0)
      start_simple_list(stack, depth);
    else if (strcmp(element, "NL") == 0) {
      struct attr *compact = query_attribute(stack, "COMPACT");

      if (compact->values != NULL && strcmp(compact->values, "COMPACT") == 0)
	start_unordered_list(stack, depth, 1);
      else
	start_unordered_list(stack, depth, 0);
    }
    else if (strcmp(element, "LI") == 0)
      start_list_item(stack, depth, 0);
    else if (strcmp(element, "GL") == 0)
      start_glossary_list(stack, depth);
    else if (strcmp(element, "GT") == 0)
      start_glossary_tag(stack, depth);
    else if (strcmp(element, "GD") == 0)
      start_glossary_def(stack, depth);
    else if (strcmp(element, "DL") == 0)
      start_def_list(stack, depth);
    else if (strcmp(element, "DTHD") == 0)
      start_def_tag_heading(stack, depth);
    else if (strcmp(element, "DDHD") == 0)
      start_def_data_heading(stack, depth);
    else if (strcmp(element, "DT") == 0)
      start_def_tag(stack, depth);
    else if (strcmp(element, "DD") == 0)
      start_def_data(stack, depth);
    else if (strcmp(element, "LINES") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\begin{lines}");
	output.need_wrap = 1;
      }
      set_text_mode(0, 0, 0, 1);
      /* Reset the number of characters per line.  */
      if (c_line.setter != RTF && c_line.setter != TEXINFO) {
	char *ptr;			/* Dummy pointer.  */
	char *width = check_style("code-width");

	output_flush();		/* Flush pending text.  */
	output.line_width = strtol(width, &ptr, 10);
      }
    }
    else if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
      int head_level = element[1] - '0';
      char *last_element = stack[-1].element;

      /* General DTD uses section headers within abstract etc.  */
      if (c_line.family == FAM_TEX) {
	if (dtd.in_title_page) {
	  output.need_wrap = 1;
	  gfputs("\\titlepheading{");
	}
	else if (strcmp(last_element, "ABSTRACT") == 0) {
	  output.need_wrap = 1;
	  gfputs("\\abstractheading{");
	}
	else if (strcmp(last_element, "PREFACE") == 0) {
	  output.need_wrap = 1;
	  gfputs("\\prefaceheading{");
	}
	else if (structure.infrontm) {
	  output.need_wrap = 1;
	  if (head_level == 1)
	    gfputs("\\frontheading{");
	  else
	    gfputs("\\subheading{");
	}
	else if (structure.inbackm) {
	  output.need_wrap = 1;
	  if (head_level == 1)
	    gfputs("\\backheading{");
	  else
	    gfputs("\\subheading{");
	}
	else
	  start_heading(stack, depth, head_level, 1);
      }
      else
	start_heading(stack, depth, head_level, 1);
    }
    else if (strcmp(element, "APPENDIX") == 0)
      start_appendix(stack, depth);
    else if (strcmp(element, "HDREF") == 0 || strcmp(element, "FIGREF") == 0
	     || strcmp(element, "FNREF") == 0 
	     || strcmp(element, "LIREF") == 0) {
      char *type = check_attribute(stack, "PAGE")->values;
      
      start_long_reference(stack, depth, strcmp(type, "NO"));
    }
    else if (strncmp(element, "HP", 2) == 0 && element[3] == '\0')
      start_phrase(stack, depth);
    else if (strcmp(element, "CIT") == 0) {
      gfputs("\\cit{");
    }
    else if (strcmp(element, "AUTHOR") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\author{");
    }
    else if (strcmp(element, "ADDRESS") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\address{");
      else
	gfputs(" (");
    }
    else if (strcmp(element, "TITLE") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\title{");
    }
    else if (strcmp(element, "DATE") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\date{");
    }
    else if (strcmp(element, "DOCNUM") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("\\docnum{");
    }
    else if (strcmp(element, "TOC") == 0) {
      char *toc_page = check_style("toc-page");
    
      if (strcmp(toc_page, "toc-omit") != 0) {
	gfputs("\\gftoc");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "FIGLIST") == 0) {
      char *lof_page = check_style("lof-page");
    
      if (strcmp(lof_page, "lof-omit") != 0) {
	gfputs("\\gflof");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "INDEX") == 0)
      start_index(stack, depth, 0);
    else if (strcmp(element, "IX") == 0)
      start_index_entry(stack, depth);
    else if (strcmp(element, "ABSTRACT") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	if (dtd.in_title_page)
	  gfputs("\\begin{tabstract}");
	else
	  gfputs("\\begin{abstract}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "PREFACE") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\begin{preface}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "BIBLIOG") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\begin{bibliog}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "GLOSSARY") == 0) {
      if (c_line.family == FAM_TEX)  {
	output.need_wrap = 1;
	gfputs("\\begin{gfglossary}");
	output.need_wrap = 1;
      }
    }
  }
}

void general_element_end(struct stack *stack, int depth)
{
  char *element = stack->element;

  if (dtd.pass == 1) {
    if (c_line.family != FAM_TEX) {
      /* Just keeping track of counters etc.  */
      if (strcmp(element, "OL") == 0)
	end_ordered_list(stack, depth, 1);
      else if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
	int head_level = element[1] - '0';
	end_heading(stack, depth, head_level, 1);
      }
    }
  }
  else {
    text.aline_pending = 0;
    text.new_par = 0;
    text.par_pending = 0;
    if (strcmp(element, "P") == 0)
      end_paragraph(stack, depth);
    else if (strcmp(element, "Q") == 0)
      end_shortquote(stack, depth);
    else if (strcmp(element, "LQ") == 0)
      end_longquote(stack, depth);
    else if (strcmp(element, "NOTE") == 0)
      end_note(stack, depth);
    else if (strcmp(element, "ADDRESS") == 0) {
      if (c_line.family == FAM_TEX)
	gfputs("}");
      else
	gfputs(") ");
      text.aline_pending = 1;
    }
    else if (strcmp(element, "XMP") == 0) {
      struct attr *type = query_attribute(stack, "LINES");

      if (type != NULL && strcmp(type->type, "TOKEN") == 0
	    && strcmp(type->values, "LINES") == 0) {
	restore_text_mode();
	if (c_line.family == FAM_TEX) {
	  output.need_wrap = 1;
	  gfputs("\\end{xmp}");
	  output.need_wrap = 1;
	} 
	/* Reset the number of characters per line.  */
	if (c_line.setter != RTF && c_line.setter != TEXINFO) {
	  char *ptr;			/* Dummy pointer.  */
	  char *width = check_style("line-width");
	  
	  output_flush();	/* Flush pending text.  */
	  output.line_width = strtol(width, &ptr, 10);
	}
      }
      else			/* Flowed XMP.  */
	end_code_inline(stack, depth);
    }
    else if (strcmp(element, "ALINE") == 0 || strcmp(element, "TLINE") == 0)
      end_aline(stack, depth);
    else if (strcmp(element, "FIG") == 0)
      end_gen_fig(stack, depth);
    else if (strcmp(element, "FIGBODY") == 0)
      end_gen_figbody(stack, depth);
    else if (strcmp(element, "FN") == 0)
      end_note(stack, depth);
    else if (strcmp(element, "TBL") == 0)
      end_gen_table(stack, depth);
    else if (strcmp(element, "F") == 0 || strcmp(element, "H") == 0
	     || strcmp(element, "C") == 0) {
      if (strcmp(element, "C") == 0) {
	struct attr *heading = query_attribute(stack, "HEADING");

	if (heading != NULL && strcmp(heading->type, "TOKEN") == 0
	    && strcmp(heading->values, "H") == 0)
	  gfputs("}");
      }
      gfputs("&");
    }
    else if (strcmp(element, "HR") == 0) {
      gfputs("\\cr");
      output.need_wrap = 1;
      gfputs("\\rowrule");
      output.need_wrap = 1;
    }
    else if (strcmp(element, "FR") == 0)
      end_gen_foot_row(stack, depth);
    else if (strcmp(element, "R") == 0) {
      gfputs("\\cr");
      output.need_wrap = 1;
    }
    else if (strncmp(element, "TOP", 3) == 0 && element[4] == '\0') {
      int top_level = element[3] - '0';

      if (c_line.family == FAM_TEX) {
	if (top_level == 1)
	  gfputs("\\end{topone}");
	else if (top_level == 2)
	  gfputs("\\end{toptwo}");
	else if (top_level == 3)
	  gfputs("\\end{topthree}");
	else if (top_level == 4)
	  gfputs("\\end{topfour}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "TH") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "OL") == 0)
      end_ordered_list(stack, depth, 0);
    else if (strcmp(element, "UL") == 0)
      end_unordered_list(stack, depth);
    else if (strcmp(element, "SL") == 0)
      end_simple_list(stack, depth);
    else if (strcmp(element, "NL") == 0)
      end_unordered_list(stack, depth);
    else if (strcmp(element, "LI") == 0)
      end_list_item(stack, depth);
    else if (strcmp(element, "LINES") == 0) {
      restore_text_mode();
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\end{lines}");
	output.need_wrap = 1;
      } 
      /* Reset the number of characters per line.  */
      if (c_line.setter != RTF && c_line.setter != TEXINFO) {
	char *ptr;			/* Dummy pointer.  */
	char *width = check_style("line-width");

	output_flush();			/* Flush pending text.  */
	output.line_width = strtol(width, &ptr, 10);
      }
    }
    else if (element[0] == 'H' && strcmp(element + 2, "T") == 0) {
      int head_level = element[1] - '0';
      end_heading(stack, depth, head_level, 0);
    }
    else if (strncmp(element, "HP", 2) == 0 && element[3] == '\0')
      end_phrase(stack, depth);
    else if (strcmp(element, "CIT") == 0) {
      gfputs("}");
    }
    else if (strcmp(element, "GL") == 0)
      end_glossary_list(stack, depth);
    else if (strcmp(element, "GT") == 0)
      end_glossary_tag(stack, depth);
    else if (strcmp(element, "DL") == 0)
      end_def_list(stack, depth);
    else if (strcmp(element, "DTHD") == 0)
      end_def_tag_heading(stack, depth);
    else if (strcmp(element, "DDHD") == 0)
      end_def_data_heading(stack, depth);
    else if (strcmp(element, "DT") == 0)
      end_def_tag(stack, depth);
    else if (strcmp(element, "DD") == 0)
      end_def_data(stack, depth);
    else if (strcmp(element, "ABSTRACT") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	if (dtd.in_title_page)
	  gfputs("\\end{tabstract}");
	else
	  gfputs("\\end{abstract}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "PREFACE") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\end{preface}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "BIBLIOG") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\end{bibliog}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "GLOSSARY") == 0) {
      if (c_line.family == FAM_TEX) {
	output.need_wrap = 1;
	gfputs("\\end{gfglossary}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "AUTHOR") == 0 
	     || strcmp(element, "TITLE") == 0
	     || strcmp(element, "THANKS") == 0
	     || strcmp(element, "DOCNUM") == 0
	     || strcmp(element, "DATE") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "IX") == 0)
      end_index_entry(stack, depth);
    else if (strcmp(element, "GENERAL") == 0)
      end_document(stack, depth);
    else if (strcmp(element, "FRONTM") == 0)
      structure.infrontm = 0;
    else if (strcmp(element, "BODY") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\end{body}");
	output.need_wrap = 1;
      }
    }
    else if (strcmp(element, "TITLEP") == 0) {
      if (c_line.family == FAM_TEX) {
	gfputs("\\end{titlepage}");
	output.need_wrap = 1;
	dtd.in_title_page = 0;
      }
      /* Free the stored text, if no other storage.  */
      if (output.store_text == 0)
	free_storage();
    }
  }
}

/* Amount of memory to grab at once when reading files.  */
#define BLOCK 1000

/* Process an external entity reference.  */
void general_x_ent(struct stack *stack, int depth,
		  struct entity_info *entity_ptr)
{
  error(EXIT, 0, "general: external entities not supported");
}

/* Process a text string.  */
void general_chars(struct stack *stack, int depth, char *string)
{
  if (output.discard_text) {
    /* Don't call print_escaped while discarding text: it can introduce
     * wraps etc.
     */
    return;
  }
  if (!(text.contents->respect_spaces && text.contents->preserve_breaks)) {
    tidy_string(string, text.contents->respect_spaces,
		text.contents->preserve_breaks);
     if (!text.contents->respect_spaces && text.new_par)
       strip_leading_blanks(string);
  }
  string = replace_sdata(string, &sdata, text.contents->tt,
			 text.contents->math);

  print_escaped(string, 1, text.contents->tt,
		text.contents->math);
}

int general_end()
{
  dtd.pass++;

  /* Two passes through the document are usually needed.  */
  if (dtd.pass > 2)
    return(1); /* Finished.  */
  else 
    return(0); /* Do another pass.  */
}
